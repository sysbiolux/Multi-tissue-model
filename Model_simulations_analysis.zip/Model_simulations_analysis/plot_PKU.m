clearvars;clc;
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');

disease='PHENYLKETONURIA';%'3_MCC_deficiency';%
load(['Results_Milan_young_LF_IEM_KD_fraction_0_',disease],'lpsol','Results','model')

res_sol_1=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_1(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_1=Results;
    clear Results qp_sols lpsol FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
     
load(['Results_Milan_young_HF_IEM_KD_fraction_0_',disease],'lpsol','Results','model')
    res_sol_2=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_2(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_2=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

    
load(['Results_no_food_IEM_KD_fraction_0_',disease],'lpsol','Results','model')

    res_sol_3=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_3(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_3=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime    
    
    
    load(['Results_Milan_young_LF_healthy'],'lpsol','Results','model')

res_sol_4=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_4(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_4=Results;
    clear Results qp_sols lpsol FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
     
load(['Results_Milan_young_HF_healthy'],'lpsol','Results','model')
    res_sol_5=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_5(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_5=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

    
load(['Results_no_food_healthy'],'lpsol','Results','model')

    res_sol_6=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_6(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_6=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime 
    %%
%    yellow=[240,228,66];%/255;
   vermillon=[227, 66, 52]/256;
%    blue=[86,180,233]/256;
load('colorblind_colormap.mat')
   black=colorblind(ismember(colornames,'black'),:);
   blue=colorblind(ismember(colornames,'blue'),:);
%    red=colorblind(ismember(colornames,'red'),:);

rxns={'store_phe_L[bl]','store_tyr_L[bl]','Muscle_phe_L_store',...
    'Muscle_tyr_L_store', 'Urine_excretion_phe_L','Urine_excretion_tyr_L'};
rxns=rxns(ismember(rxns,model.rxns));
labels={'Blood storage: phenylalanine','Blood storage: tyrosine','Muscle storage: phenylalanine',...
    'Muscle storage: tyrosine','Urine excretion: phenylalanine',...
    'Urine excretion: tyrosine'};
nrows = 3;
ncols = 2;

 for r= 1 : numel(rxns)
    if nrows*ncols-mod(-r, nrows*ncols) == 1
        fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%         H=suptitle(['Simulation of Exercise with Meal']);
%         set(H,'FontSize',20,'Position',[0.5,-0.02,0])
    end
    subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
    hold on
    if r>=5
        pos=ismember(model.rxns,rxns(r));
        vector1=(res_sol_1(pos,:));
        vector2=(res_sol_2(pos,:));
        vector3=(res_sol_3(pos,:));
        vector4=(res_sol_4(pos,:));
        vector5=(res_sol_5(pos,:));
        vector6=(res_sol_6(pos,:));
        clear pos

        plot([1:360],vector4,'Color',black,'LineStyle','-','LineWidth',2)
        plot([1:360],vector5,'Color',vermillon,'LineStyle','-','LineWidth',2)
        plot([1:360],vector6,'Color',blue,'LineStyle','-','LineWidth',2)

        plot([1:360],vector1,'Color',black,'LineStyle','--','LineWidth',2)
        plot([1:360],vector2,'Color',vermillon,'LineStyle','--','LineWidth',2)
        plot([1:360],vector3,'Color',blue,'LineStyle','--','LineWidth',2)

        ylabel([labels(r), '[\mumol/min]'],'FontSize',14)
        xlim([1,360])
        fig1.CurrentAxes.XTick=[1,fig1.CurrentAxes.XTick];
    elseif r<=2
        pos=ismember(Results_1.Properties.RowNames,rxns(r));
        vector1=(Results_1{pos,:})/5;
        vector2=(Results_2{pos,:})/5;
        vector3=(Results_3{pos,:})/5;
        vector4=(Results_4{pos,:})/5;
        vector5=(Results_5{pos,:})/5;
        vector6=(Results_6{pos,:})/5;
        clear pos

        plot([0:360],vector4,'Color',black,'LineStyle','-','LineWidth',2)
        plot([0:360],vector5,'Color',vermillon,'LineStyle','-','LineWidth',2)
        plot([0:360],vector6,'Color',blue,'LineStyle','-','LineWidth',2)

        plot([0:360],vector1,'Color',black,'LineStyle','--','LineWidth',2)
        plot([0:360],vector2,'Color',vermillon,'LineStyle','--','LineWidth',2)
        plot([0:360],vector3,'Color',blue,'LineStyle','--','LineWidth',2)
        ylabel([labels(r), '[\mumol/L]'],'FontSize',14)
        xlim([0,360])
    elseif r<=4 && r>=3
        pos=ismember(Results_1.Properties.RowNames,rxns(r));
        vector1=(Results_1{pos,:});
        vector2=(Results_2{pos,:});
        vector3=(Results_3{pos,:});
        vector4=(Results_4{pos,:});
        vector5=(Results_5{pos,:});
        vector6=(Results_6{pos,:});
        clear pos

        plot([0:360],vector4,'Color',black,'LineStyle','-','LineWidth',2)
        plot([0:360],vector5,'Color',vermillon,'LineStyle','-','LineWidth',2)
        plot([0:360],vector6,'Color',blue,'LineStyle','-','LineWidth',2)

        plot([0:360],vector1,'Color',black,'LineStyle','--','LineWidth',2)
        plot([0:360],vector2,'Color',vermillon,'LineStyle','--','LineWidth',2)
        plot([0:360],vector3,'Color',blue,'LineStyle','--','LineWidth',2)
        ylabel([labels(r), '[\mumol]'],'FontSize',14)
        xlim([0,360])
    end
    xlabel('Time in min','FontSize',14)
    hold off
 end
L=legend('Healthy: LF meal','Healthy: HF meal','Healthy: Fasting','PKU: LF meal',...
    'PKU: HF meal','PKU: Fasting');
L.FontSize=12;
L.Location='bestoutside';

fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 20 25];
%saveas(fig1,'PKU_IEM.svg')
