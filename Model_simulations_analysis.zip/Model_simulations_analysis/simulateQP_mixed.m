function [infeasibility,intCounter] = simulateQP_mixed(model,steps,params,WorkingDir,...
    FoodApplicationTime,ExerciseIntensity,ExerciseStoppingTime,ExerciseStartingTime,tag,exp,meal,x,sol_fast,step_size)

tic
% step_size=1/12;
infeasibility=[];
% step_size=60/60;
% if steps<150;
%     step=20;
% else
    step=500;
% end
if ~isempty(x)
    MIN=min(sol_fast,[],2);
    MAX=max(sol_fast,[],2);
%     model.lb= MIN*1.1;
%     model.ub= MAX*1.1;

    MinMax=[MIN,MAX];

% %     a=0.9;
% %     b=1;
% %     rxn_KD=a + (b-a).*rand(1);

    rxn_KD=0;
    MIN=min(sol_fast(x,:));
    MAX=max(sol_fast(x,:));
    if MIN<-50 || MAX>50
        model.lb(x)= MIN*rxn_KD;
        model.ub(x)= MAX*rxn_KD;
    else
        infeasibility=[];
        intCounter=[];
        return
    end
else
    MinMax=[];
end

BasalMuscleATPdemand=model.lb(ismember(model.rxns,'Muscle_DM_atp'));

% pos_stores=ismember(model.rxns,{'Hep_store_protein','Muscle_store_protein','Fat_store_protein','thr_L_FOOD'});

%Setup the Model, with physiological constraints
% [model] = SetupModel();
% orig_model = model;
model=changeRxnBounds(model,{'store_HC00250[bl]',...
    'store_cl[bl]','store_na1[bl]','store_fe2[bl]','store_fe3[bl]','store_k[bl]','store_h[bl]','store_hco3[bl]'},0,'b');
% model=changeRxnBounds(model,model.rxns(find(~cellfun('isempty',strfind(model.rxns,'secretion')))),0,'b');

% model=addReactions('model)
%,'protein_production_Fat'
% model=changeRxnBounds(model,'Fat_TAGt',1000000,'u');
%Define Initial conditions
% Res_food='';
% Hep_urea_export_flux = find(ismember(model.rxns,'Hep_urea'));

hep_glygn_amount=100/1800*1000000; %100g C66H111O56X 12*66+111+56*16=1799
hep_glygn_rxn = find(ismember(model.rxns,'Hep_glygn_stores'));
hep_glygn_phys_max_flux = model.ub(hep_glygn_rxn);
hep_glygn_phys_min_flux = model.lb(hep_glygn_rxn);
hep_glygn_maxamount = 150/1800*1000000;

fat_tag_amount=12.43*1000*0.9/879*1000000; %12,43 kg * 90%
fat_tag_rxn = find(ismember(model.rxns,'Fat_tag_stores'));
fat_tag_max_flux = model.ub(fat_tag_rxn);
fat_tag_min_flux = model.lb(fat_tag_rxn);

muscle_tag_amount=300/879*1000000; %min 318 g max 530 g if 37.7kj/g fat Cpyle E F 1995
muscle_tag_rxn = find(ismember(model.rxns,'Muscle_tag_stores'));
% muscle_tag_max_flux = model.ub(fat_tag_rxn);
% muscle_tag_min_flux = model.lb(fat_tag_rxn);

muscle_glygn_rxn = find(ismember(model.rxns,'Muscle_glygn_stores'));	
muscle_glygn_phys_min_flux = model.lb(muscle_glygn_rxn);
muscle_glygn_phys_max_flux = model.ub(muscle_glygn_rxn);
muscle_glygn_amount=380/1800*1000000;
muscle_glygn_maxamount = 500/1800*1000000;

%update the flux bounds for the fat storage fluxes
model = updateFluxBound(model,hep_glygn_rxn,hep_glygn_amount,hep_glygn_phys_min_flux,hep_glygn_phys_max_flux,hep_glygn_maxamount);
model = updateFluxBound(model,muscle_glygn_rxn,muscle_glygn_amount,muscle_glygn_phys_min_flux,muscle_glygn_phys_max_flux,muscle_glygn_maxamount);
model = updateFluxBound(model,fat_tag_rxn,fat_tag_amount,fat_tag_min_flux,fat_tag_max_flux,inf);
hep_glygn_exp = find(ismember(model.rxns,'Hep_GLYGN1_EXP'));	
hep_glygn_imp = find(ismember(model.rxns,'Hep_GLYGN2_IMP'));
muscle_glygn_exp = find(ismember(model.rxns,'Muscle_GLYGN1_EXP'));	
muscle_glygn_imp = find(ismember(model.rxns,'Muscle_GLYGN2_IMP'));
fat_tag_exp = find(ismember(model.rxns,'Fat_tag_stores_exp'));	
fat_tag_imp = find(ismember(model.rxns,'Fat_tag_stores_imp'));
muscle_tag_exp = find(ismember(model.rxns,'Muscle_tag_stores_exp'));	
muscle_tag_imp = find(ismember(model.rxns,'Muscle_tag_stores_imp'));
ObjProtein=[find(ismember(model.rxns,{'Hep_protein_production','Muscle_protein_production','Fat_protein_production'}));...
    find(ismember(model.rxns,{'Hep_protein_degradation','Muscle_protein_degradation','Fat_protein_degradation'}))];
% ObjConstraints=[hep_glygn_exp,hep_glygn_imp,muscle_glygn_exp,muscle_glygn_imp,fat_tag_exp,fat_tag_imp];
% ObjConstraints=[hep_glygn_rxn,muscle_glygn_rxn,fat_tag_exp,fat_tag_imp];
ObjConstraintsLP=[hep_glygn_exp,muscle_glygn_exp,fat_tag_exp,muscle_tag_exp];
ObjConstraintsQP=[hep_glygn_imp,muscle_glygn_imp,fat_tag_imp,muscle_tag_imp];

%Load the Blood concentration levels and the bounded reactions.
Blood_Concentrations = readtable('Blood_concentrations_updated.csv','delimiter',';');
Blood_Concentrations=Blood_Concentrations(~ismember(Blood_Concentrations{:,1},'Muscle_tag_stores'),:);
Blood_Concentrations{~ismember(Blood_Concentrations{:,1},model.rxns),1}
Blood_Concentrations=Blood_Concentrations(ismember(Blood_Concentrations{:,1},model.rxns),:);%allow albumin depletion

% updated exercise bounds
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');
BoundedReactions = BoundedReactions([1:65,75:87,208:end],:);%
% BoundedReactions.lb(ismember(BoundedReactions{:,1},'Fat_lac_L')) = 0;

% model=changeRxnBounds(model,{'Hep_lac_L'},0,'u'); 
% model=changeRxnBounds(model,{'Muscle_lac_L'},0,'l'); 

% BoundedReactions.ub(ismember(BoundedReactions{:,1},'Hep_lac_L')) = 0;
% BoundedReactions.lb(ismember(BoundedReactions{:,1},'Muscle_lac_L')) = 0;
% BoundedReactions.ub(59) = 0; %Muscle glyc production
% BoundedReactions.ub(41) = 0; %Fat_tag_hs production
% model=changeRxnBounds(model,'Muscle_glyc',0,'u');
BoundedReactions=BoundedReactions(~ismember(BoundedReactions{:,1},'Hep_glc_D'),:);
OtherExchangeReactions={'Muscle_CBPS';'Fat_r0245';'Muscle_r0245'};%'Hep_h';'Fat_h'};%'Muscle_LPS2e';'Muscle_LPS3e';'Fat_LPS2e';'Fat_LPS3e';'Muscle_h';'Fat_h'};%;'Hep_h';'Muscle_h';'Fat_h'};
OtherExchangeReactions=[OtherExchangeReactions,num2cell(zeros(numel(OtherExchangeReactions),2))];
% OtherExchangeReactions(4:5,3)={1000000};
BoundedReactions=[BoundedReactions;OtherExchangeReactions];
BoundedReactions=BoundedReactions(~ismember(BoundedReactions{:,1},'store_o2[bl]'),:);
% Muscle_glc_D,-19333,-44.84
% BoundedReactions.lb(ismember(BoundedReactions{:,1},'Muscle_glc_D')) = -19333;
% ACC={'Fat_ACCOAC';'Fat_ACCOACL';'Fat_ACCOACm';'Fat_ACCOAC2';'Muscle_ACCOAC';'Muscle_ACCOACL';'Muscle_ACCOACm';'Muscle_ACCOAC2';'Hep_ACCOAC';'Hep_ACCOACL';'Hep_ACCOACm';'Hep_ACCOAC2'};
% MCD={'Fat_MCD';'Fat_MCDm';'Fat_MCDp';'Hep_MCD';'Hep_MCDm';'Hep_MCDp';'Muscle_MCD';'Muscle_MCDm';'Muscle_MCDp'};
% OtherExchangeReactions=[ACC;MCD];
% OtherExchangeReactions=[OtherExchangeReactions,num2cell(zeros(numel(OtherExchangeReactions),2))];
% OtherExchangeReactions(:,3)={1000000};
% BoundedReactions=[BoundedReactions;OtherExchangeReactions];

% rxns=unique([{'MDH3','MDH2','ADH2','ADH1','ADH5','ADH4','BIO2','SFA1_2','SFA1_1','LYS1','TDH1','TDH2','TDH3'},...
% {'BTDD-RR','FALDH','2HBO','ALCD2x','SACCD2','MDH','GAPD'},...
% {'BIO2','LYS1','r275','ADH1','SFA1_1','MDH2'},...
% {'r_0714','r_0486','r_0470','r_0003,U45_','PRO3_3','FAS1_4','FOX2','PRO2_1','LYS2_2','HOM6_1'},...
% {'AASAD2','G5SD2','HPROa','ALCD25xi','ALCD2ir','ALCD26xi','ALCD22xi','FMNRx','ALCD23xi','C22STDSx','LNS14DMx','HSDxi','ALCD24xi'},...
% {'LYS2_2','PRO2_1','U45_','PRO3_3','HOM6_1','PGA3'},...
% {'r_0169','r_0166','r_0179','r_0182','r_0186','r_0441','r_1010','r_2115'}]);
% tissues={'Fat_';'Muscle_';'Hep_'};
% OtherExchangeReactions=[strcat(tissues(1),rxns),strcat(tissues(2),rxns),strcat(tissues(3),rxns)];
% OtherExchangeReactions=OtherExchangeReactions(ismember(OtherExchangeReactions,model.rxns));
% OtherExchangeReactions=intersect(findRxnsFromMets(model,{'Fat_nadh[c]';'Muscle_nadh[c]';'Hep_nadh[c]'}),findRxnsFromMets(model,{'Fat_nad[c]';'Muscle_nad[c]';'Hep_nad[c]'}));
% OtherExchangeReactions=[OtherExchangeReactions,num2cell(zeros(numel(OtherExchangeReactions),2))];
% rxns={'Fat_34DHOXPEGOX','Fat_RE3347C','Hep_34DHOXPEGOX','Hep_RE3347C','Muscle_34DHOXPEGOX'};
% OtherExchangeReactions(~ismember(OtherExchangeReactions(:,1),rxns),3)={1000000};
% OtherExchangeReactions(ismember(OtherExchangeReactions(:,1),rxns),2)={-1000000};
% BoundedReactions=[BoundedReactions;OtherExchangeReactions];
% OtherExchangeReactions={'Hep_GLCMter'};
% OtherExchangeReactions=[OtherExchangeReactions,num2cell(zeros(numel(OtherExchangeReactions),2))];
% OtherExchangeReactions(:,2:3)={278,1000000};
% BoundedReactions=[BoundedReactions;OtherExchangeReactions];
% model=changeRxnBounds(model,{'Muscle_LDH_L','Muscle_r0173','Muscle_LDH_Lm'},0,'l'); 
% model=changeRxnBounds(model,{'Hep_lac_L'},0,'u'); 
% model=changeRxnBounds(model,{'Muscle_lac_L'},0,'l'); 

% OtherExchangeReactions={'Fat_r1418';'Hep_r1418';'Muscle_r1418'};
% OtherExchangeReactions=[OtherExchangeReactions,num2cell(zeros(numel(OtherExchangeReactions),2))];
% OtherExchangeReactions(:,3)={1000000};
% BoundedReactions=[BoundedReactions;OtherExchangeReactions];
% model=addReaction(model,'DM_atp','h2o[bl] + atp[bl] -> adp[bl] + h[bl] + pi[bl]'); 
% model=changeRxnBounds(model,'DM_atp',86758,'b');
% rxn_pos=randi(size(BoundedReactions,1));
% a=0.9;
% b=1;
% rxn_KD=a + (b-a).*rand(1);
% 
% BoundedReactions{rxn_pos,2:3}=BoundedReactions{rxn_pos,2:3}*rxn_KD;
% BoundedReactions=BoundedReactions(1:end-1,:);

% for a=1:size(BoundedReactions,1)
%    model=changeRxnBounds(model, BoundedReactions{a,1},BoundedReactions{a,2},'l');
%    model=changeRxnBounds(model, BoundedReactions{a,1},BoundedReactions{a,3},'u');
% end

% liver_constraints = readtable('liver_release_constraints.csv','delimiter',';');

% patient_data=readtable([strjoin(diet),'_',strjoin(patient_id),'.csv'],'delimiter',';','ReadVariableNames',0);
% [A,B]=ismember(Blood_Concentrations{:,1},patient_data{:,1});
% % [Blood_Concentrations{A,1},num2cell(Blood_Concentrations{A,2}),patient_data{B(A),1},num2cell(Blood_Concentrations{A,3}),num2cell(patient_data{B(A),2}*5),num2cell(Blood_Concentrations{A,4})]
% Blood_Concentrations{A,2}=patient_data{B(A),2}*5;
% 
% BoundedReactions = readtable('BoundedReactions.csv','delimiter',';');
% Orig_BoundedReactions=BoundedReactions;
% Hep=strncmp(BoundedReactions{:,1},'Hep',3);
% Muscle=strncmp(BoundedReactions{:,1},'Muscle',3);
% Fat=strncmp(BoundedReactions{:,1},'Fat',3);
% pos_patient=find(BoundedReactions{5,7:9}==str2double(cell2mat(patient_id)));
% BoundedReactions{Hep,2:3}=BoundedReactions{Hep,2:3}*BoundedReactions{1,6+pos_patient}/BoundedReactions{1,7};
% BoundedReactions{Muscle,2:3}=BoundedReactions{Muscle,2:3}*BoundedReactions{2,6+pos_patient}/BoundedReactions{2,7};
% BoundedReactions{Fat,2:3}=BoundedReactions{Fat,2:3}*BoundedReactions{3,6+pos_patient}/BoundedReactions{3,7};
% BoundedReactions{BoundedReactions{:,2}<-1000000,2}=-1000000;
% BoundedReactions{BoundedReactions{:,3}>1000000,3}=1000000;
% 
% model.S(:,ismember(model.rxns,'Hep_protein_turnover'))=model.S(:,ismember(model.rxns,'Hep_protein_turnover'))*BoundedReactions{1,6+pos_patient}/BoundedReactions{1,7};
% model.S(:,ismember(model.rxns,'Muscle_protein_turnover'))=model.S(:,ismember(model.rxns,'Muscle_protein_turnover'))*BoundedReactions{2,6+pos_patient}/BoundedReactions{2,7};
% model.S(:,ismember(model.rxns,'Fat_protein_turnover'))=model.S(:,ismember(model.rxns,'Fat_protein_turnover'))*BoundedReactions{3,6+pos_patient}/BoundedReactions{3,7};

%%adjust also aa amount in muscle??

Muscle_aa_storage = readtable('Muscle_aa_amount.csv','delimiter',';');
% Muscle_degradation_rates = readtable('Muscle_aa_degradation_rates.csv','delimiter',';');
% [A,B]=ismember(Muscle_degradation_rates{:,1},Muscle_aa_storage{:,1});
% degradation_rates=[Muscle_degradation_rates{:,1},num2cell(Muscle_aa_storage{B(A),2}./Muscle_degradation_rates{:,2})];

Current_aa_storage=Muscle_aa_storage;
Current_aa_storage{:,2} = 0;
MIN_aa=Muscle_aa_storage{:,3};
MAX_aa=Muscle_aa_storage{:,4};

protein_MW=134;%MW of average protein g/mol
hep_protein=429.52/protein_MW*1000000;%18.2g*2360g/100g %bordbar
muscle_protein=5.76*1000/protein_MW*1000000;% 18% total weight -sum(Muscle_aa_storage{:,2}); ????????????????
fat_protein=261/protein_MW*1000000;%bordbar
hep_protein_max=hep_protein*1.05;
muscle_protein_max=muscle_protein*1.05;
fat_protein_max=fat_protein*1.05;
protein_pos=find(ismember(model.rxns,{'Hep_store_protein','Muscle_store_protein','Fat_store_protein'}));

model = updateFluxBound(model,protein_pos(1),hep_protein,-inf,inf,hep_protein_max);
model = updateFluxBound(model,protein_pos(2),muscle_protein,-inf,inf,muscle_protein_max);
model = updateFluxBound(model,protein_pos(3),fat_protein,-inf,inf,fat_protein_max);
protein=cell2table([{'Hep_store_protein','Muscle_store_protein','Fat_store_protein'}',num2cell([hep_protein,0,hep_protein_max;...
    muscle_protein,0,muscle_protein_max;fat_protein,0,fat_protein_max])]);
Current_protein=protein;

Current_protein{:,2}=0;


% basal=readtable(['Basal_food_uptakes_balanced_diet_all_mets.csv'],'delimiter',';');
% basal=readtable(['Basal_food_uptakes_vmh.csv'],'delimiter',';');

% basal{1:end,2:4}=0;
% Food_conc = readtable(['food_amounts_per_meal_balanced_diet_all_mets_calbet_',strjoin(diet),'.csv'],'delimiter',';');
% Food_conc = readtable(['vmh_',strjoin(diet),'.csv'],'delimiter',';');
type_of_diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms
diet=type_of_diet(2);
Food_conc = readtable(['Food_amounts_',strjoin(diet),'.csv'],'delimiter',';');
food_30={'store_ile_L[bl]';'store_leu_L[bl]';'store_met_L[bl]';'store_phe_L[bl]';'store_trp_L[bl]';...
        'store_val_L[bl]';'store_pro_L[bl]';'store_ala_L[bl]';'store_asn_L[bl]';'store_cys_L[bl]';'store_ser_L[bl]';...
        'store_thr_L[bl]';'store_tyr_L[bl]';'store_his_L[bl]';'store_lys_L[bl]';'store_gly[bl]';'store_arg_L[bl]'};
food_99={'store_asp_L[bl]'};
food_98={'store_glu_L[bl]'};
food_66={'store_gln_L[bl]'};
food_20={'store_glc_D[bl]'};
% Food_conc{:,2}=Food_conc{:,2}*2;
Food_conc{ismember(Food_conc{:,1},food_30),2} = (Food_conc{ismember(Food_conc{:,1},food_30),2}*0.7);
Food_conc{ismember(Food_conc{:,1},food_99),2} = (Food_conc{ismember(Food_conc{:,1},food_99),2}*(1-0.99));
Food_conc{ismember(Food_conc{:,1},food_98),2} = (Food_conc{ismember(Food_conc{:,1},food_98),2}*(1-0.98));
Food_conc{ismember(Food_conc{:,1},food_66),2} = (Food_conc{ismember(Food_conc{:,1},food_66),2}*(1-0.66));
Food_conc{ismember(Food_conc{:,1},food_20),2} = (Food_conc{ismember(Food_conc{:,1},food_20),2}*(1-0.2));

% Food_conc{4,2} = 0;
% Food_conc{:,3}=find(ismember(model.rxns,table2cell(Food_conc(:,1))));
% meals=[1,0,0,0];
CurrentFood=Food_conc;
% % CurrentFood.Properties.VariableNames ={'Mets','Meal1','Meal2','Meal3','Meal4'};
% CurrentFood=[CurrentFood,array2table(CurrentFood{:,2})];
% CurrentFood.Properties.VariableNames ={'Mets','Meal1','Meal2'};
% CurrentFood=[CurrentFood,Food_conc(:,2)];
% CurrentFood.Properties.VariableNames ={'Mets','Meal1','Meal2','Meal3'};
% CurrentFood=[CurrentFood,Food_conc(:,2)];
% CurrentFood.Properties.VariableNames ={'Mets','Meal1','Meal2','Meal3','Meal4'};

% Res_food=table('RowNames',CurrentFood{:,1});
% AdipoConstraints=table();
% initial_food=CurrentFood;
CurrentConcentrationChanges = Blood_Concentrations;
CurrentConcentrationChanges{:,2} = 0;
MIN_BLOOD=Blood_Concentrations{:,3};
MAX_BLOOD=Blood_Concentrations{:,4};
%Initialize the results.
qp_sols=cell(1,step);
lp_sols=cell(1,step);
% qpmodels=cell(1,steps);
% lpmodels=cell(1,steps);
% Res_food=cell(size(Food_conc,1),steps);
% Res_food=cell2table(Res_food);
Results = table('RowNames',[Blood_Concentrations{:,1};'Muscle_glycogen';'Liver_glycogen';'Fat_TAG';'Muscle_TAG';Muscle_aa_storage{:,1};'Hep_protein_store';'Muscle_protein_store';'Fat_protein_store']);

% qp = Cplex();
% qp.DisplayFunc='';
% splitLP = Cplex();

% basal_rates=basal(:,1:2);
% [A,B]=ismember(basal{:,1},Food_conc{:,1});
% basal_rates{:,3}=[-Food_conc{B(A),2}*0.25/600];
% Results{:,1:steps+1}=zeros(size(Results,1),steps+1);
% [CurrentConcentrationChanges,CurrentFood]=food_decay(CurrentConcentrationChanges,CurrentFood,basal);
Results{:,1} = [Blood_Concentrations{:,2} + CurrentConcentrationChanges{:,2} ; muscle_glygn_amount;hep_glygn_amount;fat_tag_amount;muscle_tag_amount;...
    Muscle_aa_storage{:,2} + Current_aa_storage{:,2};0;0;0];
% capacity=[Food_conc{:,1}, array2table(zeros(size(Food_conc,1),1))];
% new_basal_rates=capacity;

Results.Properties.VariableNames={'Time_0'};
NewResults=Results;
% [A,B] = ismember(basal{:,1},new_basal_rates{:,1});
% new_basal_rates{(B(A)),2}=basal{A,2};

% capacity=[capacity,basal(:,2)];
% capacity.Properties.VariableNames{'BasalUptake'} ='Cap2';
% basal=readtable(['Basal_food_uptakes_balanced_diet_all_mets.csv'],'delimiter',';');

capacity=[Food_conc{:,1}, array2table(zeros(size(Food_conc,1),1))];
new_basal_rates=capacity;

% [A,B] = ismember(basal{:,1},new_basal_rates{:,1});
% new_basal_rates{(B(A)),2}=basal{A,2};
new_basal_rates=[new_basal_rates,array2table(zeros(size(new_basal_rates)),'VariableNames',{'adjusted','ub'})];
% new_basal_rates.Properties.VariableNames={'rxn','basal','adjusted','ub'};

i=0;
% res_capacity{1}=capacity;
% adj_rates{1}=capacity{:,2};
% res_new_rates
count=0;

 %adjust bound for gene knockdown
%         model.ub(rxnpos&qpsol_reference{time}.x(1:numel(model.rxns))>=0)=qpsol_reference{time}.x(rxnpos&(qpsol_reference{time}.x(1:numel(model.rxns))>=0))*DownFraction;
%         model.lb(rxnpos&qpsol_reference{time}.x(1:numel(model.rxns))<0)=qpsol_reference{time}.x(rxnpos&(qpsol_reference{time}.x(1:numel(model.rxns))<0))*DownFraction;

% qp=[];
% splitLP=[];
Food_conc_for_delay=Food_conc;

%  if tag==1
%     filenameResults='CurrentResultsFood.mat';
%  elseif tag==2
%     filenameResults='CurrentResults.mat';
%  elseif tag==3
%     filenameResults='CurrentResultsExerc.mat';
%  end

if tag==1
    filenameResults='CurrentResultsFood';
 elseif tag==2
    filenameResults='CurrentResults';
 elseif tag==3
    filenameResults='CurrentResultsExerc';
 elseif tag==4
    filenameResults='CurrentResultsShortSim';
 end
% m = matfile(filename, 'Writable', true);

if tag==3
    if exp==3
    %12h fast ---- 50% O2Max 5 min ----- 70% O2Max 1h55 ---- 30 min rest---- 70% O2Max 10 min ----- 80% O2Max 10 min ---- 90% O2Max 10 min
    %900 min 
        ExerciseIntensity70=31.67;
        ExerciseStartingTime70=ExerciseStoppingTime;
        ExerciseStoppingTime70=ExerciseStartingTime70+60+55;

        ExerciseIntensity70_incr=ExerciseIntensity70;
        ExerciseStartingTime70_incr=ExerciseStoppingTime70+30;
        ExerciseStoppingTime70_incr=ExerciseStartingTime70_incr+10;

        ExerciseIntensity80=36.33;
        ExerciseStartingTime80=ExerciseStoppingTime70_incr;
        ExerciseStoppingTime80=ExerciseStartingTime80+10;

        ExerciseIntensity90=41;
        ExerciseStartingTime90=ExerciseStoppingTime80;
        ExerciseStoppingTime90=ExerciseStartingTime90+10;
    end
end

%%
counter=1;
intCounter=1;
internal_time=0;
internal_time_vec=[];
steps=round(steps/step_size,0);
for time = 1:steps
    internal_time=internal_time+step_size
    i=i+1;
        count=count+1;
         if tag==3
            if exp==3
                if internal_time==ExerciseStartingTime70
                     ExerciseIntensity=ExerciseIntensity70;
                     ExerciseStartingTime=ExerciseStartingTime70;
                     ExerciseStoppingTime=ExerciseStoppingTime70;
                end
               
                if internal_time==ExerciseStartingTime70_incr
                    ExerciseIntensity=ExerciseIntensity70_incr;
                    ExerciseStartingTime=ExerciseStartingTime70_incr;
                    ExerciseStoppingTime=ExerciseStoppingTime70_incr;
                end
        
                if internal_time==ExerciseStartingTime80
                    ExerciseIntensity=ExerciseIntensity80;
                    ExerciseStartingTime=ExerciseStartingTime80;
                    ExerciseStoppingTime=ExerciseStoppingTime80;
                end
        
                if internal_time==ExerciseStartingTime90
                    ExerciseIntensity=ExerciseIntensity90;
                    ExerciseStartingTime=ExerciseStartingTime90;
                    ExerciseStoppingTime=ExerciseStoppingTime90;
                end
            end
         end
        if round(internal_time,2)==ExerciseStartingTime
%             previous_step_size=step_size;
%             step_size=step_size/small_step;%15 sec
            model=changeRxnBounds(model,'Muscle_DM_atp',(ExerciseIntensity*BasalMuscleATPdemand+BasalMuscleATPdemand),'b'); %1.9178e+06 vigourous biking umol/min atp
%         elseif round(internal_time,2)==ExerciseStartingTime+2;%step_size/step_size;
% %             previous_step_size=step_size;
% %             step_size=1;%1min
%             model=changeRxnBounds(model,'Muscle_DM_atp',(ExerciseIntensity*BasalMuscleATPdemand+BasalMuscleATPdemand)*step_size,'b'); 
        elseif round(internal_time,2)==ExerciseStoppingTime
%             previous_step_size=step_size;
%             step_size=step_size/small_step;%15 sec
            model=changeRxnBounds(model,'Muscle_DM_atp',BasalMuscleATPdemand,'b');
%         elseif round(internal_time,2)==ExerciseStoppingTime+2;%step_size/step_size
%             previous_step_size=step_size;
%             step_size=1;%1 min
%             model=changeRxnBounds(model,'Muscle_DM_atp',BasalMuscleATPdemand*step_size,'l');
%         else
%             previous_step_size=step_size;
        end
       
%         o2_10=(116940+6089+397.76)/9;
%         Intensity=[0,17.67,22.33,24.67,27.00,29.33,31.67,36.33,41];
%         O2max=[1000000,4, 5, 5.5,    6, 6.5,    7,    8,   9];
%         if round(ExerciseIntensity)~=0&&time==ExerciseStartingTime
%             O2max_simulation=O2max(round(Intensity)==round(ExerciseIntensity))*o2_10;
% %             model=changeRxnBounds(model,'store_o2[bl]',-O2max_simulation,'l');
%             BoundedReactions=[BoundedReactions;[{'store_o2[bl]'},num2cell([-O2max_simulation,0])]];
%         end
        
        if i==FoodApplicationTime   
            count=1;
            diet=type_of_diet(meal);
            Food_conc = readtable(['Food_amounts_',strjoin(diet),'.csv'],'delimiter',';');
            food_30={'store_ile_L[bl]';'store_leu_L[bl]';'store_met_L[bl]';'store_phe_L[bl]';'store_trp_L[bl]';...
                    'store_val_L[bl]';'store_pro_L[bl]';'store_ala_L[bl]';'store_asn_L[bl]';'store_cys_L[bl]';'store_ser_L[bl]';...
                    'store_thr_L[bl]';'store_tyr_L[bl]';'store_his_L[bl]';'store_lys_L[bl]';'store_gly[bl]';'store_arg_L[bl]'};
            food_99={'store_asp_L[bl]'};
            food_98={'store_glu_L[bl]'};
            food_66={'store_gln_L[bl]'};
            food_20={'store_glc_D[bl]'};
            % Food_conc{:,2}=Food_conc{:,2}*2;
            Food_conc{ismember(Food_conc{:,1},food_30),2} = (Food_conc{ismember(Food_conc{:,1},food_30),2}*0.7);
            Food_conc{ismember(Food_conc{:,1},food_99),2} = (Food_conc{ismember(Food_conc{:,1},food_99),2}*(1-0.99));
            Food_conc{ismember(Food_conc{:,1},food_98),2} = (Food_conc{ismember(Food_conc{:,1},food_98),2}*(1-0.98));
            Food_conc{ismember(Food_conc{:,1},food_66),2} = (Food_conc{ismember(Food_conc{:,1},food_66),2}*(1-0.66));
            Food_conc{ismember(Food_conc{:,1},food_20),2} = (Food_conc{ismember(Food_conc{:,1},food_20),2}*(1-0.2));
            CurrentFood=Food_conc; 
            Food_conc_for_delay=Food_conc;
            
            capacity=[Food_conc{:,1}, array2table(zeros(size(Food_conc,1),1))];
            new_basal_rates=capacity;
            new_basal_rates=[new_basal_rates,array2table(zeros(size(new_basal_rates)),'VariableNames',{'adjusted','ub'})];
            
        end
        

  [CurrentConcentrationChanges,CurrentFood,food_rates]=food_decay(CurrentConcentrationChanges,CurrentFood,count,Food_conc_for_delay,params,step_size);
       
    [new_basal_rates,capacity]=adjustBasalRate(new_basal_rates,CurrentConcentrationChanges,Blood_Concentrations,capacity,params);

    CurrentConcentrationChanges{:,3}= MIN_BLOOD-(Blood_Concentrations{:,2}+CurrentConcentrationChanges{:,2});
    CurrentConcentrationChanges{:,4}= MAX_BLOOD-(Blood_Concentrations{:,2}+CurrentConcentrationChanges{:,2});

    Current_aa_storage{:,3}= MIN_aa-(Muscle_aa_storage{:,2}+Current_aa_storage{:,2});
    Current_aa_storage{:,4}= MAX_aa-(Muscle_aa_storage{:,2}+Current_aa_storage{:,2});
    
    Current_protein{:,3}=Current_protein{:,3}-(protein{:,2}+Current_protein{:,2});
    Current_protein{:,4}=Current_protein{:,4}-(protein{:,2}+Current_protein{:,2});
  
    if ~ exist('previous_sol')%internal_time==time
%         load Previous_solution
%         load('Results_healthy_exercise_sim_1','lp_sols')
%         previous_sol=lp_sols{1000};
%         clear lp_sols
       previous_sol=[];
    end
    
%     if step_size<previous_step_size
%         previous_sol.x=previous_sol.x*step_size;
%     elseif step_size>previous_step_size
%         previous_sol.x=previous_sol.x/previous_step_size;
%     end
    
    [qp_sol,solfound] = setupBalancingQP_mixed(model,new_basal_rates,params, BoundedReactions, CurrentConcentrationChanges,Blood_Concentrations,ObjConstraintsLP,...
        ObjConstraintsQP,...
        internal_time,food_rates,Muscle_aa_storage,Current_aa_storage,ObjProtein,protein_pos,Current_protein,diet,WorkingDir,previous_sol,FoodApplicationTime,...
        ExerciseStartingTime,ExerciseStoppingTime,ExerciseIntensity,meal,MinMax,step_size);

    internal_time_vec=[internal_time_vec,internal_time];
    qp_sols{:,counter}=qp_sol;
    if strcmp(qp_sol.statusstring,'infeasible')% || qp_sol.method==4%~solfound strcmp(qp_sol.statusstring,'infeasible') %| ~strcmp(solqp.statusstring,'integer optimal solution')
        try
            infeasibility=[infeasibility;internal_time];
            NewResults=NewResults(:,sum(table2array(NewResults))~=0);
%             NewResults=array2table(NewResults);
            NewResults.Properties.VariableNames{counter}=(['Time',strrep(num2str(internal_time_vec),'.','_')]);
%             ,'VariableNames',strrep(strcat({'Time_'},num2str([step*(intCounter-1)+1:time-1]')),' ',''));
            save([filenameResults,num2str(intCounter)],'NewResults','lp_sols','qp_sols','infeasibility')
        catch
            infeasibility=[infeasibility;internal_time];
            save([filenameResults,num2str(intCounter)],'lp_sols','qp_sols','infeasibility')
        end
        return        
    end
    [qp_sol.statusstring,' ',num2str(qp_sol.method)]
    qp_method=qp_sol.method;

    [lp_sol]=Simulate_Min(model,BoundedReactions,CurrentConcentrationChanges,ObjConstraintsLP,ObjConstraintsQP,qp_sol,Muscle_aa_storage,ObjProtein,...
        internal_time,previous_sol,protein_pos,qp_method,diet,WorkingDir,MinMax,step_size);
    try
        lp_sols{:,counter}=lp_sol;
    end
        if strcmp(lp_sol.statusstring,'infeasible') %| ~strcmp(solqp.statusstring,'integer optimal solution')
            infeasibility=[infeasibility;internal_time];
            lp_sol=qp_sol;
        else
            [lp_sol.statusstring,' ',num2str(lp_sol.method)]
            previous_sol=lp_sol;
        end      
        
        [muscle_glygn_amount,hep_glygn_amount,fat_tag_amount,muscle_tag_amount,CurrentConcentrationChanges,Current_aa_storage,hep_protein,muscle_protein,fat_protein]...
            = updateConcentrations(model,CurrentConcentrationChanges,muscle_glygn_amount,muscle_glygn_rxn,hep_glygn_amount,hep_glygn_rxn,fat_tag_amount,fat_tag_rxn,...
            muscle_tag_amount,muscle_tag_rxn,lp_sol,Current_aa_storage,hep_protein,muscle_protein,fat_protein,protein_pos);

        if intCounter==1
        NewResults{:,counter+1} = [Blood_Concentrations{:,2} + CurrentConcentrationChanges{:,2} ; muscle_glygn_amount;hep_glygn_amount;fat_tag_amount;...
            muscle_tag_amount;Muscle_aa_storage{:,2} + Current_aa_storage{:,2};lp_sol.x(protein_pos(1));lp_sol.x(protein_pos(2));lp_sol.x(protein_pos(3))];
        NewResults.Properties.VariableNames{counter+1}=(['Time_',strrep(num2str(internal_time),'.','_')]);

        else
            NewResults{:,counter} = [Blood_Concentrations{:,2} + CurrentConcentrationChanges{:,2} ; muscle_glygn_amount;hep_glygn_amount;fat_tag_amount;...
            muscle_tag_amount;Muscle_aa_storage{:,2} + Current_aa_storage{:,2};lp_sol.x(protein_pos(1));lp_sol.x(protein_pos(2));lp_sol.x(protein_pos(3))];
            NewResults.Properties.VariableNames{counter}=(['Time_',strrep(num2str(internal_time),'.','_')]);
  
        end
        model = updateFluxBound(model,hep_glygn_rxn,hep_glygn_amount,hep_glygn_phys_min_flux*step_size,hep_glygn_phys_max_flux*step_size,hep_glygn_maxamount);
        model = updateFluxBound(model,muscle_glygn_rxn,muscle_glygn_amount,muscle_glygn_phys_min_flux*step_size,muscle_glygn_phys_max_flux*step_size,muscle_glygn_maxamount);
        model = updateFluxBound(model,fat_tag_rxn,fat_tag_amount,fat_tag_min_flux*step_size,fat_tag_max_flux*step_size,inf);
        model = updateFluxBound(model,muscle_tag_rxn,muscle_tag_amount,-1000000,1000000,inf);

        model = updateFluxBound(model,protein_pos(1),hep_protein,-inf,inf,hep_protein_max);
        model = updateFluxBound(model,protein_pos(2),muscle_protein,-inf,inf,muscle_protein_max);
        model = updateFluxBound(model,protein_pos(3),fat_protein,-inf,inf,fat_protein_max);

    counter=counter+1;
    if mod(time,step)==0
       
        if intCounter==1
%             NewResults=array2table(NewResults);
%             NewResults.Properties.VariableNames{counter}=(['Time',strrep(num2str(internal_time),'.','_')]);
%             Results.Properties.VariableNames={'Time_0'};
%             Results=[Results,NewResults];
%             NewResults=Results;
            clear Results
        else
%             NewResults=array2table(NewResults);
        end
        save([filenameResults,num2str(intCounter)],'NewResults','lp_sols','qp_sols')

        qp_sols=cell(1,step);
        lp_sols=cell(1,step);

        NewResults=table;%(zeros(size(NewResults,1),step));
        intCounter=intCounter+1;
        counter=1;
    end
    
    
    if time==steps %&& steps>500
       qp_sols=qp_sols(~cellfun(@isempty,qp_sols));
       lp_sols=lp_sols(~cellfun(@isempty,lp_sols));
        NewResults=NewResults(:,sum(table2array(NewResults))~=0);
        save([filenameResults,num2str(intCounter)],'NewResults','lp_sols','qp_sols')
    end
end

toc
    