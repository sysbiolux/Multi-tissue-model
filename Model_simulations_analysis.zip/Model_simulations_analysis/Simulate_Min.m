% function [lp_sol,splitLP]=Simulate_LP(model,BoundedReactions,Blood_Concentrations,sol)
function [min_sol]=Simulate_Min(model,BoundedReactions,Blood_Concentrations,ObjConstraintsLP,ObjConstraintsQP,sol,Muscle_aa_storage,...
    ObjProtein,time,previous_sol,pos_protein,qp_method,diet,WorkingDir,sol_fast,step_size)

% if time==482
%     save('lp_blocking_at_482')
% end
BReactions = readtable('BoundedReactions_all.csv','delimiter',',');

Fat = BReactions{[69:71,88:127],1};%
Hep = BReactions{[66:68,168:207],1};%
Muscle = BReactions{[72:74,128:167],1};%
Co2_rxns={'Hep_co2','Muscle_co2','Fat_co2','Hep_o2','Muscle_o2','Fat_o2'};
Co2_rxns=[Co2_rxns,Fat',Hep',Muscle'];
% 'store_co2[bl]',,'store_o2[bl]'
constraints = readtable('Metabolites_fluxes_urine_excretion.csv','delimiter',';');
constraints{:,1}=strcat('Urine_excretion_',strrep(constraints{:,1},'[bl]',''));

ObjConstraints=[ObjConstraintsQP,ObjConstraintsLP,find(ismember(model.rxns,Blood_Concentrations{:,1}))',...
    find(ismember(model.rxns,[Muscle_aa_storage{:,1};Co2_rxns']))',ObjProtein',...
    find(~cellfun(@isempty,strfind(model.rxns,'secretion')))',...%find(ismember(model.rxns,BoundedReactions{:,1}))',...
    find(ismember(model.rxns,constraints{:,1}))'];
% min_model.Model.sense='minimize';
% ,pos_protein'
% changeCobraSolver('ibm_cplex','LP');
min_model = Cplex();
% min_model.Param.barrier.algorithm.Cur=1;
% splitLP.Param.emphasis.memory.Cur=1;
% splitLP.DisplayFunc=4;
min_model.Param.timelimit.Cur=60*10;
min_model.Param.barrier.algorithm.Cur=1;%remove numerical difficulties for infeasible simplex optimization
% min_model.Param.barrier.convergetol.Cur=min_model.Param.barrier.convergetol.Cur*10; %remove numerical difficulties
% min_model.Param.emphasis.numerical.Cur=1;%remove numerical difficulties
% min_model.Param.preprocessing.presolve.Cur =0; %turn off preprocessing

min_model.Model.lb = round(model.lb*step_size,4);
min_model.Model.ub = round(model.ub*step_size,4);

if time>step_size
    adjusted_rxn_fluxes = (ismember(model.rxns,{'Muscle_glygn_stores','Fat_tag_stores','Hep_glygn_stores'}));
    min_model.Model.lb(adjusted_rxn_fluxes) = round(model.lb(adjusted_rxn_fluxes),4);
    min_model.Model.ub(adjusted_rxn_fluxes) = round(model.ub(adjusted_rxn_fluxes),4);
end

min_model.Model.rhs = round(model.b,4);
min_model.Model.lhs = round(model.b,4);
min_model.Model.colname = model.rxns;
min_model.Model.rowname = model.mets;
min_model.Model.A = model.S;
min_model.Model.obj = zeros(numel(model.rxns),1);
Q = sparse(speye(numel(model.rxns)));

for j= 1 : size(BoundedReactions,1)
    rxnpos = ismember(model.rxns,BoundedReactions{j,1});
     if ~isempty(find(rxnpos,1))
%         if sol.x(rxnpos)>BoundedReactions{j,3}||sol.x(rxnpos)<BoundedReactions{j,2}
%             if sol.x(rxnpos)>=0
                min_model.Model.lb(rxnpos)=sol.x(rxnpos)*1;
                min_model.Model.ub(rxnpos)=sol.x(rxnpos)*1;
%             else
%                 min_model.Model.lb(rxnpos)=sol.x(rxnpos)*1;
%                 min_model.Model.ub(rxnpos)=sol.x(rxnpos)*1;
%             end
%         else
%             min_model.Model.lb(rxnpos)=(BoundedReactions{j,2});
%             min_model.Model.ub(rxnpos)=(BoundedReactions{j,3});
%         end
     end
end

%all constraints except bounded reactions
rxnpos = ismember(model.rxns,model.rxns(ObjConstraints)); 
min_model.Model.lb(rxnpos&sol.x(1:numel(model.rxns))>=0)=sol.x(rxnpos&sol.x(1:numel(model.rxns))>=0)*1;
min_model.Model.ub(rxnpos&sol.x(1:numel(model.rxns))>=0)=sol.x(rxnpos&sol.x(1:numel(model.rxns))>=0)*1;

min_model.Model.lb(rxnpos&sol.x(1:numel(model.rxns))<0)=sol.x(rxnpos&sol.x(1:numel(model.rxns))<0)*1;
min_model.Model.ub(rxnpos&sol.x(1:numel(model.rxns))<0)=sol.x(rxnpos&sol.x(1:numel(model.rxns))<0)*1;

min_model.DisplayFunc = [];

intracellularConstraints=[ObjConstraints,find(ismember(model.rxns,BoundedReactions{:,1}))'];

if  time>step_size
    [a]=~ismember(model.rxns,model.rxns(intracellularConstraints));
    dim_rxns=sum(a);
    A=sparse(dim_rxns,numel(min_model.Model.lb));
    min_model.addCols(zeros(dim_rxns,1),zeros(size(min_model.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
    names=strcat(model.rxns(a), '_compound_meas');
    A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
    constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
    min_model.addRows(previous_sol.x(a),constraint_matrix, previous_sol.x(a),char(names));
    pen_matrix=sparse(speye(dim_rxns));
    pen_matrix(pen_matrix==1)=0.001;
    Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)),pen_matrix];       
%         Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];   
end

if ~isempty(sol_fast)

        [a]=ismember(model.rxns,model.rxns);
        dim_rxns=sum(a);
        A=sparse(dim_rxns,numel(min_model.Model.lb));
        min_model.addCols(zeros(dim_rxns,1),zeros(size(min_model.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
        names=strcat(model.rxns(a), '_compound_meas');
        A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
        constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
        min_model.addRows(sol_fast(:,1),constraint_matrix, sol_fast(:,2),char(names));
        Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];   
end
            min_model.Model.Q = Q;


        min_sol = min_model.solve();
        NOsol=[];
        if strcmp(min_sol.statusstring,'non-optimal')
            NOsol=min_sol;
        end
        
        if (min_sol.status == 1) || (min_sol.status == 101)
%                     solfound = 1;
            return
        else 

            try
                used_method=min_sol.method;
            catch
                used_method=0;
            end
            for algo=1:4
                if algo~=used_method
                    min_model.Param.qpmethod.Cur=algo;
%                     min_model.Param.lpmethod.Cur=algo;
                    try
                        min_sol = min_model.solve();
                        if strcmp(min_sol.statusstring,'non-optimal')
                            NOsol=min_sol;
                        elseif (min_sol.status == 1) || (min_sol.status == 101)
%                     solfound = 1;
                            break
                        end
                    end
                end
                if algo==4 &&~isempty(NOsol)
%                     solfound = 1;
                    min_sol=NOsol;
%                     save(['lp_model_',strjoin(diet)])
                    break
                end
            end
        end
 
     if strcmp(min_sol.statusstring,'non-optimal') || strcmp(min_sol.statusstring,'infeasible')
        min_model.Param.barrier.convergetol.Cur=min_model.Param.barrier.convergetol.Cur*10; %remove numerical difficulties
        min_model.Param.emphasis.numerical.Cur=1;%remove numerical difficulties
        min_model.Param.preprocessing.presolve.Cur =0; %turn off preprocessing
         for algo=1:4
             try
                min_model.Param.qpmethod.Cur=algo;
                min_sol = min_model.solve();
                if (min_sol.status == 1) || (min_sol.status == 101)
                    break
                end
             catch
             end
        end
     end   
    
end

    %    pos=find(rxnpos);
    %    counter_i=1;

    %    cplex.addCols([1 1 1]', 
    %                [1 2 3;4 5 6;7 8 9], 
    %                [1 1 1]', [10 10 10]', 
    %                'IBI', ['c1';'c2';'c3']); 
    % 
    %    cplex.addRows([1 1 1]',
    %               [1 2 3;
    %                4 5 6;
    %                7 8 9],
    %               [10 20 30]',
    %               ['r1';'r2';'r3']);
    %    tic