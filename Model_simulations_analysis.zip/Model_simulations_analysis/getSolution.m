function sol=getSolution%(type_of_diet)

type_of_diet={'Milan_young_LF'}; %wph pph ms
load (['Results_',strjoin(type_of_diet),'_healthy'],'lpsol','Results')
lpsol_LF=lpsol;
try
    load Infeasibility_Milan_young_LF_healthy
    infeasi=infeasibility;
catch
    infeasi=0;
end


try
    load Infeasibility_no_food_healthy
    infeasibility=unique([infeasi,infeasibility]);
catch
    infeasibility=unique(infeasi);
end
type_of_diet={'no_food'}; %wph pph ms
load (['Results_',strjoin(type_of_diet),'_healthy'],'lpsol','Results')
lpsol_fast=lpsol;


try
    load Infeasibility_Milan_young_HF_healthy
    infeasibility=unique([infeasi,infeasibility]);
catch
    infeasibility=unique(infeasi);
end
type_of_diet={'Milan_young_HF'}; %wph pph ms
load (['Results_',strjoin(type_of_diet),'_healthy'],'lpsol','Results')
lpsol_HF=lpsol;


sol=zeros(numel(lpsol_LF{1}.x),size(Results,2)-1);
try
    for i=1:360
        if i~=infeasibility
            sol(1:numel(lpsol_fast{i}.x),i)=lpsol_fast{i}.x;
            sol(:,i+size(Results,2)-1)=lpsol_LF{i}.x;
            sol(:,i+size(Results,2)+size(Results,2)-2)=lpsol_HF{i}.x;
        end
    end
catch
  for i=1:size(Results,2)-1
      if i~=infeasibility
            sol(1:numel(lpsol_fast{i}.x),i)=lpsol_fast{i}.x;
            sol(:,i+size(Results,2)-1)=lpsol_LF{i}.x;
            sol(:,i+size(Results,2)+size(Results,2)-2)=lpsol_HF{i}.x;
      end
  end  
end
