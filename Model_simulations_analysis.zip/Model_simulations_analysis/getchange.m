function dxdt = getchange(currentval, initialval, t_max_new,step_size)

%With the change function x'(t) = - (t * x(0) * e^(-t/tmax)) / tmax^2 we obtain the
%integral as:
% x(t) = x(0) * (tmax + t) * e^(-t/tmax) / tmax
% We can rearrange the function (getting all ts to one side:
% x(t)*tmax / x(0) = tmax * e^(-t/tmax) + t * e^(-t/tmax) for t
% and calc res = x(t)*tmax/x(0)
res = currentval * t_max_new / initialval;

%Now we can solve:
% res = tmax * e^(-t/tmax) + t * e^(-t/tmax) for t
% which yields -tmax * (lambertw(-(res/(tmax*e)))+1)
% There are potentially two real solutions which are either lambertw(0,val) 
% or lambertw(-1,val), and we have to pick the one with x > 0!
% As our function is monotonous for t > 0 this can be achieved as:
newt1 =real( -t_max_new * (lambertw(0,-(res/(t_max_new*exp(1))))+1));
if newt1>= 0
    newt = newt1;
else
    newt =real(-t_max_new * (lambertw(-1,-(res/(t_max_new*exp(1))))+1));

end

% now we can calculate the new change as:
% old_x(t) - x(newt+1);
newval = initialval * (t_max_new + newt+step_size) * exp(-(newt+step_size)/t_max_new) / t_max_new;
dxdt = currentval - newval;