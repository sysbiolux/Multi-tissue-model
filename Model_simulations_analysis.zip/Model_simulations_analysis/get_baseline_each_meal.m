function [new_baseline_blood,IEMS_KO]=get_baseline_each_meal

Hep_store_protein=7.9365e+05;
Muscle_store_protein=4.7619e+07;
Fat_store_protein=79365;

type_of_diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms
meal=1;
load(['Results_',strjoin(type_of_diet(meal)),'_healthy'],'Results','qpsol','model');
Results_H=Results;

new_baseline_blood=zeros(size(Results_H(:,1)));

IEMS_KO={};
IEMS_files=dir('*LF_IEM_KD_fraction*.mat');
for r=1:size(IEMS_files,1)
    IEMS_KO{r,1}=(IEMS_files(r).name);
end
IEMS_KO=IEMS_KO(~cellfun(@isempty,strfind(IEMS_KO,'Results')));
IEMS_KO=strrep(strrep(IEMS_KO,'Results_Milan_young_LF_IEM_KD_fraction_0_',''),'.mat','');
for meal=1:3
    load(['Results_',strjoin(type_of_diet(meal)),'_healthy'],'Results','qpsol','model');
    Results_H=Results;

    for count=1:size(Results_H,2)
        if count==1
            Results_H{end-2:end,count}=Results_H{end-2:end,count}+[Hep_store_protein;Muscle_store_protein;Fat_store_protein];
        else
            Results_H{end-2:end,count}=Results_H{end-2:end,count-1}+Results_H{end-2:end,count};
        end
    end
    qpsol_H=qpsol;

    urine_fluxes=readtable('Metabolites_fluxes_urine_excretion.csv','Delimiter',';','ReadRowNames',1);
    blood_conc=readtable('Blood_concentrations_updated.csv','Delimiter',';','ReadRowNames',1);
    blood_conc=blood_conc(ismember(blood_conc.Properties.RowNames,model.rxns),:);
    num_blood_mets=size(blood_conc,1);
    Healthy_min=blood_conc{:,2};
    Healthy_max=blood_conc{:,3};

    urine_rxns=strfind(model.rxns,'Urine_excretion');
    urine_rxns=~cellfun(@isempty,urine_rxns);

    % new_baseline_blood=zeros(size(Results_H(:,1)));
    % new_baseline_urine=zeros(sum(urine_rxns),1);

    time_healthy=size(Results_H,2)-1;
    
    tag_healthy=1;
    for i=1:100%:size(IEMS_KO,1)
%         try
            load(['Results_',strjoin(type_of_diet(meal)),'_healthy_',num2str(i),'.mat'],'Results','qpsol')
            time_IEM=size(Results,2)-1;
            min_time=min(time_healthy,time_IEM);
            Results_healthy=Results_H(:,1:min_time+1);
            y_healthy=Results_healthy{:,:};
            
            Results_IEM=Results(:,1:min_time+1);
    %         qpsol_IEM=qpsol(:,1:min_time);
    % 
            for count=1:size(Results_IEM,2)
                if count==1
                    Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count}+[Hep_store_protein;Muscle_store_protein;Fat_store_protein];
                else
                    Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count-1}+Results_IEM{end-2:end,count};
                end
            end

            clear qpsol
            clear Results

            y_IEM=Results_IEM{:,:};             
            x=1:min_time+1;
            if tag_healthy==1
                tag_healthy=0;
                new_baseline_blood=min(new_baseline_blood,min(y_healthy,[],2));
            end

            new_baseline_blood=min(new_baseline_blood,min(y_IEM,[],2));
%         end
    end
    
      for i=1:size(IEMS_KO,1)
%         try
            load(['Results_',strjoin(type_of_diet(meal)),'_IEM_KD_fraction_0_',strjoin(IEMS_KO(i)),'.mat'],'Results','qpsol')
            time_IEM=size(Results,2)-1;
            min_time=min(time_healthy,time_IEM);

            Results_IEM=Results(:,1:min_time+1);
    %         qpsol_IEM=qpsol(:,1:min_time);
    % 
            for count=1:size(Results_IEM,2)
                if count==1
                    Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count}+[Hep_store_protein;Muscle_store_protein;Fat_store_protein];
                else
                    Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count-1}+Results_IEM{end-2:end,count};
                end
            end

            clear qpsol
            clear Results

            y_IEM=Results_IEM{:,:};             

            new_baseline_blood=min(new_baseline_blood,min(y_IEM,[],2));
%         end
    end
end
save('New_baseline_blood','IEMS_KO','new_baseline_blood')