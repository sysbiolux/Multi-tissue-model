function model = updateFluxBound(model,RxnPos,Amount,minlower,maxupper,maxamount)
%update a flux bound given a model, the position of the bound to change given some properties
% Amount - the current amount (the flux cannot be smaller than the negative amount)
% minlower - the minimal flux bound i.e. the maximum rate of usage
% maxupper - the maximal flux bound, i.e. the maximal rate of production.
% maxamount - the maximal amount that can be stored. the flux cannot be higher than maxamount - Amount
% new_rate=sol.x(RxnPos);
model.lb(RxnPos) = max([-Amount,minlower]);
if maxamount - Amount<0
    model.ub(RxnPos)=0;
else
    model.ub(RxnPos) = min([maxamount - Amount,maxupper]);
end

% if new_rate>=0
%     model.lb(RxnPos)=model.lb(RxnPos)*0.5;
% else
%     model.ub(RxnPos)=model.ub(RxnPos)*0.5;
% end