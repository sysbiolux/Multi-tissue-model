function simulate_mixed_conditions(meal,exp_final,tag,step_size)
for exp=1:exp_final
%     meal=1;
    WorkingDir=pwd;
%     tag=1;
    type_of_diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms

    model= SetupModel();

    params=getParams(meal);


%     tag=1;

    if tag==1
        simTime=1000;%2*24*60; %fasting 1.5 day and Low fat meal 
        FoodApplicationTime=12*60;%1.5*24
        ExerciseIntensity=10;
        ExerciseStartingTime=simTime+10;
        ExerciseStoppingTime=simTime+20;
        [infeasibility,intCounter] = simulateQP_mixed(model,simTime,params,WorkingDir,...
            FoodApplicationTime,ExerciseIntensity,ExerciseStoppingTime,ExerciseStartingTime,tag,'',meal,'','',step_size);
    elseif tag==2 %starvation 3 days
        simTime=3*24*60;
        FoodApplicationTime=simTime+10;
        ExerciseIntensity=10;
        ExerciseStartingTime=simTime+10;
        ExerciseStoppingTime=simTime+20;
        [infeasibility,intCounter] = simulateQP_mixed(model,simTime,params,WorkingDir,...
            FoodApplicationTime,ExerciseIntensity,ExerciseStoppingTime,ExerciseStartingTime,tag,'',meal,'','',step_size);
    elseif tag==3 %exercise
    %     exp=1;
        simTime=1000;
        if exp==1 %12h fast ---- 40% O2Max 90 min ---- 3h rest  => 990 min
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=17.67;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+90;
        elseif exp==2 %12h fast ---- 60% O2Max 60 min ---- 3h rest  => 960 min
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=27;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+60;
        elseif exp==3 %12h fast ---- 50% O2Max 5 min ----- 70% O2Max 1h55 ---- 30 min rest---- 70% O2Max 10 min ----- 80% O2Max 10 min ---- 90% O2Max 10 min
        %900 min 
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=22.33;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+5;
        elseif exp==4 %12h fast ---- 55% O2Max 60 min ---- 30min rest---- Meal ---- 150min rest => 960 min
            ExerciseIntensity=24.67;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+60;
            FoodApplicationTime=ExerciseStoppingTime+30;
        elseif exp==5 %12h fast ---- Meal ---- 60 min rest ---- 55% O2Max 60 min ---- 180 min rest => 1020 min
            FoodApplicationTime=12*60;
            ExerciseIntensity=24.67;
            ExerciseStartingTime=FoodApplicationTime+60;
            ExerciseStoppingTime=ExerciseStartingTime+60;
            
        elseif exp==6 %12h fast ---- 55% O2Max 60 min ----  => 1020 min
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=24.67;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+60;         
        elseif exp==7 %12h fast ---- 50% O2Max 20 min ----  => 800 min
            simTime=720+40;
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=22.33;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+20;
        elseif exp==8 %12h fast ---- 70% O2Max 20 min ----  => 800 min
            simTime=720+40;
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=31.67;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+20;
        elseif exp==9 %12h fast ---- 80% O2Max 20 min ----  => 800 min
            simTime=720+40;
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=36.33;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+20;
        elseif exp==10 %12h fast ---- 90% O2Max 20 min ----  => 800 min
            simTime=720+40;
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=41;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+20;
        elseif exp==11 %12h fast ---- 65% O2Max 240 min ----  => 800 min
            simTime=720+240;
            FoodApplicationTime=simTime+10;
            ExerciseIntensity=29.33;
            ExerciseStartingTime=12*60;
            ExerciseStoppingTime=ExerciseStartingTime+250;
        end  
        [infeasibility,intCounter] = simulateQP_mixed(model,simTime,params,WorkingDir,...
        FoodApplicationTime,ExerciseIntensity,ExerciseStoppingTime,ExerciseStartingTime,tag,exp,meal,'','',step_size);
    end


    if tag==1
        filenameResults='CurrentResultsFood';
     elseif tag==2
        filenameResults='CurrentResults';
     elseif tag==3
        filenameResults='CurrentResultsExerc';
     elseif tag==4
        filenameResults='CurrentResultsShortSim';
    elseif tag==5
        filenameResults='CurrentResultsLowKo';
    end

     final_lp=[];
     final_qp=[];
     final_res=[];
    for ic=1:intCounter%-1
        load([filenameResults,num2str(ic)])
        final_lp=[final_lp,lp_sols];
        final_qp=[final_qp,qp_sols];
        final_res=[final_res,NewResults];
    end
    lp_sols=final_lp;
    clear final_lp
    qp_sols=final_qp;
    clear final_qp
    Results=final_res;
    clear final_res
    clear NewResults

    if tag==1
      save([WorkingDir filesep ['Results_healthy_mixed_conditions_',strjoin(type_of_diet(meal)),'.mat']])

      if ~isempty(infeasibility)
                save(['Infeasibility_healthy_mixed_conditions_',strjoin(type_of_diet(meal)),'.mat'],'infeasibility')
      end
    elseif tag==2
        save([WorkingDir filesep 'Results_healthy_starvation.mat'])

      if ~isempty(infeasibility)
                save(['Infeasibility_healthy_starvation.mat'],'infeasibility')
      end

    elseif tag==3
      save([WorkingDir filesep 'Results_healthy_exercise_sim_',num2str(exp),'_',strjoin(type_of_diet(meal)),'.mat'])

      if ~isempty(infeasibility)
                save(['Infeasibility_healthy_exercise_sim_',num2str(exp),'_',strjoin(type_of_diet(meal)),'.mat'],'infeasibility')
      end
      
    
    
    elseif tag==4
      save([WorkingDir filesep 'Results_healthy_',strjoin(type_of_diet(meal)),'.mat'])

      if ~isempty(infeasibility)
                save(['Infeasibility_healthy_',strjoin(type_of_diet(meal)),'.mat'],'infeasibility')
      end
      
    
    
    elseif tag==5
%       save([WorkingDir filesep 'Results_healthy_exercise_sim_',num2str(exp),'.mat'])
% 
%       if ~isempty(infeasibility)
%                 save(['Infeasibility_healthy_exercise_sim_',num2str(exp),'.mat'],'infeasibility')
%       end
    end  
    
    clearvars -except meal tag exp_final exp step_size;clc
end
