function tag=checkrange(up,down)
tag=zeros(numel(down),1);
tag(up&~down)=1;
tag(up&down)=2;
tag(~up&down)=-1;
end