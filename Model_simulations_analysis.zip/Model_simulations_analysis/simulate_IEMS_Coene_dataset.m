function simulate_IEMS_Coene_dataset(WorkingDir,a)
step_size=1;
% persistent model_KO
% persistent sol
% persistent params
% persistent model
% persistent IEMS_KO
% persistent list_IEMS_effect
% persistent type_of_diet
% persistent res
% cluster=parpool('local',3);
% cluster = parcluster();

% cluster.JobStorageLocation = WorkingDir;
% load IEMS_results
% load('IEMS_mapped')
list_IEMS_effect=readtable('Coene_IEMs.csv','ReadVariableNames',false);
individual_models=0;
try
    clear Res_mapped
    clear Res_mapped_not_mito
end

% data=readtable('literature_biomarkers_IEMbase_urine_plasma_0_5.csv','Delimiter',',','ReadVariableNames',0);
% 
% data_val=readtable('literature_biomarkers_IEMbase_urine_plasma_0_validation_set.csv','Delimiter',',','ReadVariableNames',0);
% data_val{:,1}=strrep(strrep(strrep(data_val{:,1},' ','_'),'/','_'),':','_');
% data=[data;data_val];
IEMS_KO=strrep(list_IEMS_effect{:,8:end},'"','');
list_IEMS_effect=list_IEMS_effect(:,2);
list_IEMS_effect=strrep(strrep(list_IEMS_effect{:,1},' ','_'),'-','_');

% type_of_diet={'no_food'}; %wph pph ms
% type_of_diet={'Milan_young_LF'}; %wph pph ms
% load (['Results_',strjoin(type_of_diet),'_healthy'],'model')
diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms
type_of_diet=diet(a);
% type_of_diet={'no_food'}; %wph pph ms
% load (['Results_',strjoin(type_of_diet),'_healthy'],'model')

sol=getSolution;%(type_of_diet);
params=getParams(a);
model=SetupModel();
model_KO=model;
% model_KO=changeRxnBounds(model_KO,{'Hep_glyb'},-1000000,'l');
% model_KO.rev(ismember(model_KO.rxns,'Hep_glyb'))=1;
% model_KO.rxns(ismember(model_KO.rxns,'Hep_GLYBt4_2_r_secretion'))={'Hep_GLYBt4_2_r'};

KO=0;
for i=1:size(IEMS_KO,1)

        not_empty=~cellfun(@isempty,IEMS_KO(i,:));
        geneKO=IEMS_KO(i,not_empty);
        disease=list_IEMS_effect(i,1);
%         if sum(ismember(data{:,1},strrep(strrep(strrep(disease,' ','_'),'/','_'),':','_')))>0
            run_simulation(geneKO,disease,sol,model,model_KO,params,WorkingDir,type_of_diet,KO,individual_models,step_size);
%         end
end

% KO=0.5;
% for i=1:size(IEMS_KO,1)
% 
%         not_empty=~cellfun(@isempty,IEMS_KO(i,:));
%         geneKO=IEMS_KO(i,not_empty);
%         disease=list_IEMS_effect{i,1};
% %         if sum(ismember(data{:,1},strrep(strrep(strrep(disease,' ','_'),'/','_'),':','_')))>0
%             run_simulation(geneKO,disease,sol,model,model_KO,params,WorkingDir,type_of_diet,KO);
% %         end
% end

end

function run_simulation(geneKO,disease,sol,model,model_to_change,params,WorkingDir,type_of_diet,KO,individual_models,step_size)
    % type_of_diet={'Milan_young_LF'}; %wph pph ms
    % type_of_diet={'no_food'}; %wph pph ms

    if ~exist(['Results_',strjoin(type_of_diet),'_IEM_KD_fraction_',num2str(KO),'_',strjoin(strrep(strrep(strrep(disease,' ','_'),'/','_'),':','_')),'.mat'],'file')
        disease
        model_KO=model_to_change;
        [~,~,rxnKO] = deleteModelGenes(model,geneKO);
        if isempty(rxnKO)
           warning(['No effect of ',strjoin((geneKO),' '),' on model'])
           return
        end

        posKO=find(ismember(model.rxns,rxnKO));
        sol_pos=sol(posKO,:);
        bound = max(abs(sol_pos),[],2);

        KObound=abs(bound*KO);
        model_healthy=model;
        %IEM
        model_KO=changeRxnBounds(model_KO,model_healthy.rxns(posKO),KObound,'u');
        model_KO=changeRxnBounds(model_KO,model_healthy.rxns(posKO),-KObound.*model_healthy.rev(posKO),'l');
       
        [Results,qpsol,lpsol,infeasibility] = simulateQP_modified(model_KO,360,type_of_diet,params,WorkingDir,individual_models,step_size);
%         try
            save(['Results_',strjoin(type_of_diet),'_IEM_KD_fraction_',num2str(KO),'_',strjoin(strrep(strrep(strrep(disease,' ','_'),'/','_'),':','_')),'.mat'])
            
        if ~isempty(infeasibility)
            save(['Infeasibility_',strjoin(type_of_diet),'_IEM_KD_fraction_',num2str(KO),'_',strjoin(strrep(strrep(strrep(disease,' ','_'),'/','_'),':','_')),'.mat'],'infeasibility')
        end

    end
end
