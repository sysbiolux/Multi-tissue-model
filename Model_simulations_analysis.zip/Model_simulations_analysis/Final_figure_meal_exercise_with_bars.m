clearvars;clc;
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');

load('Results_healthy_exercise_sim_4_Milan_young_LF.mat')

res_sol_1=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_1(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime1=ExerciseStartingTime;
   ExerciseStoppingTime1=ExerciseStoppingTime;
    FoodApplicationTime1=FoodApplicationTime;
    Results_1=Results;
    clear Results qp_sols lp_sols FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
     
    load('Results_healthy_exercise_sim_5_Milan_young_LF.mat')

    res_sol_2=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_2(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime2=ExerciseStartingTime;
   ExerciseStoppingTime2=ExerciseStoppingTime;
   FoodApplicationTime2=FoodApplicationTime;
    Results_2=Results;

    clear Results qp_sols lp_sols  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

    
     load('Results_healthy_mixed_conditions_Milan_young_LF.mat')

    res_sol_Meal=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_Meal(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime_Meal=ExerciseStartingTime;
   ExerciseStoppingTime_Meal=ExerciseStoppingTime;
   FoodApplicationTime_Meal=FoodApplicationTime;
    Results_Meal=Results;

    clear Results qp_sols lp_sols  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
   
%%
rxns={'Muscle_glc_D';'Muscle_tag_hs';'Muscle_fa';'Fat_glyc';'Foxid';'Goxid';'Muscle_glygn_stores';...
    'Fat_tag_stores';'Hep_glygn_stores';};%;'Fat_Rtotal2';'Fat_Rtotal3'};

nrows = 3;
ncols = 3;
labels={'Muscle: Glucose uptake','Muscle: TAG uptake','Muscle: Fatty acids uptake','Adip. Tissue: Glycerol secretion',...
    'WModel: Fatty acid oxidation','WModel: Glucose oxidation','Muscle: Glycogen usage','Adip. Tissue: TAG usage','Liver: Glycogen usage'};

 for r= 1 : numel(rxns)
    if nrows*ncols-mod(-r, nrows*ncols) == 1
        fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%         H=suptitle(['Simulation of Exercise with Meal']);
%         set(H,'FontSize',20,'Position',[0.5,-0.02,0])
    end
    subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
    hold on
    
    if strcmp(rxns(r),'Muscle_fa')
           Muscle = BoundedReactions{[72:74,128:167],1};%
           Muscle=Muscle(ismember(Muscle,model.rxns));
           pos=ismember(model.rxns,Muscle(:,1));
           vector1=sum(res_sol_1(pos,ExerciseStartingTime1-120:end));
           vector2=sum(res_sol_2(pos,FoodApplicationTime2-60:end));
           vector3=sum(res_sol_Meal(pos,FoodApplicationTime2-60:end));
%            rxns{r}='Muscle Fatty acids';
           clear pos       
    elseif strcmp(rxns(r),'Foxid')
                fa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'coa['))&cellfun(@isempty,strfind(model.mets,'_coa['))&...
        cellfun(@isempty,strfind(model.mets,'_accoa['))&cellfun(@isempty,strfind(model.mets,'[x]'))&~cellfun(@isempty,strfind(model.mets,'[m]'))));
        accoa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'accoa['))));
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX'))&~cellfun(@isempty,strfind(rxns_fox,'Muscle')));
        rxns_fox_sup={'Muscle_ACACT10m';'Muscle_MCDm';'Muscle_r0287';'Muscle_r0639';'Muscle_r0653';'Muscle_r0732';'Muscle_RE1533M';'Muscle_RE3006M';'Muscle_r0724'};
        rxns_fox=[rxns_fox;rxns_fox_sup];
        pos=ismember(model.rxns,rxns_fox);
        pos_met=ismember(model.mets,'Muscle_accoa[m]');
        coef=full(model.S(pos_met,pos));
        vector1_muscle=sum(abs(bsxfun(@times,coef',res_sol_1(pos,ExerciseStartingTime1-120:end))));%/sum(pos);
        vector2_muscle=sum(abs(bsxfun(@times,coef',res_sol_2(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        vector3_muscle=sum(abs(bsxfun(@times,coef',res_sol_Meal(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        
        
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX'))&~cellfun(@isempty,strfind(rxns_fox,'Hep')));
        rxns_fox_sup={'Hep_ACACT10m';'Hep_MCDm';'Hep_r0287';'Hep_r0639';'Hep_r0653';'Hep_r0732';'Hep_RE1533M';'Hep_RE3006M';'Hep_r0724'};
        rxns_fox=[rxns_fox;rxns_fox_sup];
        pos=ismember(model.rxns,rxns_fox);
        pos_met=ismember(model.mets,'Hep_accoa[m]');
        coef=full(model.S(pos_met,pos));
        vector1_Hep=sum(abs(bsxfun(@times,coef',res_sol_1(pos,ExerciseStartingTime1-120:end))));%/sum(pos);
        vector2_Hep=sum(abs(bsxfun(@times,coef',res_sol_2(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        vector3_Hep=sum(abs(bsxfun(@times,coef',res_sol_Meal(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX'))&~cellfun(@isempty,strfind(rxns_fox,'Fat')));
        rxns_fox_sup={'Fat_ACACT10m';'Fat_MCDm';'Fat_r0287';'Fat_r0639';'Fat_r0653';'Fat_r0732';'Fat_RE1533M';'Fat_RE3006M';'Fat_r0724'};
        rxns_fox=[rxns_fox;rxns_fox_sup];
        pos=ismember(model.rxns,rxns_fox);
        pos_met=ismember(model.mets,'Fat_accoa[m]');
        coef=full(model.S(pos_met,pos));
        vector1_Fat=sum(abs(bsxfun(@times,coef',res_sol_1(pos,ExerciseStartingTime1-120:end))));%/sum(pos);
        vector2_Fat=sum(abs(bsxfun(@times,coef',res_sol_2(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        vector3_Fat=sum(abs(bsxfun(@times,coef',res_sol_Meal(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        
        vector1=vector1_Fat+vector1_Hep+vector1_muscle;
        vector2=vector2_Fat+vector2_Hep+vector2_muscle;
        vector3=vector3_Fat+vector3_Hep+vector3_muscle;
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    elseif strcmp(rxns(r),'Goxid')
           pos=ismember(model.rxns,{'Hep_PDHm';'Muscle_PDHm';'Fat_PDHm';});
           vector1=sum(abs(res_sol_1(pos,ExerciseStartingTime1-120:end)));%/sum(pos);
           vector2=sum(abs(res_sol_2(pos,FoodApplicationTime2-60:end)));%/sum(pos);
           vector3=sum(abs(res_sol_Meal(pos,FoodApplicationTime2-60:end)));%/sum(pos);
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    else
        pos=ismember(model.rxns,rxns(r));
        vector1=(res_sol_1(pos,ExerciseStartingTime1-120:end));
        vector2=(res_sol_2(pos,FoodApplicationTime2-60:end));
        vector3=(res_sol_Meal(pos,FoodApplicationTime2-60:end));
        clear pos
    end
    
    MIN=min([vector1,vector2,vector3]);
    MAX=max([vector1,vector2,vector3]);
    
    if MIN==MAX
       MIN=MIN-1;
       MAX=MAX+1;
    end
    x11 = [ExerciseStartingTime2-ExerciseStartingTime2:ExerciseStoppingTime2-ExerciseStartingTime2];
    x12=flip(x11);
    y11 = repmat(MAX,1,numel(x11));
    y12 = repmat(MIN,1,numel(x11));

    y1=[y11 ,y12];
    x1=[x11, x12];

    a1=patch(x1,y1,'b');
    Darkgrey=[242 242 242]/256;

    set(a1,'FaceColor',Darkgrey)
    set(a1,'EdgeColor',Darkgrey)
   
    plot([-120:220],vector3,'k','LineWidth',3)
    plot([-120:220],vector2,'r--','LineWidth',2)
    plot([-120:280],vector1,'b:','LineWidth',2)

    [lims]=get(gca,{'XLim','YLim'});

    x1=FoodApplicationTime_Meal-ExerciseStartingTime2;
    x2=FoodApplicationTime1-ExerciseStartingTime1;
    
    minVec=min([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);
    maxVec=max([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);

    coef_norm=((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100))^1.1+1;
%     [((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5)^1.2,(abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5+1]
    if abs(MAX-maxVec)>abs(MIN-minVec)
        if (MAX-maxVec)>30
            y1=maxVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')   
        else
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E')
        end

    else
        if abs(MIN-minVec)>30
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E') 
        else
            y1=minVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')  
        end
    end

    minVec=min([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);
    maxVec=max([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);

    if abs((MAX-maxVec))>abs((MIN-minVec)) 
        if (MAX-maxVec)>30
            y2=maxVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        else
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        end

    else
        if abs(MIN-minVec)>30
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        else
            y2=minVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        end
    end
    
    plot([FoodApplicationTime_Meal-ExerciseStartingTime2],[MIN],'ko','MarkerFaceColor','k','MarkerSize',5)
%     plot([FoodApplicationTime2-ExerciseStartingTime2],[lims{2}(2)],'ro','MarkerFaceColor','r','MarkerSize',5)
    plot([FoodApplicationTime1-ExerciseStartingTime1],[MIN],'bo','MarkerFaceColor','b','MarkerSize',5)
         
    ylabel([labels(r), '[\mumol/min]'],'FontSize',12)
    xlabel('Time [min]','FontSize',12)
    
    xlim([-90,220])
    ylim([MIN,MAX])

    hold off
 end
L=legend('Exercise: M->E and E->M','M->R','M->E','E->M','Meal: M->R and Meal M->E','Meal E->M');
% L.FontSize=13;

fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 25 20];
% saveas(fig1,'Fluxes_exerc_vs_meal_LF.svg')
%%

nrows = 2;
ncols = 2;
labels={'Liver: glycogen amount','Muscle: glycogen amount','Adipose Tissue: TAG amount','Muscle: TAG amount'};
rxns={'Liver_glycogen','Muscle_glycogen','Fat_TAG','Muscle_TAG'};%'Hep_tag_stores',
 for r= 1 : numel(rxns)
        if nrows*ncols-mod(-r, nrows*ncols) == 1
            fig=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%             H=suptitle(['Simulation of Exercise 4&5']);
%             set(H,'FontSize',20,'Position',[0.5,-0.02,0])
        end
        subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
       hold on
      
       pos=ismember(Results_1.Properties.RowNames,rxns(r));

       vector1=Results_Meal{pos,FoodApplicationTime2-60:end}/5;%+diff_met)
       vector2=Results_2{pos,FoodApplicationTime2-60:end}/5;%+diff_met)
       vector3=Results_1{pos,ExerciseStartingTime1-120:end}/5;%+diff_met)
       
    MIN=min([vector1,vector2,vector3]);
    MAX=max([vector1,vector2,vector3]);
    
    if MIN==MAX
       MIN=MIN-1;
       MAX=MAX+1;
    end
    x11 = [ExerciseStartingTime2-ExerciseStartingTime2:ExerciseStoppingTime2-ExerciseStartingTime2];
    x12=flip(x11);
    y11 = repmat(MAX,1,numel(x11));
    y12 = repmat(MIN,1,numel(x11));

    y1=[y11 ,y12];
    x1=[x11, x12];

    a1=patch(x1,y1,'b');
    Darkgrey=[242 242 242]/256;

    set(a1,'FaceColor',Darkgrey)
    set(a1,'EdgeColor',Darkgrey)
   
    plot([-120:221],vector1,'k','LineWidth',3)
    plot([-120:221],vector2,'r--','LineWidth',2)
    plot([-120:281],vector3,'b:','LineWidth',2)
       
   [lims]=get(gca,{'XLim','YLim'});

    x1=FoodApplicationTime_Meal-ExerciseStartingTime2;
    x2=FoodApplicationTime1-ExerciseStartingTime1;
    
    minVec=min([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);
    maxVec=max([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);

    coef_norm=((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100))^1.1+1;
%     [((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5)^1.2,(abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5+1]
    if abs(MAX-maxVec)>abs(MIN-minVec)
        if (MAX-maxVec)>30
            y1=maxVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')   
        else
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E')
        end

    else
        if abs(MIN-minVec)>30
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E') 
        else
            y1=minVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')  
        end
    end

    minVec=min([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);
    maxVec=max([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);

    if abs((MAX-maxVec))>abs((MIN-minVec)) 
        if (MAX-maxVec)>30
            y2=maxVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        else
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        end

    else
        if abs(MIN-minVec)>30
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        else
            y2=minVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        end
    end
    
    plot([FoodApplicationTime_Meal-ExerciseStartingTime2],[MIN],'ko','MarkerFaceColor','k','MarkerSize',5)
%     plot([FoodApplicationTime2-ExerciseStartingTime2],[lims{2}(2)],'ro','MarkerFaceColor','r','MarkerSize',5)
    plot([FoodApplicationTime1-ExerciseStartingTime1],[MIN],'bo','MarkerFaceColor','b','MarkerSize',5)
         
    ylabel([labels(r), '[\mumol/min]'],'FontSize',12)
    xlabel('Time [min]','FontSize',12)
    
    xlim([-90,220])
    ylim([MIN,MAX])
 end
 
fig.PaperUnits = 'centimeters';
fig.PaperPosition = [0 0 20 15];

% L=legend('M->R','M->E','E->M','Meal StartT M->R','Meal StartT M->E','Meal StartT E->M','Exercise StartT M->E','Exercise StopT M->E',...
% 'Exercise StartT E->M','Exercise StopT E->M');
% L.FontSize=16;

% saveas(fig,'Stores_exerc_vs_meal_LF.svg')
% legend('M->R','M->E','E->M','Meal StartT M->R','Meal StartT M->E','Meal StartT E->M','Exercise StartT M->E','Exercise StopT M->E',...
% 'Exercise StartT E->M','Exercise StopT E->M')
%%
clearvars;clc;
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');

load('Results_healthy_exercise_sim_4_Milan_young_HF.mat')

res_sol_1=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_1(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime1=ExerciseStartingTime;
   ExerciseStoppingTime1=ExerciseStoppingTime;
    FoodApplicationTime1=FoodApplicationTime;
    Results_1=Results;
    clear Results qp_sols lp_sols FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
     
    load('Results_healthy_exercise_sim_5_Milan_young_HF.mat')

    res_sol_2=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_2(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime2=ExerciseStartingTime;
   ExerciseStoppingTime2=ExerciseStoppingTime;
   FoodApplicationTime2=FoodApplicationTime;
    Results_2=Results;

    clear Results qp_sols lp_sols  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

    
     load('Results_healthy_mixed_conditions_Milan_young_HF.mat')

    res_sol_Meal=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_Meal(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime_Meal=ExerciseStartingTime;
   ExerciseStoppingTime_Meal=ExerciseStoppingTime;
   FoodApplicationTime_Meal=FoodApplicationTime;
    Results_Meal=Results;

    clear Results qp_sols lp_sols  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
   
%%
rxns={'Muscle_glc_D';'Muscle_tag_hs';'Muscle_fa';'Fat_glyc';'Foxid';'Goxid';'Muscle_glygn_stores';...
    'Fat_tag_stores';'Hep_glygn_stores';};%;'Fat_Rtotal2';'Fat_Rtotal3'};

nrows = 3;
ncols = 3;
labels={'Muscle: Glucose uptake','Muscle: TAG uptake','Muscle: Fatty acids uptake','Adip. Tissue: Glycerol secretion',...
    'WModel: Fatty acid oxidation','WModel: Glucose oxidation','Muscle: Glycogen usage','Adip. Tissue: TAG usage','Liver: Glycogen usage'};

for r= 1 : numel(rxns)
    if nrows*ncols-mod(-r, nrows*ncols) == 1
        fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%         H=suptitle(['Simulation of Exercise with Meal']);
%         set(H,'FontSize',20,'Position',[0.5,-0.02,0])
    end
    subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
    hold on
    
    if strcmp(rxns(r),'Muscle_fa')
           Muscle = BoundedReactions{[72:74,128:167],1};%
           Muscle=Muscle(ismember(Muscle,model.rxns));
           pos=ismember(model.rxns,Muscle(:,1));
           vector1=sum(res_sol_1(pos,ExerciseStartingTime1-120:end));
           vector2=sum(res_sol_2(pos,FoodApplicationTime2-60:end));
           vector3=sum(res_sol_Meal(pos,FoodApplicationTime2-60:end));
%            rxns{r}='Muscle Fatty acids';
           clear pos       
    elseif strcmp(rxns(r),'Foxid')
                fa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'coa['))&cellfun(@isempty,strfind(model.mets,'_coa['))&...
        cellfun(@isempty,strfind(model.mets,'_accoa['))&cellfun(@isempty,strfind(model.mets,'[x]'))&~cellfun(@isempty,strfind(model.mets,'[m]'))));
        accoa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'accoa['))));
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX'))&~cellfun(@isempty,strfind(rxns_fox,'Muscle')));
        rxns_fox_sup={'Muscle_ACACT10m';'Muscle_MCDm';'Muscle_r0287';'Muscle_r0639';'Muscle_r0653';'Muscle_r0732';'Muscle_RE1533M';'Muscle_RE3006M';'Muscle_r0724'};
        rxns_fox=[rxns_fox;rxns_fox_sup];
        pos=ismember(model.rxns,rxns_fox);
        pos_met=ismember(model.mets,'Muscle_accoa[m]');
        coef=full(model.S(pos_met,pos));
        vector1_muscle=sum(abs(bsxfun(@times,coef',res_sol_1(pos,ExerciseStartingTime1-120:end))));%/sum(pos);
        vector2_muscle=sum(abs(bsxfun(@times,coef',res_sol_2(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        vector3_muscle=sum(abs(bsxfun(@times,coef',res_sol_Meal(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        
        
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX'))&~cellfun(@isempty,strfind(rxns_fox,'Hep')));
        rxns_fox_sup={'Hep_ACACT10m';'Hep_MCDm';'Hep_r0287';'Hep_r0639';'Hep_r0653';'Hep_r0732';'Hep_RE1533M';'Hep_RE3006M';'Hep_r0724'};
        rxns_fox=[rxns_fox;rxns_fox_sup];
        pos=ismember(model.rxns,rxns_fox);
        pos_met=ismember(model.mets,'Hep_accoa[m]');
        coef=full(model.S(pos_met,pos));
        vector1_Hep=sum(abs(bsxfun(@times,coef',res_sol_1(pos,ExerciseStartingTime1-120:end))));%/sum(pos);
        vector2_Hep=sum(abs(bsxfun(@times,coef',res_sol_2(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        vector3_Hep=sum(abs(bsxfun(@times,coef',res_sol_Meal(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX'))&~cellfun(@isempty,strfind(rxns_fox,'Fat')));
        rxns_fox_sup={'Fat_ACACT10m';'Fat_MCDm';'Fat_r0287';'Fat_r0639';'Fat_r0653';'Fat_r0732';'Fat_RE1533M';'Fat_RE3006M';'Fat_r0724'};
        rxns_fox=[rxns_fox;rxns_fox_sup];
        pos=ismember(model.rxns,rxns_fox);
        pos_met=ismember(model.mets,'Fat_accoa[m]');
        coef=full(model.S(pos_met,pos));
        vector1_Fat=sum(abs(bsxfun(@times,coef',res_sol_1(pos,ExerciseStartingTime1-120:end))));%/sum(pos);
        vector2_Fat=sum(abs(bsxfun(@times,coef',res_sol_2(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        vector3_Fat=sum(abs(bsxfun(@times,coef',res_sol_Meal(pos,FoodApplicationTime2-60:end))));%/sum(pos);
        
        vector1=vector1_Fat+vector1_Hep+vector1_muscle;
        vector2=vector2_Fat+vector2_Hep+vector2_muscle;
        vector3=vector3_Fat+vector3_Hep+vector3_muscle;
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    elseif strcmp(rxns(r),'Goxid')
           pos=ismember(model.rxns,{'Hep_PDHm';'Muscle_PDHm';'Fat_PDHm';});
           vector1=sum(abs(res_sol_1(pos,ExerciseStartingTime1-120:end)));%/sum(pos);
           vector2=sum(abs(res_sol_2(pos,FoodApplicationTime2-60:end)));%/sum(pos);
           vector3=sum(abs(res_sol_Meal(pos,FoodApplicationTime2-60:end)));%/sum(pos);
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    else
        pos=ismember(model.rxns,rxns(r));
        vector1=(res_sol_1(pos,ExerciseStartingTime1-120:end));
        vector2=(res_sol_2(pos,FoodApplicationTime2-60:end));
        vector3=(res_sol_Meal(pos,FoodApplicationTime2-60:end));
        clear pos
    end
    
    MIN=min([vector1,vector2,vector3]);
    MAX=max([vector1,vector2,vector3]);
    
    if MIN==MAX
       MIN=MIN-1;
       MAX=MAX+1;
    end
    x11 = [ExerciseStartingTime2-ExerciseStartingTime2:ExerciseStoppingTime2-ExerciseStartingTime2];
    x12=flip(x11);
    y11 = repmat(MAX,1,numel(x11));
    y12 = repmat(MIN,1,numel(x11));

    y1=[y11 ,y12];
    x1=[x11, x12];

    a1=patch(x1,y1,'b');
    Darkgrey=[242 242 242]/256;

    set(a1,'FaceColor',Darkgrey)
    set(a1,'EdgeColor',Darkgrey)
   
    plot([-120:220],vector3,'k','LineWidth',3)
    plot([-120:220],vector2,'r--','LineWidth',2)
    plot([-120:280],vector1,'b:','LineWidth',2)

    [lims]=get(gca,{'XLim','YLim'});

    x1=FoodApplicationTime_Meal-ExerciseStartingTime2;
    x2=FoodApplicationTime1-ExerciseStartingTime1;
    
    minVec=min([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);
    maxVec=max([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);

    coef_norm=((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100))^1.1+1;
%     [((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5)^1.2,(abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5+1]
    if abs(MAX-maxVec)>abs(MIN-minVec)
        if (MAX-maxVec)>30
            y1=maxVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')   
        else
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E')
        end

    else
        if abs(MIN-minVec)>30
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E') 
        else
            y1=minVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')  
        end
    end

    minVec=min([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);
    maxVec=max([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);

    if abs((MAX-maxVec))>abs((MIN-minVec)) 
        if (MAX-maxVec)>30
            y2=maxVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        else
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        end

    else
        if abs(MIN-minVec)>30
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        else
            y2=minVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        end
    end
    
    plot([FoodApplicationTime_Meal-ExerciseStartingTime2],[MIN],'ko','MarkerFaceColor','k','MarkerSize',5)
%     plot([FoodApplicationTime2-ExerciseStartingTime2],[lims{2}(2)],'ro','MarkerFaceColor','r','MarkerSize',5)
    plot([FoodApplicationTime1-ExerciseStartingTime1],[MIN],'bo','MarkerFaceColor','b','MarkerSize',5)
         
    ylabel([labels(r), '[\mumol/min]'],'FontSize',12)
    xlabel('Time [min]','FontSize',12)
    
    xlim([-90,220])
    ylim([MIN,MAX])

    hold off
 end

fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 25 20];
% saveas(fig1,'Fluxes_exerc_vs_meal_HF.svg')
%%


nrows = 2;
ncols = 2;
labels={'Liver: glycogen amount','Muscle: glycogen amount','Adipose Tissue: TAG amount','Muscle: TAG amount'};
rxns={'Liver_glycogen','Muscle_glycogen','Fat_TAG','Muscle_TAG'};%'Hep_tag_stores',
for r= 1 : numel(rxns)
        if nrows*ncols-mod(-r, nrows*ncols) == 1
            fig=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%             H=suptitle(['Simulation of Exercise 4&5']);
%             set(H,'FontSize',20,'Position',[0.5,-0.02,0])
        end
        subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
       hold on
      
       pos=ismember(Results_1.Properties.RowNames,rxns(r));

       vector1=Results_Meal{pos,FoodApplicationTime2-60:end}/5;%+diff_met)
       vector2=Results_2{pos,FoodApplicationTime2-60:end}/5;%+diff_met)
       vector3=Results_1{pos,ExerciseStartingTime1-120:end}/5;%+diff_met)
       
    MIN=min([vector1,vector2,vector3]);
    MAX=max([vector1,vector2,vector3]);
    
    if MIN==MAX
       MIN=MIN-1;
       MAX=MAX+1;
    end
    x11 = [ExerciseStartingTime2-ExerciseStartingTime2:ExerciseStoppingTime2-ExerciseStartingTime2];
    x12=flip(x11);
    y11 = repmat(MAX,1,numel(x11));
    y12 = repmat(MIN,1,numel(x11));

    y1=[y11 ,y12];
    x1=[x11, x12];

    a1=patch(x1,y1,'b');
    Darkgrey=[242 242 242]/256;

    set(a1,'FaceColor',Darkgrey)
    set(a1,'EdgeColor',Darkgrey)
   
    plot([-120:221],vector1,'k','LineWidth',3)
    plot([-120:221],vector2,'r--','LineWidth',2)
    plot([-120:281],vector3,'b:','LineWidth',2)
       
   [lims]=get(gca,{'XLim','YLim'});

    x1=FoodApplicationTime_Meal-ExerciseStartingTime2;
    x2=FoodApplicationTime1-ExerciseStartingTime1;
    
    minVec=min([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);
    maxVec=max([vector3(x1+121),vector2(x1+121),vector1(x1+121)]);

    coef_norm=((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100))^1.1+1;
%     [((abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5)^1.2,(abs(MAX-MIN)>100)*round(abs(MAX-MIN)/100)*1.5+1]
    if abs(MAX-maxVec)>abs(MIN-minVec)
        if (MAX-maxVec)>30
            y1=maxVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')   
        else
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E')
        end

    else
        if abs(MIN-minVec)>30
            y1=minVec-7*coef_norm;
            text(x1,y1,'\uparrow','fontsize',20,'Color','k')
%             text(x1-15,y1-10*coef_norm,'Meal M->R')
%             text(x1-15,y1-15*coef_norm,'Meal M->E') 
        else
            y1=minVec+7*coef_norm;
            text(x1,y1,'\downarrow','fontsize',20,'Color','k')
%             text(x1-15,y1+10*coef_norm,'Meal M->R')
%             text(x1-15,y1+15*coef_norm,'Meal M->E')  
        end
    end

    minVec=min([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);
    maxVec=max([vector3(x2+121),vector2(x2+121),vector1(x2+121)]);

    if abs((MAX-maxVec))>abs((MIN-minVec)) 
        if (MAX-maxVec)>30
            y2=maxVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        else
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        end

    else
        if abs(MIN-minVec)>30
            y2=minVec-7*coef_norm;
            text(x2,y2,'\uparrow','fontsize',20,'Color','b')
%             text(x2-15,y2-10*coef_norm,'Meal E->M')
        else
            y2=minVec+7*coef_norm;
            text(x2,y2,'\downarrow','fontsize',20,'Color','b')
%             text(x2-15,y2+10*coef_norm,'Meal E->M')
        end
    end
    
    plot([FoodApplicationTime_Meal-ExerciseStartingTime2],[MIN],'ko','MarkerFaceColor','k','MarkerSize',5)
%     plot([FoodApplicationTime2-ExerciseStartingTime2],[lims{2}(2)],'ro','MarkerFaceColor','r','MarkerSize',5)
    plot([FoodApplicationTime1-ExerciseStartingTime1],[MIN],'bo','MarkerFaceColor','b','MarkerSize',5)
         
    ylabel([labels(r), '[\mumol/min]'],'FontSize',12)
    xlabel('Time [min]','FontSize',12)
    
    xlim([-90,220])
    ylim([MIN,MAX])
 end
 
fig.PaperUnits = 'centimeters';
fig.PaperPosition = [0 0 20 15];

% L=legend('M->R','M->E','E->M','Meal StartT M->R','Meal StartT M->E','Meal StartT E->M','Exercise StartT M->E','Exercise StopT M->E',...
% 'Exercise StartT E->M','Exercise StopT E->M');
% L.FontSize=16;

% saveas(fig,'Stores_exerc_vs_meal_HF.svg')
% legend('M->R','M->E','E->M','Meal StartT M->R','Meal StartT M->E','Meal StartT E->M','Exercise StartT M->E','Exercise StopT M->E',...
% 'Exercise StartT E->M','Exercise StopT E->M')


