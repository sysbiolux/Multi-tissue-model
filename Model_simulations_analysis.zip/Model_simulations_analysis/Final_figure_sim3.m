clearvars;clc;
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');

load('Results_healthy_exercise_sim_3.mat')

res_sol_1=zeros(numel(qp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_1(:,i)=qp_sols{i}.x(1:numel(qp_sols{1}.x));
        end
    end
   ExerciseStartingTime1=ExerciseStartingTime;
   ExerciseStoppingTime1=ExerciseStoppingTime;
%     FoodApplicationTime1=FoodApplicationTime;
    Results_1=Results;
    clear Results qp_sols lp_sols FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

%%
rxns={'Hep_glc_D';'Hep_o2';'Hep_lac_L';'Muscle_glc_D';'Muscle_o2';'Muscle_lac_L'};%;'Fat_Rtotal2';'Fat_Rtotal3'};

x=255;


nrows = 3;
ncols = 2;
labels={'Liver: Glucose export','Liver: O_2 uptake','Liver: Lactate uptake',...
    'Muscle: Glucose uptake','Muscle: O_2 uptake','Muscle: Lactate export'};

 for r= 1 : numel(rxns)
    if nrows*ncols-mod(-r, nrows*ncols) == 1
        fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%         H=suptitle(['Simulation of Exercise with Meal']);
%         set(H,'FontSize',20,'Position',[0.5,-0.02,0])
    end
    subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
    hold on
    
    if strcmp(rxns(r),'Fat_fa')
           Fat = BoundedReactions{[69:71,88:127],1};%
           Fat=Fat(ismember(Fat,model.rxns));  
           pos=ismember(model.rxns,Fat(:,1));
           vector1=sum(res_sol_1(pos,ExerciseStartingTime1-30:end));
           rxns{r}='Fat Fatty acids';
           pos_fa=pos;
           clear pos    
    elseif strcmp(rxns(r),'Foxid')
        fa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'coa['))&cellfun(@isempty,strfind(model.mets,'_coa['))&...
            cellfun(@isempty,strfind(model.mets,'_accoa['))&cellfun(@isempty,strfind(model.mets,'[x]'))&~cellfun(@isempty,strfind(model.mets,'[m]'))));
        accoa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'accoa['))));
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX')));
        pos=ismember(model.rxns,rxns_fox);
        vector1=sum(abs(res_sol_1(pos,ExerciseStartingTime1-30:end)));%/sum(pos);
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    elseif strcmp(rxns(r),'Goxid')
           pos=ismember(model.rxns,{'Hep_PDHm';'Muscle_PDHm';'Fat_PDHm';});
           vector1=sum(abs(res_sol_1(pos,ExerciseStartingTime1-30:end)));%/sum(pos);
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    else
        pos=ismember(model.rxns,rxns(r));
        vector1=(res_sol_1(pos,ExerciseStartingTime1-30:end));
        clear pos
    end
    
    plot([-30:1000-720],vector1,'k','LineWidth',2)

    [lims]=get(gca,{'XLim','YLim'});

         
    plot([ExerciseStartingTime1-ExerciseStartingTime1],lims{2}(1),'k^','MarkerFaceColor','k','MarkerSize',4)
    plot([ExerciseStoppingTime1-ExerciseStartingTime1],[lims{2}(1)],'b^','MarkerFaceColor','b','MarkerSize',4)
    plot([120],lims{2}(1),'^','Color',[63/x,122/x,77/x],'MarkerFaceColor',[63/x,122/x,77/x],'MarkerSize',4)
    plot([150],lims{2}(1),'b^','MarkerFaceColor','b','MarkerSize',4)
    plot([160],lims{2}(1),'m^','MarkerFaceColor','m','MarkerSize',4)
    plot([170],lims{2}(1),'r^','MarkerFaceColor','r','MarkerSize',4)
    plot([180],lims{2}(1),'^','Color',[63/x,122/x,77/x],'MarkerFaceColor',[63/x,122/x,77/x],'MarkerSize',4)    
  
    
    plot([0],lims{2}(2),'kv','MarkerFaceColor','k','MarkerSize',4)
    plot([5],[lims{2}(2)],'bv','MarkerFaceColor','b','MarkerSize',4)
    plot([120],lims{2}(2),'v','Color',[63/x,122/x,77/x],'MarkerFaceColor',[63/x,122/x,77/x],'MarkerSize',4)
    plot([150],lims{2}(2),'bv','MarkerFaceColor','b','MarkerSize',4)
    plot([160],lims{2}(2),'mv','MarkerFaceColor','m','MarkerSize',4)
    plot([170],lims{2}(2),'rv','MarkerFaceColor','r','MarkerSize',4)
    plot([180],lims{2}(2),'v','Color',[63/x,122/x,77/x],'MarkerFaceColor',[63/x,122/x,77/x],'MarkerSize',4)    
    
    ylabel([labels(r), '[\mumol/min]'],'FontSize',14)
    xlabel('Time [min]','FontSize',14)
    
    xlim([-30,180])
    ylim(lims{2})

    hold off
 end
L=legend('Simulation','StartTime 55% V0_2_m_a_x','StartTime 70% V0_2_m_a_x','StartTime Rest','StartTime 70% V0_2_m_a_x',...
'StartTime 80% V0_2_m_a_x','StartTime 90% V0_2_m_a_x','StartTime Rest');
L.FontSize=12;

fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 20 20];
% saveas(fig1,'Fluxes_exerc_sim3.svg')
