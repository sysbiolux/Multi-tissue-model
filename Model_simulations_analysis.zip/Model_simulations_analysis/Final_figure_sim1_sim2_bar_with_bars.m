TCE = [515 420 370 250 135 120 60 20];
days = 0:5:35;

x11 = [0:10];
x12=flip(x11);
y11 = repmat(515,1,numel(x11));
y12 = repmat(0,1,numel(x11));

x21=[0:30];
x22=flip(x21);
y21 = repmat(515,1,numel(x21));
y22 = repmat(0,1,numel(x21));
clearvars;clc;
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');

load('Results_healthy_exercise_sim_1.mat')

res_sol_1=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_1(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime1=ExerciseStartingTime;
   ExerciseStoppingTime1=ExerciseStoppingTime;
%     FoodApplicationTime1=FoodApplicationTime;
    Results_1=Results;
    clear Results qp_sols lp_sols FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
     
    load('Results_healthy_exercise_sim_2.mat')

    res_sol_2=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_2(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
   ExerciseStartingTime2=ExerciseStartingTime;
   ExerciseStoppingTime2=ExerciseStoppingTime;
%    FoodApplicationTime2=FoodApplicationTime;
    Results_2=Results;

    clear Results qp_sols lp_sols  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
%%
rxns={'Fat_glc_D';'Fat_o2';'Fat_glyc';'Fat_lac_L';'Fat_fa';};%;'Fat_Rtotal2';'Fat_Rtotal3'};

nrows = 2;
ncols = 3;
labels={'A. Tissue: Glucose uptake','A. Tissue: O_2 uptake','A. Tissue: Glycerol export',...
    'A. Tissue: Lactate export','A. Tissue: Fatty acids export'};

 for r= 1 : numel(rxns)
    if nrows*ncols-mod(-r, nrows*ncols) == 1
        fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%         H=suptitle(['Simulation of Exercise with Meal']);
%         set(H,'FontSize',20,'Position',[0.5,-0.02,0])
    end
    subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
    hold on
    
    if strcmp(rxns(r),'Fat_fa')
           Fat = BoundedReactions{[69:71,88:127],1};%
           Fat=Fat(ismember(Fat,model.rxns));  
           pos=ismember(model.rxns,Fat(:,1));
           vector1=sum(res_sol_1(pos,ExerciseStartingTime1-60:end));
           vector2=sum(res_sol_2(pos,ExerciseStartingTime1-60:end));
           rxns{r}='Fat Fatty acids';
           pos_fa=pos;
           clear pos    
    elseif strcmp(rxns(r),'Foxid')
        fa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'coa['))&cellfun(@isempty,strfind(model.mets,'_coa['))&...
            cellfun(@isempty,strfind(model.mets,'_accoa['))&cellfun(@isempty,strfind(model.mets,'[x]'))&~cellfun(@isempty,strfind(model.mets,'[m]'))));
        accoa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'accoa['))));
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX')));
        pos=ismember(model.rxns,rxns_fox);
        vector1=sum(abs(res_sol_1(pos,ExerciseStartingTime1-60:end)));%/sum(pos);
        vector2=sum(abs(res_sol_2(pos,ExerciseStartingTime1-60:end)));%/sum(pos);
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    elseif strcmp(rxns(r),'Goxid')
           pos=ismember(model.rxns,{'Hep_PDHm';'Muscle_PDHm';'Fat_PDHm';});
           vector1=sum(abs(res_sol_1(pos,ExerciseStartingTime1-60:end)));%/sum(pos);
           vector2=sum(abs(res_sol_2(pos,ExerciseStartingTime1-60:end)));%/sum(pos);
%            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    else
        pos=ismember(model.rxns,rxns(r));
        vector1=(res_sol_1(pos,ExerciseStartingTime1-60:end));
        vector2=(res_sol_2(pos,ExerciseStartingTime1-60:end));
        clear pos
    end
    
    MIN=min([vector1,vector2]);
    MAX=max([vector1,vector2]);
    
    if MIN==MAX
       MIN=MIN-1;
       MAX=MAX+1;
    end
    x11 = [ExerciseStartingTime1-ExerciseStartingTime1:ExerciseStoppingTime1-ExerciseStartingTime1];
    x12=flip(x11);
    y11 = repmat(MAX,1,numel(x11));
    y12 = repmat(MIN,1,numel(x11));

    x21 = [ExerciseStartingTime2-ExerciseStartingTime2:ExerciseStoppingTime2-ExerciseStartingTime2];
    x22=flip(x21);
    y21 = repmat(MAX,1,numel(x21));
    y22 = repmat(MIN,1,numel(x21));
    y1=[y11 ,y12];
    x1=[x11, x12];
    y2=[y21 ,y22];
    x2=[x21, x22];

    a1=patch(x1,y1,'b');
    Lightgrey=[256 256 256]/256;
    Darkgrey=[232 232 232]/256;

    set(a1,'FaceColor',Lightgrey)
    set(a1,'EdgeColor','k')
%     a1.FaceAlpha = 0.2;

    a2=patch(x2,y2,'b');
    set(a2,'FaceColor',Darkgrey);
    set(a2,'EdgeColor',Darkgrey)
%     a2.FaceAlpha = 0.2;
      
    plot([-60:1000-720],vector1,'b:','LineWidth',2)
    plot([-60:1000-720],vector2,'r--','LineWidth',2)

    [lims]=get(gca,{'XLim','YLim'});
  
    ylabel([labels(r), '[\mumol/min]'],'FontSize',14)
    xlabel('Time [min]','FontSize',14)
    
    xlim([-60,300])

    ylim([MIN,MAX])

    hold off
 end
L=legend('Exercise 40% V0_2_m_a_x',...
'Exercise 60% V0_2_m_a_x','40% V0_2_m_a_x','60% V0_2_m_a_x');
L.FontSize=12;

fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 25 13];
%saveas(fig1,'Fluxes_exerc_sim1_sim2.svg')
