clear all;clc

disease='Arginase_deficiency';
% disease='Tyrosinemia_I';
%%
load('Top_biomarkers_blood.mat','data','final_set_wo_fasting')

mets={'5g2oxpt','arg_L','gln_L','citr_L','orot','nh4','urea','creat','gudac','argsuc','ura','crn','orn','5oxpro','Lcystin'};

mets_blood=mets(ismember(mets,data{:,2}));
final_set_wo_fasting=final_set_wo_fasting(ismember(final_set_wo_fasting{:,2},disease),:);


for r=1:size(final_set_wo_fasting,1)
   
    pos=ismember(data{:,1},'Healthy')&ismember(data{:,5},final_set_wo_fasting{r,5})&ismember(data{:,2},final_set_wo_fasting{r,1});
    final_set_wo_fasting{r,6}=log2(final_set_wo_fasting{r,4}/data{pos,4});       
end

% mets=unique(final_set_wo_fasting{:,1});

blood=table;
for m=1:numel(mets)
    pos=ismember(final_set_wo_fasting{:,1},mets(m));
    blood{m,1:4}=[unique(final_set_wo_fasting{pos,1}),unique(final_set_wo_fasting{pos,3}),cellstr(strjoin(final_set_wo_fasting{pos,5},';')),...
        num2cell(max(abs(final_set_wo_fasting{pos,6})))];   
end

try
blood=sortrows(blood,-4);
end
%%

clearvars -except blood mets_blood disease
load('Top_biomarkers_urine.mat','data','final_set_wo_fasting')

mets={'5g2oxpt','arg_L','gln_L','citr_L','orot','nh4','urea','creat','gudac','argsuc','ura','crn','orn','5oxpro','Lcystin'};
mets_urine=mets(ismember(mets,data{:,2}));

final_set_wo_fasting=final_set_wo_fasting(ismember(final_set_wo_fasting{:,2},disease),:);


for r=1:size(final_set_wo_fasting,1)
   
    pos=ismember(data{:,1},'Healthy')&ismember(data{:,5},final_set_wo_fasting{r,5})&ismember(data{:,2},final_set_wo_fasting{r,1});
    final_set_wo_fasting{r,6}=log2(final_set_wo_fasting{r,4}/data{pos,4});       
end

% mets=unique(final_set_wo_fasting{:,1});

urine=table;
for m=1:numel(mets)
    pos=ismember(final_set_wo_fasting{:,1},mets(m));
    urine{m,1:4}=[unique(final_set_wo_fasting{pos,1}),unique(final_set_wo_fasting{pos,3}),cellstr(strjoin(final_set_wo_fasting{pos,5},';')),...
        num2cell(max(abs(final_set_wo_fasting{pos,6})))];   
end

try
urine=sortrows(urine,-4);
end

%% 

% mets={'5g2oxpt','arg_L','gln_L','citr_L','orot','nh4','urea','creat','gudac','argsuc','ura','crn','orn','5oxpro','Lcystin'};

% blood(ismember(blood{:,1},mets_blood),:)
% 
% urine(ismember(urine{:,1},mets_urine),:)


%%
load('Top_biomarkers_blood.mat','data','final_set_wo_fasting')

for r=1:size(final_set_wo_fasting,1)
   
    pos=ismember(data{:,1},'Healthy')&ismember(data{:,5},final_set_wo_fasting{r,5})&ismember(data{:,2},final_set_wo_fasting{r,1});
    final_set_wo_fasting{r,6}=log2(final_set_wo_fasting{r,4}/data{pos,4})*(final_set_wo_fasting{r,4}-data{pos,4});       
end

mets=unique(final_set_wo_fasting{:,1});
dis=unique(final_set_wo_fasting{:,2});

blood=table;
for m=1:numel(mets)
    for d=1:numel(dis)
        pos=ismember(final_set_wo_fasting{:,1},mets(m))&ismember(final_set_wo_fasting{:,2},dis(d));
        if sum(pos)>0
            try
        blood{end+1,1:5}=[unique(final_set_wo_fasting{pos,2}),unique(final_set_wo_fasting{pos,1}),unique(final_set_wo_fasting{pos,3}),cellstr(strjoin(final_set_wo_fasting{pos,5},';')),...
            num2cell(max(abs(final_set_wo_fasting{pos,6})))];
            catch
                final_set_wo_fasting(pos,:)
            end
        end
    end
end


clearvars -except blood 
load('Top_biomarkers_urine.mat','data','final_set_wo_fasting')

for r=1:size(final_set_wo_fasting,1)
   
    pos=ismember(data{:,1},'Healthy')&ismember(data{:,5},final_set_wo_fasting{r,5})&ismember(data{:,2},final_set_wo_fasting{r,1});
    final_set_wo_fasting{r,6}=log2(final_set_wo_fasting{r,4}/data{pos,4})*(final_set_wo_fasting{r,4}-data{pos,4});       
end

mets=unique(final_set_wo_fasting{:,1});
dis=unique(final_set_wo_fasting{:,2});

urine=table;
for m=1:numel(mets)
    for d=1:numel(dis)
        pos=ismember(final_set_wo_fasting{:,1},mets(m))&ismember(final_set_wo_fasting{:,2},dis(d));
        if sum(pos)>0
        urine{end+1,1:5}=[unique(final_set_wo_fasting{pos,2}),unique(final_set_wo_fasting{pos,1}),unique(final_set_wo_fasting{pos,3}),cellstr(strjoin(final_set_wo_fasting{pos,5},';')),...
            num2cell(max(abs(final_set_wo_fasting{pos,6})))];
        end
    end
end


clearvars -except blood urine

dis=unique([blood{:,1};urine{:,1}]);
mets=unique([blood{:,2};urine{:,2}]);

biomarkers=table;

for d=1:numel(dis)
    for m=1:numel(mets)
        pos_blood=ismember(blood{:,2},mets(m))&ismember(blood{:,1},dis(d));
        pos_urine=ismember(urine{:,2},mets(m))&ismember(urine{:,1},dis(d));
        try
            if sum(pos_blood)>0&&sum(pos_urine)>0
                biomarkers{end+1,1:8}=[blood{pos_blood,:},urine{pos_urine,3:5}];
            elseif sum(pos_blood)>0
                biomarkers{end+1,1:5}=blood{pos_blood,:}; 
            elseif sum(pos_urine)>0
                biomarkers{end+1,1:2}=urine{pos_urine,1:2}; 
                biomarkers{end,6:8}=urine{pos_urine,3:5};
            end
        end
    end
end


biomarkers.Properties.VariableNames={'IEM','Metabolite','BloodPrediction','BloodConditions','BloodMaxValue','UrinePrediction','UrineConditions','UrineMaxValue'};


Smaller_list=biomarkers(~cellfun(@isempty,biomarkers{:,5})&~cellfun(@isempty,biomarkers{:,8}),:);

writetable(biomarkers,'List_identified_biomarkers_all_fluids.csv')

writetable(Smaller_list,'List_common_biomarkers_all_fluids.csv')



