function top_biomarkers=CV_threshold_outlier_determination_blood_AUC
    clear all;clc;
    clearvars;
    linkage_meas='single';
    type_of_diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms

    meal=1;
    data=readtable(['Results_for_blood_biomarker_prediction_',strjoin(type_of_diet(meal)),'_AUC.csv']);
    data(:,end+1)={'LF'};
    
    meal=2;
    data2=readtable(['Results_for_blood_biomarker_prediction_',strjoin(type_of_diet(meal)),'_AUC.csv']);
    data2(:,end+1)={'Fasting'};
    
    meal=3;
    data3=readtable(['Results_for_blood_biomarker_prediction_',strjoin(type_of_diet(meal)),'_AUC.csv']);
    data3(:,end+1)={'HF'};

    data=[data;data2;data3];
    
    mets=unique(data{:,2});

    data_biomarkers=data(:,1:3);
    data_biomarkers{:,4}={''};
    data_biomarkers{strcmp(data_biomarkers{:,3},'up'),4}={'+'};
    data_biomarkers{strcmp(data_biomarkers{:,3},'down'),4}={'-'};

    data_biomarkers{:,5}={'n'};
   
    data=sortrows(sortrows(data,2),1);

    skmeans=0;
    adjbox=0;
    hclust=1;
    
    mets=unique(data{:,2});
    nrows = 6;
    ncols = 7;

    AND_rule=0;
    filtering=0;
    
    top_biomarkers=table();

    m_b=1;
    for m=1:numel(mets)

        pos=ismember(data{:,2},mets(m));
        data_met=data(pos,:);
        auc=data_met{:,4};
        diseases=data_met{:,1};
        Condition=data_met{:,5};

        x=([auc]);
%         x=zscore(x);
        if hclust
            if skmeans
                  myfunc = @(X,K)(kmeans(X, K,'Distance','cityblock', 'replicate',5));
                  E = evalclusters(x,myfunc,'silhouette','klist',[1:3]);

                    cl=E.OptimalK;
                    if isnan(cl)
                        cl=1;
                    end

%                 c = cluster(linkage(x,'complete'),'maxclust',cl);
    %             opts = statset('Display','final');
                [c] = kmeans(x,cl,'Distance','cityblock',...
                    'Replicates',5);%,'Options',opts
            else
                 myfunc = @(x,k) clusterdata(x,'linkage',linkage_meas,'maxclust',k);
                  E = evalclusters(x,myfunc,'silhouette','klist',[1:3]);

%                     [a,b]=max(round(E.CriterionValues,3));
                    cl=E.OptimalK;
%                     cl=b;
                    if isnan(cl)
                        cl=1;
    %                 else
    %                     cl
                    end

                c = cluster(linkage(x,linkage_meas),'maxclust',cl);
            end
            
            pos_1=c==1;
            if cl==3
                pos_2=c==2;
                pos_3=c==3;
                [~,max_pos]=max([sum(pos_1),sum(pos_2),sum(pos_3)]);
            elseif cl==2
                pos_2=c==2;
                [~,max_pos]=max([sum(pos_1),sum(pos_2)]);
            else
                [~,max_pos]=max([sum(pos_1)]);
            end
            index_max=logical(zeros(cl,1));
            index_max(max_pos)=true;

            f=find(~index_max);
            f=ismember(c,f);

            pos=~cellfun(@isempty,strfind(diseases,'Healthy'));

                f_down=f&auc<min(x(pos));%&scoreFC<-threshold_MAD&scoreFC<-threshold_MAD;%FC<t_downFC&ABS<t_downA&
                f_up=f&auc>max(x(pos));%&scoreFC>threshold_MAD&scoreFC>threshold_MAD;%FC>t_upFC&ABS>t_upA&
        end
        if adjbox
            threshold=1.5;

            pos=~cellfun(@isempty,strfind(diseases,'Healthy'));
            x=auc(pos);
            Q1 = quantile(x, 0.25);
            Q3 = quantile(x, 0.75);

            MC = medcouple(x);
            
            k1 = -3.5*(MC>=0);
            k1 = k1 - 4*(MC<0);
            k3 = 4*(MC>=0);
            k3 = k3 + 3.5*(MC<0);
%             x=[auc];

            x=auc;
            [n, col] = size(x);
            [i1,j1] = find(x < repmat(Q1 - threshold*exp(k1.*MC).*(Q3-Q1),n,1));
            [i2,j2] = find(x > repmat(Q3 + threshold*exp(k3.*MC).*(Q3-Q1),n,1));
            LL=Q1 - threshold*exp(k1.*MC).*(Q3-Q1);
            UL=Q3 + threshold*exp(k3.*MC).*(Q3-Q1);

            down=logical(zeros(numel(auc),1));
            up=logical(zeros(numel(auc),1));

             if (isempty(i1)+isempty(i2)) == 0
                 if AND_rule
                    down(intersect(i1(j1==1),i1(j1==2)))=true;
                    up(intersect(i2(j2==1),i2(j2==2)))=true;
                 else
                    down(unique(i1))=true;
                    up(unique(i2))=true;
                 end
            elseif isempty(i1),
                if AND_rule
                    up(intersect(i2(j2==1),i2(j2==2)))=true;
                else
                    up(unique(i2))=true;
                end
            elseif isempty(i2),
                if AND_rule
                    down(intersect(i1(j1==1),i1(j1==2)))=true;
                else
                    down(unique(i1))=true;
                end
             end


            if hclust==0
                cl=0;
                f_down=down;
                f_up=up;
            else
                f_down=f_down&down;
                f_up=f_up&up;
            end
        end
        
        if filtering
%             f_up(abs(FC)<0.585)=0;
%             f_down(abs(FC)<0.585)=0;

             f_up(abs(x)<trapz(repmat(1.4e-06,361,1)))=0;
            f_down(abs(x)<trapz(repmat(1.4e-06,361,1)))=0;
%             f_up(1:numel(Res_IEM{ismember(Res_IEM{:,2},mets(m)),3}))=f_up(1:numel(Res_IEM{ismember(Res_IEM{:,2},mets(m)),3}))&Res_IEM{ismember(Res_IEM{:,2},mets(m)),3};
%             f_down(1:numel(Res_IEM{ismember(Res_IEM{:,2},mets(m)),3}))=f_down(1:numel(Res_IEM{ismember(Res_IEM{:,2},mets(m)),3}))&Res_IEM{ismember(Res_IEM{:,2},mets(m)),3};
        end
        
        diff_up=auc;
        diff_down=auc;
       
        up=f_up;
        down=f_down;
%         if sum(up)>0|sum(down)>0
%             if nrows*ncols-mod(-m_b, nrows*ncols) == 1
%                 figure('Visible','off','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%                 suptitle(['CV Miller data FC or AbsChange threshold: hclust in blood']);
%             end
%             subplot(nrows, ncols, nrows*ncols-mod(-m_b, nrows*ncols));
%             dis_vector=1:numel(diseases);
% 
%             hold on
%         %             plot(dis_vector(~up&~down),FC(~up&~down),'ko','MarkerFaceColor','k')%correctly predicted n-> n
%         % 
%         %             plot(dis_vector(up),FC(up),'ro','MarkerFaceColor','red')%predicted  n-> up
%         % 
%         %             plot(dis_vector(down),FC(down),'co','MarkerFaceColor','c')%predicted  n-> down
%             try
%             plot(auc(~up&~down),1,'ko','MarkerFaceColor','k')%correctly predicted n-> n
%             end
%             try
%             plot(auc(up),1,'ro','MarkerFaceColor','red')%predicted  n-> up
%             end
%             try
%             plot(auc(down),1,'co','MarkerFaceColor','c')%predicted  n-> down
%             end
%             m_b=m_b+1;
%             y = ylim;
% 
%             hold off
%             xlabel(['auc ',[strrep(mets{m},'_',' '),' cluster:',num2str(cl)]])
%             ylabel([''])
%         end
%     %             xlim([1,numel(diseases)])
        

        final_down=mean(diff_down,2);
        final_up=mean(diff_up,2);  

        biomarkers=table([repmat(mets(m),sum(down|up),1)],[diseases(down);diseases(up)],[repmat({'down'},sum(down),1);repmat({'up'},sum(up),1)],[final_down(down);final_up(up)],[Condition(down);Condition(up)]);
        top_biomarkers=[top_biomarkers;biomarkers];
        
        if ~isempty(biomarkers)
           for b=1:size(biomarkers,1)
               dis_pos=ismember(data_biomarkers{:,1},biomarkers{b,2});
               met_pos=ismember(data_biomarkers{:,2},biomarkers{b,1});
               data_biomarkers{dis_pos&met_pos,5}=biomarkers{b,3};
               data_biomarkers{dis_pos&met_pos,6}=biomarkers{b,4};
               data_biomarkers{dis_pos&met_pos,7}=biomarkers{b,5};
           end
        end

    end    
    
    top_markers=top_biomarkers(abs(top_biomarkers{:,4})>0,:);
    mets=unique(top_biomarkers{:,1});

    final_set={};
    for m=1:numel(mets)
       current_biomarkers=top_markers(ismember(top_markers{:,1},mets(m)),:);
       current_set={};
       tag=0;
       for d=1:size(current_biomarkers,1)
           if d>d-1+tag
            if sum(strcmp(current_biomarkers{:,2},current_biomarkers{d,2})) >1
                current_set=[current_set;current_biomarkers(strcmp(current_biomarkers{:,2},current_biomarkers{d,2}),:)];
                tag=sum(strcmp(current_biomarkers{:,2},current_biomarkers{d,2}))-1;
            else
                tag=0;
            end
           else
               tag=max(tag-1,0);
           end
       end
       if ~isempty(current_set)
        final_set=[final_set;current_set]; 
       end
    end

    
    top_markers=top_biomarkers(abs(top_biomarkers{:,4})>0,:);
    mets=unique(top_biomarkers{:,1});

    %%remove biomarkers identified only in the fasting condition
    final_set_wo_fasting={};
    for m=1:numel(mets)
       current_biomarkers=top_markers(ismember(top_markers{:,1},mets(m)),:);
       current_set={};
       tag=0;
       for d=1:size(current_biomarkers,1)
           if d>d-1+tag
            if sum(strcmp(current_biomarkers{:,2},current_biomarkers{d,2})) >1 || sum(strcmp(current_biomarkers{d,5},'Fasting')) ==0
                current_set=[current_set;current_biomarkers(strcmp(current_biomarkers{:,2},current_biomarkers{d,2}),:)];
                tag=sum(strcmp(current_biomarkers{:,2},current_biomarkers{d,2}))-1;
            else
                 tag=0;
            end
           else
               tag=max(tag-1,0);
           end
       end
       if ~isempty(current_set)
        final_set_wo_fasting=[final_set_wo_fasting;current_set]; 
       end
    end
    
    %calculate in how many conditions the biomarkers were identified
    %(between 1 and 3)
    final_set_wo_fasting_score={};
    mets=unique(final_set_wo_fasting{:,1});
    for m=1:numel(mets)
       current_biomarkers=final_set_wo_fasting(ismember(final_set_wo_fasting{:,1},mets(m)),:);
       current_set={};
       tag=0;
       for d=1:size(current_biomarkers,1)
           if d>d-1+tag
            if sum(strcmp(current_biomarkers{:,2},current_biomarkers{d,2})) >1 || sum(strcmp(current_biomarkers{d,5},'Fasting')) ==0
                unique_set=current_biomarkers(strcmp(current_biomarkers{:,2},current_biomarkers{d,2}),1:3);
                if sum(strcmp(unique_set{:,3},unique_set{1,3})) ~=size(unique_set,1)
%                     current_set=[current_set;[unique_set,array2table(zeros(size(unique_set,1),1),'VariableNames',{'Score'})]];
                else
                    current_set=[current_set;[unique_set(1,:),array2table(size(unique_set,1),'VariableNames',{'Score'})]];
                end
                tag=sum(strcmp(current_biomarkers{:,2},current_biomarkers{d,2}))-1;
            else
                 tag=0;
            end
           else
               tag=max(tag-1,0);
           end
       end
       if ~isempty(current_set)
        final_set_wo_fasting_score=[final_set_wo_fasting_score;current_set]; 
       end
    end
    final_set_wo_fasting_score.Properties.VariableNames={'Met_','IEM','Change','Score'};
    
        save('Top_biomarkers_blood')

        writetable(final_set_wo_fasting_score,['Top_ranked_biomarkers_AUC_all_IEMs_hclust_blood_score.csv'])

        top_biomarkers.Properties.VariableNames={'Met_','IEM','Change','AUC','Condition'};
        writetable(top_biomarkers,['Top_ranked_biomarkers_AUC_all_IEMs_hclust_blood.csv'])

%% Extract data for heatmap
        
        schlomi=readtable('Schlomi_biomarkers.csv');
        schlomi{:,1}=strrep(schlomi{:,1},' ','_');
        mets=unique(schlomi{:,2});
        schlomi{ismember(schlomi{:,1},'ARGININEMIA'),1}={'Arginase_deficiency'};
        schlomi{ismember(schlomi{:,1},'MAPLE_SYRUP_URINE_DISEASE'),1}={'MSUD'};
        schlomi{ismember(schlomi{:,1},'TYROSINEMIA_TYPE_1'),1}={'TYROSINEMIA_I'};
        schlomi{ismember(schlomi{:,1},'TYROSINEMIA_TYPE_III'),1}={'TYROSINEMIA_III'};
        schlomi{ismember(schlomi{:,1},'ALKAPTONURIA'),1}={'Alkaptonuria'};
              
        for m=1:size(schlomi,1)        
            pos=find(ismember(upper(final_set_wo_fasting_score{:,2}),upper(schlomi{m,1}))&ismember(final_set_wo_fasting_score{:,1},schlomi{m,2}));
            if isempty(pos)
                schlomi{m,5}={'n'};
            else
                schlomi(m,5:6)=final_set_wo_fasting_score(pos,3:4);
            end
        end
        
        schlomi.Properties.VariableNames={'IEM','Metabolite','Regulation','LitSign','Predictions','Score'};
        
    schlomi{ismember(schlomi{:,1},'Alkaptonuria'),1}={'AKU'};%Alkaptonuria'};
    schlomi{ismember(schlomi{:,1},'Arginase_deficiency'),1}={'ARG'};%{'Arginase deficiency'};
    schlomi{ismember(schlomi{:,1},'CYSTINURIA'),1}={'CYST'};%Cystinuria'};
    schlomi{ismember(schlomi{:,1},'GLUTAMATE_FORMIMINOTRANSFERASE_DEFICIENCY'),1}={'FIGLU'}; %Glutamate Formiminotransferase Deficiency
    schlomi{ismember(schlomi{:,1},'GLYCINE_ENCEPHALOPATHY__NONKETOTIC_HYPERGLYCINEMIA___NKH'),1}={'NKH'};%Glycine Encephalopathy/ Nonketotic Hyperglycinemia / Nkh
    schlomi{ismember(schlomi{:,1},'HISTIDINEMIA'),1}={'HIS'};%Histidinemia
    schlomi{ismember(schlomi{:,1},'HOMOCYSTINURIA'),1}={'HCYS'};%Homocystinuria
    schlomi{ismember(schlomi{:,1},'HYPERPROLINEMIA_TYPE_I'),1}={'HYPRO1'};%Hyperprolinemia Type I
    schlomi{ismember(schlomi{:,1},'LYSINURIC_PROTEIN_INTOLERANCE'),1}={'LPI'};%Lysinuric Protein Intolerance
    schlomi{ismember(schlomi{:,1},'METHIONINE_ADENOSYLTRANSFERASE_DEFICIENCY'),1}={'MAT I/III'};%Methionine adenosyltransferase I/III deficiency
    schlomi{ismember(schlomi{:,1},'METHYLMALONIC_ACIDEMIA_(MMA)'),1}={'MMA'};%Methylmalonic Acidemia (MMA)
%     schlomi{ismember(schlomi{:,1},'MSUD'),1}={'Alkaptonuria'};%Maple Syrup Urine Disease
    schlomi{ismember(schlomi{:,1},'PHENYLKETONURIA'),1}={'PKU'};%Phenylketonuria
    schlomi{ismember(schlomi{:,1},'PHENYLKETONURIA_TYPE_2'),1}={'PKU2'};%Phenylketonuria Type II
    schlomi{ismember(schlomi{:,1},'S_ADENOSYLHOMOCYSTEIN_HYDROLASE'),1}={'AHCY'};%S-adenosylhomocysteine hydrolase
    schlomi{ismember(schlomi{:,1},'TYROSINEMIA_I'),1}={'TYR1'};%Tyrosinemia Type I
    schlomi{ismember(schlomi{:,1},'TYROSINEMIA_III'),1}={'TYR3'};%Tyrosinemia Type III
        writetable(schlomi,'Schlomi_predicted_biomarkers_blood_filtered.csv')
end

 
  
   