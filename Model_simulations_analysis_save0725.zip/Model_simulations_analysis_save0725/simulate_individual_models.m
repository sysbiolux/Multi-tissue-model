function simulate_individual_models(WorkingDir,a)%(a)
step_size=1;
% a=1;
model= SetupModel();
individual_models=1;
diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms
type_of_diet=diet(a);

params=getParams(a);

for m=1:100
    
    if ~exist([WorkingDir filesep 'Results_',strjoin(type_of_diet),'_healthy_',num2str(m),'.mat'],'file')
        [Results,qpsol,lpsol,infeasibility] = simulateQP_modified(model,360,type_of_diet,params,WorkingDir,individual_models,step_size);
% save('Results_no_food_healthy_day')
        save([WorkingDir filesep 'Results_',strjoin(type_of_diet),'_healthy_',num2str(m),'.mat'])

        if ~isempty(infeasibility)
            save(['Infeasibility_',strjoin(type_of_diet),'_healthy_',num2str(m),'.mat'],'infeasibility')
        end
    end   
end
end