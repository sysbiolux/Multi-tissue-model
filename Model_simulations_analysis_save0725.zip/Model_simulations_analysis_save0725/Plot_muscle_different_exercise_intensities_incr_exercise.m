clearvars;clc;
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');

load('Results_healthy_exercise_sim_3.mat','lp_sols','Results','model')

res_sol_1=zeros(numel(lp_sols{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_1(:,i)=lp_sols{i}.x(1:numel(lp_sols{1}.x));
        end
    end
%    ExerciseStartingTime1=ExerciseStartingTime;
%    ExerciseStoppingTime1=ExerciseStoppingTime;
%     FoodApplicationTime1=FoodApplicationTime;
%     Results1=Results;
    clear Results qp_sols lp_sols FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

%% steady exercise break plus incremental exercise
% model=SetupModel;
x=255;
fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
rxns={'Muscle_glc_D';'Muscle_fa';'Muscle_tag_hs';'Muscle_GLYGN2_IMP';'Foxid';'Goxid'};%;'Fat_Rtotal2';'Fat_Rtotal3'};
% rxns=rxns(ismember(rxns,model.rxns));
nrows = 2;
ncols = 3;
labels={'Muscle: Glucose uptake','Muscle: Fatty acids uptake','Muscle: Other Fat sources',...
    'Muscle: Glycogen usage','Muscle: Fatty acids oxidation','Muscle: Glucose oxidation'};

 for r= 1 : numel(rxns)
%     if nrows*ncols-mod(-r, nrows*ncols) == 1
%         fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
% %         H=suptitle(['Simulation of Exercise with Meal']);
% %         set(H,'FontSize',20,'Position',[0.5,-0.02,0])
%     end
    if strcmp(rxns(r),'Muscle_fa')
           Muscle = BoundedReactions{[72:74,128:167],1};%
           Muscle=Muscle(ismember(Muscle,model.rxns));  
           pos=ismember(model.rxns,Muscle(:,1));
           basal_fa=trapz(abs(sum(res_sol_1(pos,712:719))));
           exerc70_fa=trapz(abs(sum(res_sol_1(pos,727:734)))); %beginning of exercising at 70% after the 5 min warm up
           basal_post_fa=trapz(abs(sum(res_sol_1(pos,862:869))));
           exerc70_post_fa=trapz(abs(sum(res_sol_1(pos,872:879))));
           exerc80_fa=trapz(abs(sum(res_sol_1(pos,882:889))));
           exerc90_fa=trapz(abs(sum(res_sol_1(pos,892:899))));
%            exerc40=trapz(abs(sum(res_sol_40(pos,722:729))));
%            exerc60=trapz(abs(sum(res_sol_60(pos,722:729))));
           clear pos  
    elseif strcmp(rxns(r),'Foxid')
        subplot(2, 2,1);
        fa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'coa['))&cellfun(@isempty,strfind(model.mets,'_coa['))&...
            cellfun(@isempty,strfind(model.mets,'_accoa['))&cellfun(@isempty,strfind(model.mets,'[x]'))&~cellfun(@isempty,strfind(model.mets,'[m]'))));
        accoa=findRxnsFromMets(model,model.mets(~cellfun(@isempty,strfind(model.mets,'accoa['))));
        rxns_fox=intersect(fa,accoa);
        rxns_fox=rxns_fox(~cellfun(@isempty,strfind(rxns_fox,'FAOX'))&~cellfun(@isempty,strfind(rxns_fox,'Muscle')));
        rxns_fox_sup={'Muscle_ACACT10m';'Muscle_MCDm';'Muscle_r0287';'Muscle_r0639';'Muscle_r0653';'Muscle_r0732';'Muscle_RE1533M';'Muscle_RE3006M';'Muscle_r0724'};
        rxns_fox=[rxns_fox;rxns_fox_sup];
        pos=ismember(model.rxns,rxns_fox);
        pos_met=ismember(model.mets,'Muscle_accoa[m]');
        coef=full(model.S(pos_met,pos));
        basal=trapz(abs(sum(bsxfun(@times,coef',res_sol_1(pos,712:719)))));
        exerc70=trapz(abs(sum(bsxfun(@times,coef',res_sol_1(pos,727:734))))); %beginning of exercising at 70% after the 5 min warm up
        basal_post=trapz(abs(sum(bsxfun(@times,coef',res_sol_1(pos,862:869)))));
        exerc70_post=trapz(abs(sum(bsxfun(@times,coef',res_sol_1(pos,872:879)))));
        exerc80=trapz(abs(sum(bsxfun(@times,coef',res_sol_1(pos,882:889)))));
        exerc90=trapz(abs(sum(bsxfun(@times,coef',res_sol_1(pos,892:899)))));%

        clear pos  
        b= bar([basal,exerc70,basal_post,exerc70_post,exerc80,exerc90]);
        set(gca,'XTickLabel', {'Rest','70%','PE Rest','70%','80%','90%'});
        set(b,{'FaceColor'},{[178/x,177/x,169/x]});

        ylabel(['AUC', labels(r), '[\mumol]'],'FontSize',14)
        xlabel(['Exercise intensity', {'[% V0_2_m_a_x]'}],'FontSize',12)
    elseif strcmp(rxns(r),'Goxid')
                subplot(2, 2,2);

           pos=ismember(model.rxns,{'Muscle_PDHm'});
           basal=trapz(abs((res_sol_1(pos,712:719))));
           exerc70=trapz(abs((res_sol_1(pos,727:734)))); %beginning of exercising at 70% after the 5 min warm up
           basal_post=trapz(abs((res_sol_1(pos,862:869))));
           exerc70_post=trapz(abs((res_sol_1(pos,872:879))));
           exerc80=trapz(abs((res_sol_1(pos,882:889))));
           exerc90=trapz(abs((res_sol_1(pos,892:899))));%   
%            exerc40=trapz(abs((res_sol_40(pos,722:729))));
%            exerc60=trapz(abs((res_sol_60(pos,722:729))));
%            rxns{r}='Whole-model Fatty acid oxidation'; 
              b= bar([basal,exerc70,basal_post,exerc70_post,exerc80,exerc90]);
        set(gca,'XTickLabel', {'Rest','70%','PE Rest','70%','80%','90%'});
        set(b,{'FaceColor'},{[178/x,177/x,169/x]});
        ylabel(['AUC', labels(r), '[\mumol]'],'FontSize',14)
        xlabel(['Exercise intensity', {'[% V0_2_m_a_x]'}],'FontSize',12)
        clear pos  
    elseif strcmp(rxns(r),'Muscle_tag_hs')
           pos=ismember(model.rxns,{'Muscle_tag_hs','Muscle_tag_stores_imp'});
           basal_tag=trapz(abs(sum(res_sol_1(pos,712:719))));
           exerc70_tag=trapz(abs(sum(res_sol_1(pos,727:734)))); %beginning of exercising at 70% after the 5 min warm up
           basal_post_tag=trapz(abs(sum(res_sol_1(pos,862:869))));
           exerc70_post_tag=trapz(abs(sum(res_sol_1(pos,872:879))));
           exerc80_tag=trapz(abs(sum(res_sol_1(pos,882:889))));
           exerc90_tag=trapz(abs(sum(res_sol_1(pos,892:899))));
%            exerc40=trapz(abs(sum(res_sol_40(pos,722:729))));
%            exerc60=trapz(abs(sum(res_sol_60(pos,722:729))));
           %            rxns{r}='Whole-model Fatty acid oxidation'; 
           clear pos  
    elseif strcmp(rxns(r),'Muscle_glc_D')
           pos=ismember(model.rxns,rxns(r));
            basal_glc=trapz(abs((res_sol_1(pos,712:719))));
            exerc70_glc=trapz(abs((res_sol_1(pos,727:734)))); %beginning of exercising at 70% after the 5 min warm up
           basal_post_glc=trapz(abs((res_sol_1(pos,862:869))));
           exerc70_post_glc=trapz(abs((res_sol_1(pos,872:879))));
           exerc80_glc=trapz(abs((res_sol_1(pos,882:889))));
           exerc90_glc=trapz(abs((res_sol_1(pos,892:899))));  
%            exerc40=trapz(abs((res_sol_40(pos,722:729))));
%            exerc60=trapz(abs((res_sol_60(pos,722:729))));
           clear pos
     elseif strcmp(rxns(r),'Muscle_GLYGN2_IMP')
            pos=ismember(model.rxns,rxns(r));
           basal_glyco=trapz(abs((res_sol_1(pos,712:719))));
           exerc70_glyco=trapz(abs((res_sol_1(pos,727:734)))); %beginning of exercising at 70% after the 5 min warm up
           basal_post_glyco=trapz(abs((res_sol_1(pos,862:869))));
           exerc70_post_glyco=trapz(abs((res_sol_1(pos,872:879))));
           exerc80_glyco=trapz(abs((res_sol_1(pos,882:889))));
           exerc90_glyco=trapz(abs((res_sol_1(pos,892:899))));  
%            exerc40=trapz(abs((res_sol_40(pos,722:729))));
%            exerc60=trapz(abs((res_sol_60(pos,722:729))));
           clear pos
    end
    
 end
 x=255;
 
  subplot(2,2,3);
 energy_fa=1;%106;
 energy_glc=1;%31;
 
 basal=[basal_fa*energy_fa,basal_tag*3*energy_fa,basal_glc*energy_glc,basal_glyco*11*energy_glc];
%  basal=basal/sum(basal)*100;
 
 exerc70=[exerc70_fa*energy_fa,exerc70_tag*3*energy_fa,exerc70_glc*energy_glc,exerc70_glyco*11*energy_glc];
%  exerc70=exerc70/sum(exerc70)*100;
 
  basal_post=[basal_post_fa*energy_fa,basal_post_tag*3*energy_fa,basal_post_glc*energy_glc,basal_post_glyco*11*energy_glc];
%  basal_post=basal_post/sum(basal_post)*100;
 
 exerc70_post=[exerc70_post_fa*energy_fa,exerc70_post_tag*3*energy_fa,exerc70_post_glc*energy_glc,exerc70_post_glyco*11*energy_glc];
%  exerc70_post=exerc70_post/sum(exerc70_post)*100;
 
  exerc80=[exerc80_fa*energy_fa,exerc80_tag*3*energy_fa,exerc80_glc*energy_glc,exerc80_glyco*11*energy_glc];
%  exerc80=exerc80/sum(exerc80)*100;
 
  exerc90=[exerc90_fa*energy_fa,exerc90_tag*3*energy_fa,exerc90_glc*energy_glc,exerc90_glyco*11*energy_glc];
%  exerc90=exerc90/sum(exerc90)*100;
 
 y=[basal;exerc70;basal_post;exerc70_post;exerc80;exerc90];
     b=bar(y,'stacked');
        set(gca,'XTickLabel', {'Rest','70%','PE Rest','70%','80%','90%'});
        set(b,{'FaceColor'},{[229/x,192/x,23/x];[231/x,155/x,155/x];[178/x,177/x,169/x];[207/x,226/x,239/x]});
        
 ylabel([{'Available energy source'},{'for ATP production'}],'FontSize',14)
 xlabel(['Exercise intensity', {'[% VO_2_m_a_x]'}],'FontSize',12)
 
 subplot(2,2,4);
%  energy_fa=106;
%  energy_glc=31;
 
 basal=[basal_fa*energy_fa,basal_tag*3*energy_fa,basal_glc*energy_glc,basal_glyco*11*energy_glc];
 basal=basal/sum(basal)*100;
 
 exerc70=[exerc70_fa*energy_fa,exerc70_tag*3*energy_fa,exerc70_glc*energy_glc,exerc70_glyco*11*energy_glc];
 exerc70=exerc70/sum(exerc70)*100;
 
  basal_post=[basal_post_fa*energy_fa,basal_post_tag*3*energy_fa,basal_post_glc*energy_glc,basal_post_glyco*11*energy_glc];
 basal_post=basal_post/sum(basal_post)*100;
 
 exerc70_post=[exerc70_post_fa*energy_fa,exerc70_post_tag*3*energy_fa,exerc70_post_glc*energy_glc,exerc70_post_glyco*11*energy_glc];
 exerc70_post=exerc70_post/sum(exerc70_post)*100;
 
  exerc80=[exerc80_fa*energy_fa,exerc80_tag*3*energy_fa,exerc80_glc*energy_glc,exerc80_glyco*11*energy_glc];
 exerc80=exerc80/sum(exerc80)*100;
 
  exerc90=[exerc90_fa*energy_fa,exerc90_tag*3*energy_fa,exerc90_glc*energy_glc,exerc90_glyco*11*energy_glc];
 exerc90=exerc90/sum(exerc90)*100;
 
 y=[basal;exerc70;basal_post;exerc70_post;exerc80;exerc90];
     b=bar(y,'stacked');
        set(gca,'XTickLabel', {'Rest','70%','PE Rest','70%','80%','90%'});
        set(b,{'FaceColor'},{[229/x,192/x,23/x];[231/x,155/x,155/x];[178/x,177/x,169/x];[207/x,226/x,239/x]});
        
 ylabel([{'% Available energy source'},{'for ATP production'}],'FontSize',14)
 xlabel(['Exercise intensity', {'[% VO_2_m_a_x]'}],'FontSize',12)
% b.FaceColor = [0 0.5 0.5];

% L=legend({'Free fatty acids','Other fat sources','Plasma Glucose','Muscle Glycogen'});
% L.FontSize=14;
ylim([0,100])
fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 25 15];
% saveas(fig1,'Incremental_exerc_energy_sources_oxidation.svg')