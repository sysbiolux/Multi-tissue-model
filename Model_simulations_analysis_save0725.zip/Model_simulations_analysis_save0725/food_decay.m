function [blood_stores,food_left,food_rates]=food_decay(blood_stores,food_left,count,initial_food,params,step_size)
% params=['store_ala_L[bl]';'store_arg_L[bl]';'store_asn_L[bl]';'store_asp_L[bl]';'store_cys_L[bl]';'store_gln_L[bl]';'store_glu_L[bl]';'store_gly[bl]';...
% 'store_his_L[bl]';'store_ile_L[bl]';'store_leu_L[bl]';'store_lys_L[bl]';'store_met_L[bl]';'store_phe_L[bl]';'store_pro_L[bl]';'store_ser_L[bl]';...
% 'store_thr_L[bl]';'store_trp_L[bl]';'store_tyr_L[bl]';'store_val_L[bl]';'store_tag_hs[bl]';'store_glc_D[bl]'];
food_rates=food_left;    
for i=1 : size(food_left,1)
    pos=find(ismember(blood_stores{:,1},food_left{i,1}));

    if food_left{i,2}~=0
            HL=params(i);%+fat*params(i+44);%+fat*params(i+42);        
            tmax=HL;
            N=getchange(food_left{i,2},initial_food{i,2},tmax,step_size);%rate %published equation
            blood_stores{pos,2}=blood_stores{pos,2}+N;
%             if strcmp(food_left{i,3},'-') %balancing food metabolites
%                 pos_h=find(ismember(blood_stores{:,1},{'EX_h'}));
%                 blood_stores{pos_h,2}=blood_stores{pos_h,2}-N; %if metabolite is positive than we remove respective positive charge
%                 res_h=res_h-N;
%             elseif strcmp(food_left{i,3},'+')
%                 pos_h=find(ismember(blood_stores{:,1},{'EX_h'}));
%                 blood_stores{pos_h,2}=blood_stores{pos_h,2}+N; %if metabolite is negative than we add respective positive charge
%                 res_h=res_h+N;
%             end
            food_left{i,2}=food_left{i,2}-N;
            food_rates{i,2}=-N;
    else
        food_rates{i,2}=0;
    end
end
