clearvars;clc;
BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');

disease='Arginase_deficiency';%'3_MCC_deficiency';%
load(['Results_Milan_young_LF_IEM_KD_fraction_0_',disease],'lpsol','Results','model')

res_sol_1=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_1(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_1=Results;
    clear Results qp_sols lpsol FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
     
load(['Results_Milan_young_HF_IEM_KD_fraction_0_',disease],'lpsol','Results','model')
    res_sol_2=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_2(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_2=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

    
load(['Results_no_food_IEM_KD_fraction_0_',disease],'lpsol','Results','model')

    res_sol_3=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_3(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_3=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime    
    
    
    load(['Results_Milan_young_LF_healthy'],'lpsol','Results','model')

res_sol_4=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_4(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_4=Results;
    clear Results qp_sols lpsol FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime
     
load(['Results_Milan_young_HF_healthy'],'lpsol','Results','model')
    res_sol_5=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_5(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_5=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime

    
load(['Results_no_food_healthy'],'lpsol','Results','model')

    res_sol_6=zeros(numel(lpsol{1}.x),size(Results,2)-1);
    for i=1:size(Results,2)-1
        try
        res_sol_6(:,i)=lpsol{i}.x(1:numel(lpsol{1}.x));
        end
    end
    Results_6=Results;

    clear Results qp_sols lpsol  FoodApplicationTime ExerciseStoppingTime ExerciseStartingTime 
    %%
    
rxns={'Hep_urea';'Muscle_urea';'Fat_urea'};%'store_nh4[bl]';'Urine_excretion_nh4';'store_urea[bl]';'Urine_excretion_urea'};%'Hep_CBPSam';'Muscle_CBPSam';'Fat_CBPSam';'Hep_r0034';'Muscle_r0034';'Fat_r0034'};
% rxns={'store_phe_L[bl]','store_tyr_L[bl]', 'Urine_excretion_phe_L','Urine_excretion_tyr_L'};
rxns=rxns(ismember(rxns,model.rxns));
% labels={'Urea production rate','NH_4 blood accumulation','NH_4 urine excretion','Urea blood accumulation','Urea urine excretion'};
labels=rxns;
nrows = 1;
ncols = 1;

 for r= 1 : numel(rxns)
    if nrows*ncols-mod(-r, nrows*ncols) == 1
        fig1=figure('Visible','on','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
%         H=suptitle(['Simulation of Exercise with Meal']);
%         set(H,'FontSize',20,'Position',[0.5,-0.02,0])
    end
    subplot(nrows, ncols, nrows*ncols-mod(-r, nrows*ncols));
    hold on
    
    pos=ismember(model.rxns,rxns(r));
    vector1=(res_sol_1(pos,:));
    vector2=(res_sol_2(pos,:));
    vector3=(res_sol_3(pos,:));
    vector4=(res_sol_4(pos,:));
    vector5=(res_sol_5(pos,:));
    vector6=(res_sol_6(pos,:));
    clear pos

    plot([1:360],vector4,'k','LineWidth',4)
    plot([1:360],vector5,'r','LineWidth',4)
    plot([1:360],vector6,'b','LineWidth',4)
    
    plot([1:360],vector1,'k:','LineWidth',2)
    plot([1:360],vector2,'r:','LineWidth',2)
    plot([1:360],vector3,'b:','LineWidth',2)

        
    ylabel([{'Urea production rate'}, '[\mumol/min]'],'FontSize',14)
    xlabel('Time in min','FontSize',14)
    hold off
 end
L=legend('Healthy: LF meal','Healthy: HF meal','Healthy: Fasting','Arginase deficiency: LF meal','Arginase deficiency: HF meal','Arginase deficiency: Fasting');
L.FontSize=12;
L.Location='bestoutside';
xlim([1,360])

fig1.CurrentAxes.XTick=[1,fig1.CurrentAxes.XTick];

fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 25 10];
saveas(fig1,'Urea_production_ARG_IEM.svg')


