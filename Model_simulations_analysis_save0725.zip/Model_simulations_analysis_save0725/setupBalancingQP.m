% function [solqp,qp] = setupBalancingQP(model, ReacsWithBounds, ReacsWithAmounts,Blood_Concentrations)
function  [solqp,solfound] = setupBalancingQP(model,new_rates,params, ReacsWithBounds, ReacsWithAmounts,Blood_Concentrations,ObjConstraintsLP,...
    ObjConstraintsQP,time,food_rates,Muscle_aa_storage,Current_aa_storage,ObjProtein,protein_pos,Current_protein,...
    diet,WorkingDir,previous_sol,step_size)

% if time==966    
%     save('qp_at_966_min')
% elseif time==976
%     save('qp_at_976_min')
% end
qp = Cplex();
% qp.Model.sense='minimize';
qp.Param.timelimit.Cur=60*10;
qp.Param.barrier.algorithm.Cur=1;%remove numerical difficulties for infeasible simplex optimization
% qp.Param.simplex.tolerances.feasibility.Cur=1e-9;% feasibility tolerance
% qp.Param.barrier.convergetol.Cur=qp.Param.barrier.convergetol.Cur*10; %remove numerical difficulties
% qp.Param.emphasis.numerical.Cur=1;%remove numerical difficulties
% qp.Param.preprocessing.presolve.Cur =0; %turn off preprocessing


%% create the Cplex model
% qp.Param.emphasis.memory.Cur=1; 
% qp.DisplayFunc='';
% qp.Param.mip.display.Cur=4;
% qp.Param.threads.Cur=8;
% qp.Param.mip.strategy.startalgorithm.Cur=;  
%Initialize with the basic linear problem.
qp.Model.lb = round(model.lb*step_size,4);
qp.Model.ub = round(model.ub*step_size,4);
if time>step_size
    adjusted_rxn_fluxes = (ismember(model.rxns,{'Muscle_tag_stores','Muscle_glygn_stores','Fat_tag_stores','Hep_glygn_stores'}));
    qp.Model.lb(adjusted_rxn_fluxes) = round(model.lb(adjusted_rxn_fluxes),4);
    qp.Model.ub(adjusted_rxn_fluxes) = round(model.ub(adjusted_rxn_fluxes),4);
end
qp.Model.rhs = round(model.b,4);
qp.Model.lhs = round(model.b,4);
qp.Model.colname = model.rxns;
qp.Model.rowname = model.mets;
qp.Model.A = model.S;
%qp.Model.ctype = repmat('C',1,numel(model.rxns));
qp.Model.obj = zeros(numel(model.rxns),1);
%hep_glygn_exp,hep_glygn_imp,muscle_glygn_exp,muscle_glygn_imp,fat_tag_exp,fat_tag_imp
qp.Model.obj(ObjConstraintsLP)=round(-0.001,4); %hep_glygn_exp,muscle_glygn_exp,fat_tag_exp
qp.Model.obj(ObjConstraintsLP(end-1:end))=round(-0.0001,4);%fat_tag_exp %muscle_tag_exp
% qp.Model.obj(ObjConstraints(end-1))=-0.00001;%fat_tag_exp
%
% qp.Model.obj(ObjConstraintsQP(end))=-10;
%and initialize the Q matrix
Q = sparse(numel(model.rxns),numel(model.rxns));
% [qp.Model.lb(find(ismember(model.rxns,{'Hep_lnlc','store_o2[bl]'}))),qp.Model.ub(find(ismember(model.rxns,{'Hep_lnlc','store_o2[bl]'})))]

% for each Reaction with bounds, we will add this as an flexible constraint
% (i.e. it should be within those constraints, if at all possible)
%% Set the literature fluxes as flexible constraints
[a,b]=ismember(model.rxns,ReacsWithBounds{:,1});
dim_rxns=sum(a);
qp.Model.lb(a) = round(max(-1000000,qp.Model.lb(a)),4);
qp.Model.ub(a) = round(min(1000000,qp.Model.ub(a)),4);
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(a), '_compound_meas');

A=sparse(dim_rxns,numel(a));
A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows(round(ReacsWithBounds{b(a),2}*step_size,4),constraint_matrix, round(ReacsWithBounds{b(a),3}*step_size,4),char(names));

pen_matrix=sparse(speye(dim_rxns));
x=46; %Muscle_o2
pen_matrix(x,x)=0.01;%WORKING OK 0.01

% x=50; %Muscle_tag_hs
% pen_matrix(x,x)=5;
% 
% x=77; %Fat_tag_hs
% pen_matrix(x,x)=5;
% 
% x=19; %Hep_tag_hs
% pen_matrix(x,x)=5;

x=81; %Hep_glygn_stores
pen_matrix(x,x)=75;

Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)),pen_matrix];
% Q = [Q, sparse(numel(model.rxns),dim_rxns);sparse(dim_rxns,numel(model.rxns)), sparse(speye(dim_rxns))];
%         counter_i=dim_rxns;

%% Add urine fluxes
constraints = readtable('Metabolites_fluxes_urine_excretion.csv','delimiter',';');
constraints{:,1}=strcat('Urine_excretion_',strrep(constraints{:,1},'[bl]',''));

[a,b]=ismember(model.rxns,constraints{:,1});
dim_rxns=sum(a);
A=sparse(dim_rxns,numel(qp.Model.lb));
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(a), '_compound_meas');
A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows((constraints{b(a),3})*step_size,constraint_matrix, (constraints{b(a),4})*step_size,char(names));
Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];

% PENALIZE SECRETION REACTIONS DIFFERENT DIRECTIONALITY C TO E AND E TO C
index_rxns=(~cellfun(@isempty,strfind(model.rxns,'secretion')));
dim_rxns=sum(index_rxns);
% qp.Model.lb(index_rxns) = 0;
% qp.Model.ub(index_rxns) = 1000000;
A=sparse(dim_rxns,numel(qp.Model.lb));
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(index_rxns), '_compound_meas');
A(sub2ind(size(A),[1:dim_rxns],find(index_rxns')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows(zeros(dim_rxns,1),constraint_matrix, zeros(dim_rxns,1),char(names));
pen_matrix=sparse(speye(dim_rxns));
pen_matrix(pen_matrix==1)=10;
Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)),pen_matrix];

% counter_i=0;
% for i=1:size(ReacsWithBounds,1)
%     rxnpos = ismember(model.rxns,ReacsWithBounds{i,1});
%     if find(rxnpos)
%         counter_i=counter_i+1;
%         qp.Model.lb(rxnpos) = -1000000;
%         qp.Model.ub(rxnpos) = 1000000;
%     %     pos=find(ismember(liver_constraints{:,1},ReacsWithBounds{i,1}));
% 
%         qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000);
%     %     if isempty(pos)||food_rates{pos,2}==0%||strcmp(food_rates{pos,1},'tag_hs_FOOD')
% %             a=[rxnpos ;sparse(counter_i-1,1); -1]';
%             qp.addRows(ReacsWithBounds{i,2},[rxnpos ;sparse(counter_i-1,1); -1]', ReacsWithBounds{i,3},[model.rxns{rxnpos} '_compound_meas']);
%     %     else
%     %         min_release=abs(liver_constraints{pos,2}*food_rates{pos,2}/100);
%     %         max_release=abs(liver_constraints{pos,3}*food_rates{pos,2}/100);
%     %         qp.addRows(min_release,[rxnpos;sparse(i-1,1) ; -1]', max_release,[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
%     %     end
%         Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1];
%     else
%         warning(strjoin(['rxn',ReacsWithBounds{i,1},'is not present in the model!']))
%     end
% end

% [cellstr(qp.Model.rowname([(numel(model.mets)+1):(numel(model.mets)+counter_i)],:)),num2cell(qp.Model.lhs([(numel(model.mets)+1):(numel(model.mets)+counter_i)],1)),num2cell(qp.Model.rhs([(numel(model.mets)+1):(numel(model.mets)+counter_i)],1))]

% counter=0;
food_index=food_rates{:,2}~=0;
% food_index(end)=0; %do not adjust bound for glucose

% Food_stores={'store_ala_L[bl]';'store_arg_L[bl]';'store_asn_L[bl]';'store_asp_L[bl]';'store_cys_L[bl]';'store_gln_L[bl]';'store_glu_L[bl]';'store_gly[bl]';'store_his_L[bl]';'store_ile_L[bl]';'store_leu_L[bl]';...
%     'store_lys_L[bl]';'store_met_L[bl]';'store_phe_L[bl]';'store_pro_L[bl]';'store_ser_L[bl]';'store_thr_L[bl]';'store_trp_L[bl]';'store_tyr_L[bl]';'store_val_L[bl]';'store_tag_hs[bl]';'store_glc_D[bl]'};
% Food=Food_stores(food_index); %flexible
% Food=currentFood(food_index);
Food=food_rates{food_index,1};

% for j=1:size(ReacsWithAmounts,1)    
%         food_pos=find(ismember(Food,ReacsWithAmounts{j,1}));
%         rxnpos = ismember(model.rxns,ReacsWithAmounts{j,1});        
%         if Blood_Concentrations{j,2}==0
%             qp.Model.lb(rxnpos) = 0;
%             qp.Model.ub(rxnpos) = 0;
% %             qp.addRows(-ReacsWithAmounts{j,2},[rxnpos;sparse(j+i-1,1) ; -1]', -ReacsWithAmounts{j,2},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
% %             Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1];
%         else
%             counter=counter+1;
%             qp.Model.lb(rxnpos) = -1000000;
%             qp.Model.ub(rxnpos) = 1000000;
%             qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds
%             if (isempty(food_pos)&&(Blood_Concentrations{j,2}+ReacsWithAmounts{j,2}<Blood_Concentrations{j,3}))...
%                 || (isempty(food_pos)&&((Blood_Concentrations{j,2}+ReacsWithAmounts{j,2})>Blood_Concentrations{j,4}))    %below min value force storage
%                 qp.addRows(ReacsWithAmounts{j,3},[rxnpos;sparse(counter+i-1,1) ; -1]', ReacsWithAmounts{j,4},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
%             else
%                 qp.addRows(-ReacsWithAmounts{j,2},[rxnpos;sparse(counter+i-1,1) ; -1]',-ReacsWithAmounts{j,2},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
%             end
%             Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1/(Blood_Concentrations{j,2})];
% %             res(counter)=1/(Blood_Concentrations{j,2}^2);
% 
%         end
% end
% counter=0;
% for j=1:size(ReacsWithAmounts,1)    
%         food_pos=find(ismember(Food,ReacsWithAmounts{j,1}));
%         rxnpos = ismember(model.rxns,ReacsWithAmounts{j,1});        
%         if Blood_Concentrations{j,2}==0&&~strcmp(ReacsWithAmounts{j,1},{'store_protein[bl]'})&&~strcmp(ReacsWithAmounts{j,8},{'True'})
%             qp.Model.lb(rxnpos) = 0;
%             qp.Model.ub(rxnpos) = 0;
% %         else
% % (abs(ReacsWithAmounts{j,2})+Blood_Concentrations{j,2})/Blood_Concentrations{j,2}
% %         elseif strcmp(ReacsWithAmounts{j,1},{'store_protein[bl]'})
% %             max_protein=-(4.4680e+07-sum(Muscle_aa_storage{:,2}));
% %                 if (ReacsWithAmounts{j,2}<=max_protein) %(4.4680e+07-sum(Muscle_aa_storage{:,2}) 6.11kg of degradable protein
% %                     qp.Model.lb(rxnpos) = 0;
% %                 else
% %                     qp.Model.lb(rxnpos) = max(max_protein-(ReacsWithAmounts{j,2}),-1000000);
% %                 end
%         elseif isempty(food_pos)
%             counter=counter+1;
% %              if Blood_Concentrations{j,2}==0
%                 if (Blood_Concentrations{j,2}+ReacsWithAmounts{j,2}<=0)
%                     qp.Model.lb(rxnpos) = 0;
%                 %                 qp.Model.ub(rxnpos) = ReacsWithAmounts{j,4};
%                 else
%                     qp.Model.lb(rxnpos) = -(Blood_Concentrations{j,2}+ReacsWithAmounts{j,2});
%                 end
% %              else
% %                 if (Blood_Concentrations{j,2}+ReacsWithAmounts{j,2}<Blood_Concentrations{j,3})
% %                     qp.Model.lb(rxnpos) = 0;
% %                     qp.Model.ub(rxnpos) = ReacsWithAmounts{j,4};
% %                 elseif (Blood_Concentrations{j,2}+ReacsWithAmounts{j,2}>Blood_Concentrations{j,4})
% %                     qp.Model.lb(rxnpos) = ReacsWithAmounts{j,3};
% %                     qp.Model.ub(rxnpos) = 0;
% %                 else
% %                     qp.Model.lb(rxnpos) = ReacsWithAmounts{j,3};
% %                     qp.Model.ub(rxnpos) = ReacsWithAmounts{j,4};
% %                 end
% %              end
%             qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds   
%             qp.addRows(-ReacsWithAmounts{j,2},[rxnpos;sparse(counter+counter_i-1,1) ; -1]',-ReacsWithAmounts{j,2},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
% %             if Blood_Concentrations{j,2}~=0
% %                 Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)),1];%(abs(ReacsWithAmounts{j,2})^1.5+Blood_Concentrations{j,2})/Blood_Concentrations{j,2}];% (Blood_Concentrations{j,2})*min(Blood_Concentrations{:,2}(Blood_Concentrations{:,2}>0))];%/(Blood_Concentrations{j,2})];
% %             else
%                 Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)),1];% (Blood_Concentrations{j,2})*min(Blood_Concentrations{:,2}(Blood_Concentrations{:,2}>0))];%/(Blood_Concentrations{j,2})];
% %             end
% %(Blood_Concentrations{j,2})*min(Blood_Concentrations{:,2}(Blood_Concentrations{:,2}>0))
%          else
%             counter=counter+1;
% %             qp.Model.ub(rxnpos) = 1000000;
%             
%              if (Blood_Concentrations{j,2}+ReacsWithAmounts{j,2}<=0)
%                 qp.Model.lb(rxnpos) = 0;
%              else
%                 pos=ismember(new_rates{:,1},Blood_Concentrations{j,1});
%                 qp.Model.lb(rxnpos) = new_rates{pos,3};
%              end        
%             qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds   
%             qp.addRows(-ReacsWithAmounts{j,2},[rxnpos;sparse(counter+counter_i-1,1) ; -1]',-ReacsWithAmounts{j,2},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction                              
%             Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)),1];% (abs(ReacsWithAmounts{j,2})+Blood_Concentrations{j,2})/Blood_Concentrations{j,2}];%(Blood_Concentrations{j,2})*min(Blood_Concentrations{:,2}(Blood_Concentrations{:,2}>0))];%/(Blood_Concentrations{j,2})];
%         end
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% not_blood_indexes=Blood_Concentrations{:,2}==0 & ~strcmp(ReacsWithAmounts{:,8},{'True'});
% not_food_indexes=~ismember(ReacsWithAmounts{:,1},Food);
% negative_conc=(Blood_Concentrations{:,2}+ReacsWithAmounts{:,2}<=0);
% 
% %% mets not in blood
% not_blood=ReacsWithAmounts(not_blood_indexes,:);
% a=ismember(model.rxns,not_blood{:,1});
% qp.Model.lb(a) = 0;
% % qp.Model.ub(a) = 0;
% 
% %% mets not in food
% not_food_negative_conc=ReacsWithAmounts(not_food_indexes&negative_conc&~not_blood_indexes,:);
% % not_food_negative_conc=ReacsWithAmounts(Blood_Concentrations{:,2}==0 & ~strcmp(ReacsWithAmounts{:,8},{'True'}) ,:);
% [a]=ismember(model.rxns,not_food_negative_conc{:,1});
% qp.Model.lb(a) = 0;
% % qp.Model.ub(a) = 0;
% 
% initial_conc=Blood_Concentrations(not_food_indexes&~negative_conc&~not_blood_indexes,:);
% not_food_positive_conc=ReacsWithAmounts(not_food_indexes&~negative_conc&~not_blood_indexes,:);
% % not_food_negative_conc=ReacsWithAmounts(Blood_Concentrations{:,2}==0 & ~strcmp(ReacsWithAmounts{:,8},{'True'}) ,:);
% [a,b]=ismember(model.rxns,not_food_positive_conc{:,1});
% qp.Model.lb(a) = (-(initial_conc{b(a),2}+not_food_positive_conc{b(a),2}),2);
% 
% not_food=ReacsWithAmounts(not_food_indexes&~not_blood_indexes,:);
% [a,b]=ismember(model.rxns,not_food{:,1});
% dim_rxns=sum(a);
% A=sparse(dim_rxns,numel(qp.Model.lb));
% qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
% names=strcat(model.rxns(a), '_compound_meas');
% A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
% constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
% qp.addRows((-not_food{b(a),2},2),constraint_matrix, (-not_food{b(a),2},2),char(names));
% Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];
% % counter_blood=dim_rxns;
% 
% %% mets in food
% food_negative_conc=ReacsWithAmounts(~not_food_indexes&negative_conc&~not_blood_indexes,:);
% [a]=ismember(model.rxns,food_negative_conc{:,1});
% qp.Model.lb(a) = 0;
% % qp.Model.ub(a) = 0;
% 
% food_positive_conc=ReacsWithAmounts(~not_food_indexes&~negative_conc&~not_blood_indexes,:);
% [a_model]=ismember(model.rxns,food_positive_conc{:,1});
% [rates_pres,rates_pos]=ismember(model.rxns(a_model),new_rates{:,1});
% qp.Model.lb(a_model) =( new_rates{rates_pos(rates_pres),3},2);
% 
% food=ReacsWithAmounts(~not_food_indexes&~not_blood_indexes,:);
% [a,b]=ismember(model.rxns,food{:,1});
% dim_rxns=sum(a);
% A=sparse(dim_rxns,numel(qp.Model.lb));
% qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
% names=strcat(model.rxns(a), '_compound_meas');
% A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
% constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
% qp.addRows((-food{b(a),2},2),constraint_matrix, (-food{b(a),2},2),char(names));
% Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
% not_blood_indexes=Blood_Concentrations{:,2}==0 & ~strcmp(ReacsWithAmounts{:,8},{'True'});
not_food_indexes=~ismember(ReacsWithAmounts{:,1},Food);
negative_conc=(Blood_Concentrations{:,2}+ReacsWithAmounts{:,2})<=0;

% mets not in blood
% not_blood=ReacsWithAmounts(not_blood_indexes,:);
% a=ismember(model.rxns,not_blood{:,1});
% qp.Model.lb(a) = 0;
% qp.Model.ub(a) = 0;

% mets not in food
not_food_negative_conc=ReacsWithAmounts(not_food_indexes&negative_conc,:);
% not_food_negative_conc=ReacsWithAmounts(Blood_Concentrations{:,2}==0 & ~strcmp(ReacsWithAmounts{:,8},{'True'}) ,:);
[a]=ismember(model.rxns,not_food_negative_conc{:,1});
qp.Model.lb(a) = 0;
% qp.Model.ub(a) = 0;

initial_conc=Blood_Concentrations(not_food_indexes&~negative_conc,:);
not_food_positive_conc=ReacsWithAmounts(not_food_indexes&~negative_conc,:);
% not_food_negative_conc=ReacsWithAmounts(Blood_Concentrations{:,2}==0 & ~strcmp(ReacsWithAmounts{:,8},{'True'}) ,:);
[a,b]=ismember(model.rxns,not_food_positive_conc{:,1});
qp.Model.lb(a) = round(-(initial_conc{b(a),2}+not_food_positive_conc{b(a),2}),4);

not_food=ReacsWithAmounts(not_food_indexes,:);
[a,b]=ismember(model.rxns,not_food{:,1});
dim_rxns=sum(a);
A=sparse(dim_rxns,numel(qp.Model.lb));
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(a), '_compound_meas');
A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows(round(-not_food{b(a),2},4),constraint_matrix, round(-not_food{b(a),2},4),char(names));
Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];
% counter_blood=dim_rxns;

%% add an additionnal constraint for concentrations not above or below range
not_food=ReacsWithAmounts(not_food_indexes,:);
[a,b]=ismember(model.rxns,not_food{:,1});
dim_rxns=sum(a);
A=sparse(dim_rxns,numel(qp.Model.lb));
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(a), '_compound_meas');
A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows(round(min(not_food{b(a),3:6},[],2),4),constraint_matrix, round(max(not_food{b(a),3:6},[],2),4),char(names));
Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];

% mets in food
food_negative_conc=ReacsWithAmounts(~not_food_indexes&negative_conc,:);
[a]=ismember(model.rxns,food_negative_conc{:,1});
qp.Model.lb(a) = 0;
% qp.Model.ub(a) = 0;

% food=ReacsWithAmounts(~not_food_indexes&negative_conc,:);
% [a,b]=ismember(model.rxns,food{:,1});
% dim_rxns=sum(a);
% A=sparse(dim_rxns,numel(qp.Model.lb));
% qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
% names=strcat(model.rxns(a), '_compound_meas');
% A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
% constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
% qp.addRows(round(-food{b(a),2},4),constraint_matrix, round(-food{b(a),2},4),char(names));
% Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];


food_positive_conc=ReacsWithAmounts(~not_food_indexes&~negative_conc,:);
[a_model,b]=ismember(model.rxns,food_positive_conc{:,1});
[rates_pres,rates_pos]=ismember(model.rxns(a_model),new_rates{:,1});
qp.Model.lb(a_model) =round(new_rates{rates_pos(rates_pres),3}*step_size,4);
% 
% dim_rxns=sum(a_model);
% A=sparse(dim_rxns,numel(qp.Model.lb));
% qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
% names=strcat(model.rxns(a_model), '_compound_meas');
% A(sub2ind(size(A),[1:dim_rxns],find(a_model')))=1;
% constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
% qp.addRows(round(min(new_rates{rates_pos(rates_pres),3},-food_positive_conc{b(a_model),2}),4),constraint_matrix, round(max(new_rates{rates_pos(rates_pres),3},-food_positive_conc{b(a_model),2}),4),char(names));
% Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];

food=ReacsWithAmounts(~not_food_indexes,:);
[a,b]=ismember(model.rxns,food{:,1});
dim_rxns=sum(a);
A=sparse(dim_rxns,numel(qp.Model.lb));
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(a), '_compound_meas');
A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows(round(-food{b(a),2},4),constraint_matrix, round(-food{b(a),2},4),char(names));
Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% counter_food=dim_rxns; 

% counter=counter_blood+counter_food;

o=0;
% j=0;
% nh4_release={'Hep_nh4','Muscle_nh4','Fat_nh4'};
% for o=1:size(nh4_release,1)
%     rxnpos = ismember(model.rxns,nh4_release{o});
%     qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds
% %     qp.addRows(-1000000,[rxnpos;sparse(counter+i+o-1,1) ; -1]', 0,[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
%     qp.addRows(0,[rxnpos;sparse(counter+i+o-1,1) ; -1]', 0,[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
% 
%     Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1];
% end

% ncounter=0;
% for n=1:size(Current_aa_storage,1)
%         rxnpos = ismember(model.rxns,Current_aa_storage{n,1});
% %         if ~strcmp(Current_aa_storage{n,5},'0')
% %             ncounter=ncounter+1;
% %             rxn=[Current_aa_storage{n,1},Current_aa_storage{n,5}];
% %             qp=addSumFluxConstraints(qp, model, Current_aa_storage{n,4},Current_aa_storage{n,3},rxn,[1,1]);
% %             
% %             qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds   
% %             qp.addRows(-Current_aa_storage{n,2},[rxnpos;sparse(counter+i+ncounter+o-1,1) ; -1]',-Current_aa_storage{n,2},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
% %             Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1];%(Muscle_aa_storage{n,2}/(32/1.1))/max(max(Muscle_aa_storage{:,2})/(32/1.1),max(Blood_Concentrations{:,2})/5)/(32/1.1)];
% % %                             qp.Model.lb(rxnpos) = 0;
% % %                 qp.Model.ub(rxnpos) = 0;
% %                 
% %             ncounter=ncounter+1;
% %             rxnpos = ismember(model.rxns,Current_aa_storage{n,5});
% % %                             qp.Model.lb(rxnpos) = 0;
% % %                 qp.Model.ub(rxnpos) = 0;
% %             qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds   
% %             qp.addRows(-Current_aa_storage{n,2},[rxnpos;sparse(counter+i+ncounter+o-1,1) ; -1]',-Current_aa_storage{n,2},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
% %             Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1];%(Muscle_aa_storage{n,2}/(32/1.1))/max(max(Muscle_aa_storage{:,2})/(32/1.1),max(Blood_Concentrations{:,2})/5)/(32/1.1)];
% %         else
%             ncounter=ncounter+1;
% %             if (Muscle_aa_storage{n,2}+Current_aa_storage{n,2}<Muscle_aa_storage{n,3})
% %                 qp.Model.lb(rxnpos) = 0;
% %                 qp.Model.ub(rxnpos) = Current_aa_storage{n,4};
% %             elseif (Muscle_aa_storage{n,2}+Current_aa_storage{n,2}>Muscle_aa_storage{n,4})
% %                 qp.Model.lb(rxnpos) = Current_aa_storage{n,3};
% %                 qp.Model.ub(rxnpos) = 0;
% %             else
% % %                 qp.Model.lb(rxnpos) = 0;
% % %                 qp.Model.ub(rxnpos) = 0;
%             if (Muscle_aa_storage{n,2}+Current_aa_storage{n,2}<=0)
%                 qp.Model.lb(rxnpos) = 0;
%                 qp.Model.ub(rxnpos) = Current_aa_storage{n,4};
%             else
%                 qp.Model.lb(rxnpos) = -(Muscle_aa_storage{n,2}+Current_aa_storage{n,2}); %allow to deplete muscle free amino...
%                 %acids but not to go above max val
%                 qp.Model.ub(rxnpos) = Current_aa_storage{n,4};
%             end
% %                 qp.Model.lb(rxnpos) = Current_aa_storage{n,3};
% %                 qp.Model.ub(rxnpos) = Current_aa_storage{n,4};
% %             end
%             qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds   
%             qp.addRows(-Current_aa_storage{n,2},[rxnpos;sparse(counter+counter_i+ncounter+o-1,1) ; -1]',-Current_aa_storage{n,2},[model.rxns{rxnpos} '_compound_meas']); %changes rhs and lhs of last added reaction
%             Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1];%(Muscle_aa_storage{n,2}/(32/1.1))/max(max(Muscle_aa_storage{:,2})/(32/1.1),max(Blood_Concentrations{:,2})/5)/(32/1.1)];
%             
% %         end
% %         count=count+1;
% %             res(count,1:2)=[Current_aa_storage{n,1},num2cell( (Muscle_aa_storage{n,2}/(32/1.1))/max(max(Muscle_aa_storage{:,2})/(32/1.1),max(Blood_Concentrations{:,2})/5)/(32/1.1))];
% end
% 
negative_conc=(Muscle_aa_storage{:,2}+Current_aa_storage{:,2})<=0;
aa_negative_conc=Current_aa_storage(negative_conc,:);
[a,b]=ismember(model.rxns,aa_negative_conc{:,1});
qp.Model.lb(a) = 0;
qp.Model.ub(a) = round(aa_negative_conc{b(a),4},4);

Muscle_aa_storage=Muscle_aa_storage(~negative_conc,:);
aa_positive_conc=Current_aa_storage(~negative_conc,:);
[a,b]=ismember(model.rxns,aa_positive_conc{:,1});
qp.Model.lb(a) = round(-(Muscle_aa_storage{b(a),2}+aa_positive_conc{b(a),2}),4); %allow to deplete muscle free amino...
qp.Model.ub(a) = round(aa_positive_conc{b(a),4},4);

aa=Current_aa_storage;
[a,b]=ismember(model.rxns,aa{:,1});
dim_rxns=sum(a);
A=sparse(dim_rxns,numel(qp.Model.lb));
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(a), '_compound_meas');
A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows(round(-aa{b(a),2},4),constraint_matrix, round(-aa{b(a),2},4),char(names));
Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];

% pcounter=0;
% for k=1:size(protein_pos,1)
%             pcounter=pcounter+1;
%             qp.addCols(0,zeros(size(qp.Model.rhs)),-1000000,1000000); %adds reaction with respective bounds   
%             qp.addRows(-Current_protein{k,2},[rxnpos;sparse(counter+counter_i+ncounter+pcounter+o-1,1) ; -1]',-Current_protein{k,2},[model.rxns{protein_pos(k)} '_compound_meas']); %changes rhs and lhs of last added reaction
%             Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 1];%(Muscle_aa_storage{n,2}/(32/1.1))/max(max(Muscle_aa_storage{:,2})/(32/1.1),max(Blood_Concentrations{:,2})/5)/(32/1.1)];            
% end

% qp=addSumFluxConstraints(qp, model, 8400,ObjSumFlux,[1,1]);
% Q = [Q, sparse(size(Q,1),1);sparse(1,size(Q,2)), 0];
% if time>=ExerciseStartingTime&& time<ExerciseStoppingTime+1 && ExerciseIntensity~=0
%     Q(ObjConstraintsQP(3),ObjConstraintsQP(3))=0.09;%7;0.7%,fat_tag_imp
%     Q(ObjConstraintsQP(2),ObjConstraintsQP(2))=0.05;%muscle_glygn_imp
%     Q(ObjConstraintsQP(4),ObjConstraintsQP(4))=0.1;%muscle_fat_imp
%     Q(ObjConstraintsQP(1),ObjConstraintsQP(1))=0.5;%4;%hep_glygn_imp,
% else
    Q(ObjConstraintsQP(3),ObjConstraintsQP(3))=0.4;%7;0.7%,fat_tag_imp
    Q(ObjConstraintsQP(2),ObjConstraintsQP(2))=15;%muscle_glygn_imp%20
    Q(ObjConstraintsQP(4),ObjConstraintsQP(4))=15;%muscle_fat_imp%20
    Q(ObjConstraintsQP(1),ObjConstraintsQP(1))=1.5;%4;%hep_glygn_imp,%1.5
% end
% Q(ObjConstraintsQP(3),ObjConstraintsQP(3))=0;

% Q(ObjProtein(4),ObjProtein(4))=0.7;  %protein degradation hep
% Q(ObjProtein(5),ObjProtein(5))=0.7;  %protein degradation muscle
% Q(ObjProtein(6),ObjProtein(6))=0.7;  %protein degradation fat

%  qp.Model.obj(ObjProtein(1:2))=1; %protein production hep and muscle punish protein production
% qp.Model.obj(ObjProtein(3))=1;%protein production fat

Q(ObjProtein(1),ObjProtein(1))=params(end);  %protein production hep
Q(ObjProtein(2),ObjProtein(2))=params(end);  %protein production muscle
Q(ObjProtein(3),ObjProtein(3))=params(end);  %protein production fat

ObjProteinDeg=model.rxns(ObjProtein(4:end));%sum flux of maximum degradation
qp=addSumFluxConstraints(qp, model,(163.5741*step_size),0,ObjProteinDeg,[1,1,1]);

[a,b]=ismember(model.rxns,model.rxns(ObjProtein(4:end)));
dim_rxns=sum(a);
A=sparse(dim_rxns,numel(qp.Model.lb));
qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
names=strcat(model.rxns(a), '_compound_meas');
A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
qp.addRows(zeros(dim_rxns,1),constraint_matrix, zeros(dim_rxns,1),char(names));
pen_matrix=sparse(speye(dim_rxns));
pen_matrix(2,2)=0.1; %muscle protein degradation
pen_matrix(1,1)=0.9; %liver protein degradation
Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)),pen_matrix];

Co2_rxns={'Hep_co2','Muscle_co2','Fat_co2'};
qp=addSumFluxConstraints(qp, model,8400*step_size,0,Co2_rxns,[1,1,1]);

BoundedReactions = readtable('BoundedReactions_all.csv','delimiter',',');
Fat = BoundedReactions{[69:71,88:127],1};%
Fat=Fat(ismember(Fat,model.rxns));
Hep = BoundedReactions{[66:68,168:207],1};%
Hep=Hep(ismember(Hep,model.rxns));
Muscle = BoundedReactions{[72:74,128:167],1};%
Muscle=Muscle(ismember(Muscle,model.rxns));
qp=addSumFluxConstraints(qp, model,684*step_size,87*step_size,Fat,ones(numel(Fat),1));
qp=addSumFluxConstraints(qp, model,0,-978*step_size,Hep,ones(numel(Hep),1));
qp=addSumFluxConstraints(qp, model,0,-684*step_size,Muscle,ones(numel(Muscle),1));


Co2_rxns={'Hep_co2','Muscle_co2','Fat_co2','Hep_o2','Muscle_o2','Fat_o2'};
Co2_rxns=[Co2_rxns,Fat',Hep',Muscle'];

ObjConstraints=[ObjConstraintsQP,ObjConstraintsLP,find(ismember(model.rxns,Blood_Concentrations{:,1}))',...
    find(ismember(model.rxns,[Muscle_aa_storage{:,1};Co2_rxns']))',ObjProtein',...
    find(~cellfun(@isempty,strfind(model.rxns,'secretion')))',...%find(ismember(model.rxns,BoundedReactions{:,1}))',...
    find(ismember(model.rxns,constraints{:,1}))'];
    intracellularConstraints=[ObjConstraints,find(ismember(model.rxns,BoundedReactions{:,1}))'];
    if time>step_size
        [a]=ismember(model.rxns,model.rxns(intracellularConstraints));
        dim_rxns=sum(a);
        A=sparse(dim_rxns,numel(qp.Model.lb));
        qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
        names=strcat(model.rxns(a), '_compound_meas');
        A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
        constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
        qp.addRows(previous_sol.x(a),constraint_matrix, previous_sol.x(a),char(names));
        pen_matrix=sparse(speye(dim_rxns));
        pen_matrix(pen_matrix==1)=0.001;
        Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)),pen_matrix];        
    end

% glc_oxidation=setdiff([intersect(findRxnsFromMets(model,'Hep_glc_D[c]'),findRxnsFromMets(model,'Hep_glc_D[e]'));...
%     intersect(findRxnsFromMets(model,'Fat_glc_D[c]'),findRxnsFromMets(model,'Fat_glc_D[e]'));...
%     intersect(findRxnsFromMets(model,'Muscle_glc_D[c]'),findRxnsFromMets(model,'Muscle_glc_D[e]'))],'Hep_GLCGLUT2');
% qp=addSumFluxConstraints(qp, model,5333,611,glc_oxidation,ones(1,numel(glc_oxidation)));

% [qp.Model.lb(find(ismember(model.rxns,{'Hep_lnlc','store_o2[bl]'}))),qp.Model.ub(find(ismember(model.rxns,{'Hep_lnlc','store_o2[bl]'})))]
% gaz_rxns={'Hep_co2','Muscle_co2','Fat_co2'};%,'Hep_o2','Muscle_o2','Fat_o2'};
% 
%     if time>1
%         [a]=ismember(model.rxns,gaz_rxns);
%         dim_rxns=sum(a);
%         A=sparse(dim_rxns,numel(qp.Model.lb));
%         qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
%         names=strcat(model.rxns(a), '_compound_meas');
%         A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
%         constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
%         qp.addRows(previous_sol.x(a),constraint_matrix, previous_sol.x(a),char(names));
%         Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];
%         [a]=ismember(model.rxns,ReacsWithBounds{:,1});
%         dim_rxns=sum(a);
%         A=sparse(dim_rxns,numel(qp.Model.lb));
%         qp.addCols(zeros(dim_rxns,1),zeros(size(qp.Model.rhs,1),dim_rxns),repmat(-1000000,dim_rxns,1),repmat(1000000,dim_rxns,1));
%         names=strcat(model.rxns(a), '_compound_meas');
%         A(sub2ind(size(A),[1:dim_rxns],find(a')))=1;
%         constraint_matrix=[A,sparse(diag(repmat(-1,dim_rxns,1)))];
%         qp.addRows(previous_sol.x(a),constraint_matrix, previous_sol.x(a),char(names));
%         Q = [Q, sparse(size(Q,1),dim_rxns);sparse(dim_rxns,size(Q,2)), sparse(speye(dim_rxns))];
%     end

qp.DisplayFunc = [];
qp.Model.Q = Q;

%         qp.Model.lb = (qp.Model.lb);
%         qp.Model.ub = (qp.Model.ub);
%         qp.Model.rhs = (qp.Model.rhs);
%         qp.Model.lhs = (qp.Model.lhs);

% pos=find(ismember(model.rxns,{'Fat_tag_hs','Fat_tag_stores','Fat_tag_stores_imp','Fat_tag_stores_exp'}));
% [model.rxns(pos),num2cell(qp.Model.lb(pos)),num2cell(qp.Model.ub(pos)),num2cell(Q(pos,pos)),num2cell(qp.Model.obj(pos))]
%%
 solfound = 0;
 NOsol='';
   qp.Param.barrier.convergetol.Cur=qp.Param.barrier.convergetol.Cur*10; %remove numerical difficulties
   qp.Param.emphasis.numerical.Cur=1;%remove numerical difficulties
%    qp.Param.preprocessing.presolve.Cur =0;
 for algo=1:4
    qp.Param.qpmethod.Cur=algo;
    try
        solqp = qp.solve();
        if strcmp(solqp.statusstring,'non-optimal')
            NOsol=solqp;
        end

        if (solqp.status == 1) || (solqp.status == 101)
            solfound = 1;
            break
        elseif algo==4 &&~isempty(NOsol)
            solfound = 1;
            solqp=NOsol;
%             save(['qp_model_',strjoin(diet)])
            break
        end    
    end
       
 end
 
      if strcmp(solqp.statusstring,'non-optimal') || strcmp(solqp.statusstring,'infeasible')
        qp.Param.barrier.convergetol.Cur=qp.Param.barrier.convergetol.Cur*10; %remove numerical difficulties
        qp.Param.emphasis.numerical.Cur=1;%remove numerical difficulties
        qp.Param.preprocessing.presolve.Cur =0; %turn off preprocessing
         for algo=1:4
             try
                qp.Param.qpmethod.Cur=algo;
                solqp = qp.solve();
                if (solqp.status == 1) || (solqp.status == 101)
                    break
                end
             catch
             end
        end
     end 
 
 if strcmp(solqp.statusstring,'non-optimal') || strcmp(solqp.statusstring,'infeasible')%| ~strcmp(solqp.statusstring,'integer optimal solution')
     save([WorkingDir filesep 'qp_model_',strjoin(diet)])%minimize_previous_sol_
 end

 
%  AdipoConst=table();
