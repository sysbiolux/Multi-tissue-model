rowname={'Liver_glycogen','Muscle_glycogen','Muscle_TAG','Fat_TAG'};
labels={'Liver: glycogen amount','Muscle: glycogen amount','Muscle: TAG amount','Adip. tissue: TAG amount'};

load('Results_Milan_young_HF_healthy.mat')
Results_HF=Results;

type_of_diet={'Milan_young_HF'}; %wph pph ms

ApplicationTime=1;

ExpData_HF=readtable([strjoin(type_of_diet),'.csv'],'delimiter',';','ReadVariableNames',0);
ExpData_HF{1,2:end}=ExpData_HF{1,2:end}+ApplicationTime;


load('Results_Milan_young_LF_healthy.mat')
type_of_diet={'Milan_young_LF'}; %wph pph ms
Results_LF=Results;
ApplicationTime=1;

ExpData_LF=readtable([strjoin(type_of_diet),'.csv'],'delimiter',';','ReadVariableNames',0);
ExpData_LF{1,2:end}=ExpData_LF{1,2:end}+ApplicationTime;

load('Results_no_food_healthy.mat')
type_of_diet={'Milan_young_HF'}; %wph pph ms

diet={'Milan_young_HF'}; %wph pph ms

nrows = 2;
ncols = 2;
for i= 1 : numel(rowname)
        if nrows*ncols-mod(-i, nrows*ncols) == 1
         fig1=figure('Visible','off','units','normalized','Position', [0 0 1920 1080],'PaperPositionMode','auto');
            suptitle('')%['Blood metabolites diet']);%,strjoin(strrep(type_of_diet, '_', ' ')),
        end
        subplot(nrows, ncols, nrows*ncols-mod(-i, nrows*ncols));
        hold on
        pos=find(ismember(Results.Properties.RowNames,rowname(i)));
        plot(0:size(Results,2)-1,Results{pos,:},'k','LineWidth',2);
        plot(0:size(Results_LF,2)-1,Results_LF{pos,:},'b','LineWidth',2);
        plot(0:size(Results_HF,2)-1,Results_HF{pos,:},'r','LineWidth',2);

      
        xlabel('Time [min]', 'FontSize', 15);
        ylabel([(labels(i)),'[\mumol]'], 'FontSize', 15);
        hold off
        xlim([0,360])
end

h=legend('Fasting','Low fat meal','High fat meal');
h.FontSize=12;

fig1.PaperUnits = 'centimeters';
fig1.PaperPosition = [0 0 20 15];
%saveas(fig1,'Stores_different_meals.svg')