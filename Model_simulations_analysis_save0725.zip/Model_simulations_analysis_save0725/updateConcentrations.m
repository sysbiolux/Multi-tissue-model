function [muscle_glyco,hep_glyco,fat,muscle_fat,CurrentConc,updated_aa_storage,updated_hep_protein,updated_muscle_protein,updated_fat_protein]...
    = updateConcentrations(model,Blood_Concentrations,muscle_glyco,muscle_glyco_pos,hep_glyco,hep_glyco_pos,fat,fat_pos,muscle_fat,muscle_fat_pos,sol,Current_aa_storage,...
    hep_protein,muscle_protein,fat_protein,protein_pos)

%The new deviation from the expected concentration, is the old deviation + the new flux through the exchanger. (as a negative flux would indicate
%a consumption of the storage)

%update the glycogen and fat stores
muscle_glyco =  muscle_glyco + sol.x(muscle_glyco_pos);
hep_glyco =  hep_glyco + sol.x(hep_glyco_pos);
fat =  fat + sol.x(fat_pos);
muscle_fat=muscle_fat+sol.x(muscle_fat_pos);
%update the blood concentrations.
[A,B] = ismember(model.rxns,Blood_Concentrations{:,1});
CurrentConc = Blood_Concentrations;
%Take feasibility tolerances into account
% sol.x(abs(sol.x) < 10^-9) = 0;

CurrentConc{B(A),2} = Blood_Concentrations{B(A),2} + sol.x(A);

updated_aa_storage = Current_aa_storage;
for i=1:size(Current_aa_storage,1)
%     if ~strcmp(Current_aa_storage{i,5},'0')
%         [A] = ismember(model.rxns,Current_aa_storage{i,1});
%         [C] = ismember(model.rxns,Current_aa_storage{i,5});
% %         pos_deg=find(ismember(deg_rate(:,1),Current_aa_storage{i,1}));
% %         if ~isempty(pos_deg)
% %             Current_aa_storage{i,2}=Current_aa_storage{i,2}-deg_rate{pos_deg,2};
% %         end
%     [Current_aa_storage{i,1},sol.x(A),Current_aa_storage{i,5},sol.x(C)]
%         updated_aa_storage{i,2} = Current_aa_storage{i,2} + sol.x(A)+ sol.x(C);
%     else
        [A] = ismember(model.rxns,Current_aa_storage{i,1});
%         pos_deg=find(ismember(deg_rate(:,1),Current_aa_storage{i,1}));
%         if ~isempty(pos_deg)
%             Current_aa_storage{i,2}=Current_aa_storage{i,2}-deg_rate{pos_deg,2};
%         end
        updated_aa_storage{i,2} = Current_aa_storage{i,2} + sol.x(A);
%     end
end

updated_hep_protein =  hep_protein + sol.x(protein_pos(1));
updated_muscle_protein =  muscle_protein + sol.x(protein_pos(2));
updated_fat_protein =  fat_protein + sol.x(protein_pos(3));

