function data=extract_data_food_untargeted_metabolomics(data,urine_mets,blood_mets,blood_food_extracted,urine_food_extracted)
for i=1:size(data,1)
    if i==1
       disease=1;
       pos_urine=find(ismember(urine_mets,data{i,2})); 
       pos_blood=find(ismember(blood_mets,data{i,2})) ;
       if ~isempty(pos_blood)
           data{i,4}=blood_food_extracted{disease,pos_blood};
       else
            data{i,4}=nan;
       end
       if ~isempty(pos_urine)
        data{i,5}=urine_food_extracted{disease,pos_urine};
       else
           data{i,5}=nan;
       end
    elseif strcmp(data{i-1,1},data{i,1})
       pos_urine=find(ismember(urine_mets,data{i,2})); 
       pos_blood=find(ismember(blood_mets,data{i,2})) ;
       if ~isempty(pos_blood)
           data{i,4}=blood_food_extracted{disease,pos_blood};
       else
            data{i,4}=nan;
       end
       if ~isempty(pos_urine)
       data{i,5}=urine_food_extracted{disease,pos_urine};
       else
            data{i,5}=nan;
       end
    else
       disease=disease+1;
       pos_urine=find(ismember(urine_mets,data{i,2})); 
       pos_blood=find(ismember(blood_mets,data{i,2})) ;
       if ~isempty(pos_blood)
           data{i,4}=blood_food_extracted{disease,pos_blood};
       else
            data{i,4}=nan;
       end
       if ~isempty(pos_urine)
       data{i,5}=urine_food_extracted{disease,pos_urine};
       else
           data{i,5}=nan;
       end
    end

    
end

data=data(sum(isnan(data{:,4:5}),2)~=2,:);

%data=data(~(strcmp(data{:,6},'urine')&sum(isnan(data{:,12:13}),2)==2),:);