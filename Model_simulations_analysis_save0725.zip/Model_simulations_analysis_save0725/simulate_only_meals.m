function simulate_only_meals(WorkingDir,meal,step_size)%(a)
%WorkingDir = working directory where the files should be saved
%meal = number from 1 to 3 each number corresponds to a different meal
SimTime=360;

individual_models=0;
model= SetupModel();

diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms
type_of_diet=diet(meal);

params=getParams(meal);

% step_size=30/60;
[Results,qpsol,lpsol,infeasibility] = simulateQP_modified(model,SimTime,type_of_diet,params,WorkingDir,individual_models,step_size);


if step_size==1
save([WorkingDir filesep 'Results_',strjoin(type_of_diet),'_healthy.mat'])

  if ~isempty(infeasibility)
            save(['Infeasibility_',strjoin(type_of_diet),'_healthy.mat'],'infeasibility')
  end
else
    save([WorkingDir filesep 'Results_',strjoin(type_of_diet),'_healthy_',num2str(step_size*60),'_sec.mat'])

  if ~isempty(infeasibility)
            save(['Infeasibility_',strjoin(type_of_diet),'_healthy_',num2str(step_size*60),'_sec.mat'],'infeasibility')
  end
end
end    
