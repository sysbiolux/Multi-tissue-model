function plot_timeseries_heatmap_per_tissue(a)
clearvars -except a
steps=1;
if a==1
    load('Results_Milan_young_LF_healthy','lpsol','model')
elseif a==2
%     steps=25;
    load('Results_Milan_young_HF_healthy','lpsol','model')
elseif a==3
    load('Results_no_food_healthy','lpsol','model')
% elseif a==4
%     load('Results_Milan_young_LF_healthy_day','lpsol')
elseif a==4
    load('Results_healthy_mixed_conditions_Milan_young_LF','lp_sols','model')
    model=SetupModel;
    lpsol=lp_sols;
    clear lp_sols
elseif a==5
    load('Results_healthy_mixed_conditions_Milan_young_HF','lp_sols','model')
    model=SetupModel;
    lpsol=lp_sols;
    clear lp_sols
elseif a==6
    load('Results_healthy_starvation','lp_sols','model')
    model=SetupModel;
    lpsol=lp_sols;
    clear lp_sols
else
    return 
end

% threshold = 10^-7;
threshold = 0;

    %rxnEq = constructEquations(model, model.rxns(exchangeReactions));
if exist('modified_subSystems_per_tissue_consistent_multi_CBM_model_with_aa_stores_charge_balanced_exchange_rxns.mat','file')
    load modified_subSystems_per_tissue_consistent_multi_CBM_model_with_aa_stores_charge_balanced_exchange_rxns
else
    model=modifySubsystems(model);
end

allSubsystems = unique(model.subSystems);
subIndex = getReactionSubsystem(model, allSubsystems);
subCount = zeros(length(allSubsystems),1);

if a~=6
    timePoints = cellstr(strsplit(num2str(linspace(1,numel(lpsol),numel(lpsol)))));
else
   timePoints = cellstr(strsplit(num2str(linspace(1,size(lpsol,2),size(lpsol,2)))));
end

for j = 1:length(timePoints)
    if mod(j,steps) >0
        timePoints{j} = '';
    end
end
if a~=6
    for j=1:numel(lpsol)
        try
            Fluxes(1:numel(lpsol{j}.x),j)=lpsol{j}.x;
        end
    end
else
    Fluxes=lpsol;
end
absFluxes =  abs(Fluxes);

subsystemFlux = zeros(size(absFluxes,2), length(allSubsystems));

%get fluxes and normalize them per number of reactions in subsystem
for j = 1:length(allSubsystems)
   subsystemFlux(:,j) = sum(absFluxes(subIndex == j,:), 1);
   subCount(j) = sum(subIndex == j);
   subsystemFlux(:,j) =  subsystemFlux(:,j)/subCount(j);
end

pos=ismember(allSubsystems,{'Miscellaneous','Blood storage','Urine excretion','Hep_Miscellaneous','Muscle_Miscellaneous','Fat_Miscellaneous',...
    'Hep_Tissue storage','Muscle_Tissue storage','Fat_Tissue storage'});
subsystemFlux(:,pos)=zeros(size(subsystemFlux,1),sum(pos));

%%agregate times and normalize
if steps ~=1
time_vector=[kron(1', ones(steps-1,1));kron([2:numel(lpsol)/steps+1]', ones(steps,1))];
time_vector=time_vector(1:numel(lpsol));
counter=steps;
for i=1:size(subsystemFlux,1)/steps+1
    pos=ismember(time_vector,i);
    if i==1
        subsystemFlux(1,:)=subsystemFlux(pos,:)/sum(sum(subsystemFlux(pos,:),2)~=0);
    elseif sum(pos)==1
        subsystemFlux(counter*(i-1),:)=subsystemFlux(pos,:)/sum(sum(subsystemFlux(pos,:),2)~=0);
    else
        subsystemFlux(counter*(i-1),:)=sum(subsystemFlux(pos,:))/sum(sum(subsystemFlux(pos,:),2)~=0);
    end
end
end
timePoints=timePoints(1:size(subsystemFlux,1));
times_to_plot=~cellfun(@isempty,timePoints);
times_to_plot(1)=1;
timePoints{1}='1';

subsystemFlux_HM=subsystemFlux;
emptySubsystems = sum(subsystemFlux_HM) <=threshold;
pos_tissue_storage_synthesis=ismember(allSubsystems,{'Fat_Tissue storage synthesis','Muscle_Tissue storage synthesis','Hep_Tissue storage synthesis','Fat_Protein synthesis','Muscle_Protein synthesis','Hep_Protein synthesis'});
emptySubsystems(pos_tissue_storage_synthesis)=0;
subsystemFlux_HM(:,emptySubsystems) = [];
% subCount(emptySubsystems) = [];
nonEmptySystems = allSubsystems(not(emptySubsystems));

data=array2table(subsystemFlux_HM(times_to_plot,:));

data.Properties.VariableNames=strrep(strrep(strrep(strrep(nonEmptySystems,', ',' '),'/','_'),'-',' '),' ','_');
data.Properties.RowNames= timePoints(times_to_plot);

Fat=strrep(data.Properties.VariableNames,'Fat_','');

Muscle=strrep(data.Properties.VariableNames,'Muscle_','');

Hep=strrep(data.Properties.VariableNames,'Hep_','');

%common Subsystems between tissues
data=data(:,ismember(strrep(strrep(strrep(data.Properties.VariableNames,'Fat_',''),'Hep_',''),'Muscle_',''),intersect(intersect(Fat,Muscle),Hep)));

if a==1
    writetable(data,['Data_healthy_Milan_young_LF_subsystems_per_tissue.csv'],'WriteRowNames',true);
elseif a==2
    writetable(data,['Data_healthy_Milan_young_HF_subsystems_per_tissue.csv'],'WriteRowNames',true);
elseif a==3
    writetable(data,['Data_healthy_no_food_subsystems_per_tissue.csv'],'WriteRowNames',true);
elseif a==4
    writetable(data,['Data_healthy_Milan_young_LF_mixed_conditions_subsystems_per_tissue.csv'],'WriteRowNames',true);
elseif a==5
    writetable(data,['Data_healthy_Milan_young_HF_mixed_conditions_subsystems_per_tissue.csv'],'WriteRowNames',true);
elseif a==6
    writetable(data,['Data_healthy_starvation_subsystems_per_tissue.csv'],'WriteRowNames',true);
end

%hepatocyte
% pos=cellfun(@isempty,strfind(allSubsystems,'Fat_'))& cellfun(@isempty,strfind(allSubsystems,'Muscle_'));
% subsystemFlux_tissue=subsystemFlux;
% % subsystemFlux_tissue(:,pos)=zeros(size(subsystemFlux,1),sum(pos));
% emptySubsystems = sum(subsystemFlux_tissue) <threshold;
% emptySubsystems=emptySubsystems'|~pos;
% subsystemFlux_tissue(:,emptySubsystems) = [];
% % subCount(emptySubsystems) = [];
% nonEmptySystems = allSubsystems(not(emptySubsystems));
% 
% 
% subsystemFlux_tissue=subsystemFlux_tissue(times_to_plot,:);
% normalizationMatrix = repmat(max(subsystemFlux_tissue)', 1,length(timePoints));
% normalizationMatrix=normalizationMatrix(:,times_to_plot);
% 
% gcf=clustergram(subsystemFlux_tissue','DisplayRatio',[0.1],'RowLabels', strrep(nonEmptySystems,'Hep_',''), 'ColumnLabels', timePoints(times_to_plot), 'Colormap', redbluecmap, 'Cluster', 1, 'Symmetric', false)
% addTitle(gcf, 'Hepatocyte', 'FontSize', 20)
% addXLabel(gcf, 'Time in seconds', 'FontSize', 12)
% addYLabel(gcf, 'Subsystems')
% 
% %muscle
% pos=cellfun(@isempty,strfind(allSubsystems,'Fat_'))& cellfun(@isempty,strfind(allSubsystems,'Hep_'));
% subsystemFlux_tissue=subsystemFlux;
% % subsystemFlux_tissue(:,pos)=zeros(size(subsystemFlux,1),sum(pos));
% emptySubsystems = sum(subsystemFlux_tissue) <threshold;
% emptySubsystems=emptySubsystems'|~pos;
% subsystemFlux_tissue(:,emptySubsystems) = [];
% % subCount(emptySubsystems) = [];
% nonEmptySystems = allSubsystems(not(emptySubsystems));
% normalizationMatrix = repmat(max(subsystemFlux_tissue)', 1,length(timePoints));
% 
% times_to_plot=~cellfun(@isempty,timePoints);
% times_to_plot(1)=1;
% timePoints{1}='1';
% subsystemFlux_tissue=subsystemFlux_tissue(times_to_plot,:);
% normalizationMatrix=normalizationMatrix(:,times_to_plot);
% 
% gcf=clustergram(subsystemFlux_tissue','DisplayRatio',[0.1],'RowLabels', strrep(nonEmptySystems,'Muscle_',''), 'ColumnLabels', timePoints(times_to_plot), 'Colormap', redbluecmap, 'Cluster', 1, 'Symmetric', false)
% addTitle(gcf, 'Muscle tissue', 'FontSize', 20)
% addXLabel(gcf, 'Time in seconds', 'FontSize', 12)
% addYLabel(gcf, 'Subsystems')
% 
% %fat
% pos=cellfun(@isempty,strfind(allSubsystems,'Hep_'))& cellfun(@isempty,strfind(allSubsystems,'Muscle_'));
% subsystemFlux_tissue=subsystemFlux;
% % subsystemFlux_tissue(:,pos)=zeros(size(subsystemFlux,1),sum(pos));
% emptySubsystems = sum(subsystemFlux_tissue) <threshold;
% emptySubsystems=emptySubsystems'|~pos;
% subsystemFlux_tissue(:,emptySubsystems) = [];
% % subCount(emptySubsystems) = [];
% nonEmptySystems = allSubsystems(not(emptySubsystems));
% normalizationMatrix = repmat(max(subsystemFlux_tissue)', 1,length(timePoints));
% 
% times_to_plot=~cellfun(@isempty,timePoints);
% times_to_plot(1)=1;
% timePoints{1}='1';
% subsystemFlux_tissue=subsystemFlux_tissue(times_to_plot,:);
% normalizationMatrix=normalizationMatrix(:,times_to_plot);
% 
% gcf=clustergram(subsystemFlux_tissue','DisplayRatio',[0.1],'RowLabels', strrep(nonEmptySystems,'Fat_',''), 'ColumnLabels', timePoints(times_to_plot), 'Colormap', redbluecmap, 'Cluster', 1, 'Symmetric', false)
% addTitle(gcf, 'Adipose tissue', 'FontSize', 20)
% addXLabel(gcf, 'Time in seconds', 'FontSize', 12)
% addYLabel(gcf, 'Subsystems')


end    
    
function result=getReactionSubsystem(model, subsystemList)

    result = zeros(length(model.rxns),1);

    for i = 1:length(model.rxns)

        result(i) = find(ismember(subsystemList, model.subSystems(i)));

    end

end

