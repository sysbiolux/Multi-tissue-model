function plot_timeseries_heatmap_per_tissue_healthy
steps=1;

% type_of_diet={'_Milan_young_LF'};
% type_of_diet={'_no_food'};
type_of_diet={''};

KO=0;       
% day={'_day'};
day={'_mixed_conditions'};

%     threshold = 10^-7;
    threshold = 0;

    try
        load(['Results',strjoin(type_of_diet),'_healthy',strjoin(day),'.mat'],'lpsol','model')
        %rxnEq = constructEquations(model, model.rxns(exchangeReactions));
        if exist('modified_subSystems_per_tissue_consistent_multi_CBM_model_with_aa_stores_charge_balanced_exchange_rxns.mat','file')
            load modified_subSystems_per_tissue_consistent_multi_CBM_model_with_aa_stores_charge_balanced_exchange_rxns
        else
            model=modifySubsystems(model);
        end

        allSubsystems = unique(model.subSystems);
        subIndex = getReactionSubsystem(model, allSubsystems);
        subCount = zeros(length(allSubsystems),1);


        timePoints = cellstr(strsplit(num2str(linspace(1,numel(lpsol),numel(lpsol)))));


        for j = 1:length(timePoints)
            if mod(j,steps) >0
                timePoints{j} = '';
            end
        end

        for j=1:numel(lpsol)
            try
                Fluxes(1:numel(lpsol{j}.x),j)=lpsol{j}.x;
            end
        end

        absFluxes =  abs(Fluxes);

        subsystemFlux = zeros(size(absFluxes,2), length(allSubsystems));

        %get fluxes and normalize them per number of reactions in subsystem
        for j = 1:length(allSubsystems)
           subsystemFlux(:,j) = sum(absFluxes(subIndex == j,:), 1);
           subCount(j) = sum(subIndex == j);
           subsystemFlux(:,j) =  subsystemFlux(:,j)/subCount(j);
        end

        pos=ismember(allSubsystems,{'Miscellaneous','Blood storage','Urine excretion','Hep_Miscellaneous','Muscle_Miscellaneous','Fat_Miscellaneous',...
            'Hep_Tissue storage','Muscle_Tissue storage','Fat_Tissue storage'});
        subsystemFlux(:,pos)=zeros(size(subsystemFlux,1),sum(pos));

        %%agregate times and normalize
        if steps ~=1
        time_vector=[kron(1', ones(steps-1,1));kron([2:numel(lpsol)/steps+1]', ones(steps,1))];
        time_vector=time_vector(1:numel(lpsol));
        counter=steps;
        for i=1:size(subsystemFlux,1)/steps+1
            pos=ismember(time_vector,i);
            if i==1
                subsystemFlux(1,:)=subsystemFlux(pos,:)/sum(sum(subsystemFlux(pos,:),2)~=0);
            elseif sum(pos)==1
                subsystemFlux(counter*(i-1),:)=subsystemFlux(pos,:)/sum(sum(subsystemFlux(pos,:),2)~=0);
            else
                subsystemFlux(counter*(i-1),:)=sum(subsystemFlux(pos,:))/sum(sum(subsystemFlux(pos,:),2)~=0);
            end
        end
        end
        timePoints=timePoints(1:size(subsystemFlux,1));
        times_to_plot=~cellfun(@isempty,timePoints);
        times_to_plot(1)=1;
        timePoints{1}='1';

        subsystemFlux_HM=subsystemFlux;
        emptySubsystems = sum(subsystemFlux_HM) <threshold;
        subsystemFlux_HM(:,emptySubsystems) = [];
        % subCount(emptySubsystems) = [];
        nonEmptySystems = allSubsystems(not(emptySubsystems));

        data=array2table(subsystemFlux_HM(times_to_plot,:));

        data.Properties.VariableNames=strrep(strrep(strrep(strrep(nonEmptySystems,', ',' '),'/','_'),'-',' '),' ','_');
        data.Properties.RowNames= timePoints(times_to_plot);

        Fat=strrep(data.Properties.VariableNames,'Fat_','');

        Muscle=strrep(data.Properties.VariableNames,'Muscle_','');

        Hep=strrep(data.Properties.VariableNames,'Hep_','');

        %common Subsystems between tissues
%         data=data(:,ismember(strrep(strrep(strrep(data.Properties.VariableNames,'Fat_',''),'Hep_',''),'Muscle_',''),intersect(intersect(Fat,Muscle),Hep)));

        writetable(data,['Data_healthy',strjoin(type_of_diet),'_subsystems_per_tissue',strjoin(day),'.csv'],'WriteRowNames',true);

    end
end
    
function result=getReactionSubsystem(model, subsystemList)

    result = zeros(length(model.rxns),1);

    for i = 1:length(model.rxns)

        result(i) = find(ismember(subsystemList, model.subSystems(i)));

    end

end

