function [rates,capacity]=adjustBasalRate(rates,CurrentConcentrationChanges,Blood_Concentrations,capacity,params);
% params=['store_ala_L[bl]';'store_arg_L[bl]';'store_asn_L[bl]';'store_asp_L[bl]';'store_cys_L[bl]';'store_gln_L[bl]';'store_glu_L[bl]';'store_gly[bl]';...
% 'store_his_L[bl]';'store_ile_L[bl]';'store_leu_L[bl]';'store_lys_L[bl]';'store_met_L[bl]';'store_phe_L[bl]';'store_pro_L[bl]';'store_ser_L[bl]';...
% 'store_thr_L[bl]';'store_trp_L[bl]';'store_tyr_L[bl]';'store_val_L[bl]';'store_glc_D[bl]'];

% res_new_rate=zeros(size(Blood_Concentrations,1),2);
for j=1:size(capacity,1) 
  %%
    pos=find(ismember(Blood_Concentrations{:,1},capacity{j,1}));    
    met=(Blood_Concentrations{pos,2} + CurrentConcentrationChanges{pos,2})/5;
    met0=Blood_Concentrations{pos,2}/5;
    vmax=params(j+22);
    % vmax_muscle=params(5);
    % vmax_fat=46;
    km=params(j+44);
%     basal=params(j+66);
    conc=met-met0;
    
    %adjust tissue rates
    if conc>=0
        v=vmax*conc/(km+conc);
    else
        v=0;
%         v=vmax*basal;
    end

%     if counter<=params(j)
%         v=vmax*conc/(km+conc);
%     else
%         v=0;
%     end
    
    new_rate=-v;
      
    rates{j,3:4}=[new_rate,1000000];

    capacity{j,2}=new_rate;
end        
%     end
% %%
%     if lb<=ub
%         rates{j,3:4}=[min(lb,0),ub];
%     else
%         rates{j,3:4}=[min(ub,0),lb];
%     end
%     rates{j,3:4}=[new_rate,new_rate];
%     capacity{j,2}=new_rate;
%     res_new_rate(j,1:2)=rates{j,3:4};

    %%
%     basal=rates{j,2};
% 
%     pos=find(ismember(Blood_Concentrations{:,1},capacity{j,1}));
%     met=round(Blood_Concentrations{pos,2} + CurrentConcentrationChanges{pos,2},2);
%     met0=Blood_Concentrations{pos,2};
%     
%     delay_fat=find(ismember(delayed_fat,rates{j,1}));
% 
%    factor1=15;
%     factor2=1;
% %     d=met/met0*0.1;
% %     if d<=0.1
%     d=0.01;
% %     end
%     
%     dadd = abs(capacity{j,2}) * d;
%     dadd2 = abs(capacity{j,3})* d;
%     if counter==1
%        cap1=abs(capacity{j,2}); %basal level 
%        cap2=(capacity{j,3});
%     else
%        cap1=capacity{j,2};
%        cap2=capacity{j,3};
%     end   
%     
%     k1=(met>met0)*(2*met/(met0+met) - 1)*factor1;
%     k2=(met0>met)*(2*met/(met0+met) - 1)*factor2;
%     cap1=(cap1+(met0<met) * dadd) + k1 -d*cap1;
%     cap2 =cap2+ (met<met0)*dadd2 + k2 -d*cap2;
%     new_rate=(met>0)*(-cap1*(2*met/(met0+met)) - cap2);
%    
%         lb=new_rate+basal;%
%         ub=new_rate-basal;%
%   
% 
%     if lb<=ub
%         rates{j,3:4}=[min(lb,0),ub];
%     else
%         rates{j,3:4}=[min(ub,0),lb];
%     end
%     
% 
%     capacity{j,2}=cap1;
%     capacity{j,3}=cap2;
%     res_new_rate(j,1:2)=rates{j,3:4};
    %%
%         pos=find(ismember(Blood_Concentrations{:,1},capacity{j,1}));
%     met=round(Blood_Concentrations{pos,2} + CurrentConcentrationChanges{pos,2},2);
%     met0=Blood_Concentrations{pos,2};
%     
%     delay_fat=find(ismember(delayed_fat,rates{j,1}));
% 
%    factor=2;%okish
%     
%     basal=rates{j,2};
%     if met0>0
% %         k=(met/met0-1)*factor; factor=1% okish
%         k=(2*met/(met0+met) - 1)*factor; %okish
%     else
%         k=0;
%     end
%     
%     k2=(met/met0)^4;
%     if counter==1 
%         new_rate=k*basal+k2*basal;%
%     else
%         new_rate=k*capacity{j,3}+k2*basal;
%     end
%     
%         lb=new_rate+basal;%
%         ub=new_rate-basal;%
%   
% 
%     if lb<=ub
%         rates{j,3:4}=[min(lb,0),ub];
%     else
%         rates{j,3:4}=[min(ub,0),lb];
%     end
%     
% 
% %     capacity{j,2}=cap1;
%     capacity{j,3}=new_rate;
%     res_new_rate(j,1:2)=rates{j,3:4};
%     capacity{j,2}=cap1;

% rates
%     if cap>0
%        d=0.1; %degradation rate
% %     else
% %         if cap<-8
% %             d=-0.1;
% %         else
% %             d=-0.9;
% %         end
% %     end
%     
%     if met>=met0
% %        k=0.1; %factor
%         k=max(0, 2*met/(met0+met));     
%     else
%         k=0;       
%     end
%     
%     cap=((cap+d) + k*1 -d*cap);
%     new_rate=-cap * (2 * met /(met + met0));
%         
%    if (capacity{j,3}==1)&&(new_rate<basal) 
%             new_rate=basal;
%    end
   
%     res(:,1:2)=rates{:,3:4};
% end