function params=getParams(meal)
if meal==3
    load initial_params_individuals_HF
%     load('store_glc_D[bl]_HF_lsqnonlin_ic_5.mat')
%     params([22,22*2,22*3])=result;
else
    load initial_params_individuals
end
tmax_ser=params(15);%+params(1))/2; %ser+ala
tmax_phe=params(13);

vmax_ser=params(15+20);%ser+ala
vmax_phe=params(13+20);

km_ser=params(15+40);%ser+ala
km_phe=params(13+40);

% basal_ser=params(15);%+60)+params(1+60))/2;%ser+ala
% basal_phe=params(13+60);
basal_ser=0;
basal_phe=0;

tmax_cys=tmax_ser;
tmax_trp=tmax_phe;
vmax_cys=vmax_ser;
vmax_trp=vmax_phe;
km_cys=km_ser;
km_trp=km_phe;
basal_cys=basal_ser;
basal_trp=basal_phe;
% unchanged_params=[tmax_cys tmax_trp vmax_cys vmax_trp km_cys km_trp basal_cys basal_trp];
params=[params(1:4),tmax_cys,params(5:16),tmax_trp,params(17:20),... %tmax
    params(21:24),vmax_cys,params(25:36),vmax_trp,params(37:40),...   %vmax
    params(41:44),km_cys,params(45:56),km_trp,params(57:60),... %km
    params(61:64),basal_cys,params(65:76),basal_trp,params(77:end)]; %basal
% params(22)=50; % tmax glc =50 min from lit

% params(22)=798;
% params(22+22)=390;
% params(22+44)=0.050;
% params(44)=params(44)*5; % vmax glc

% params(4)=params(17)+10;    %tmax asp= thr
% params(7)=params(17)+10;     %tmax glu= thr
% 
% params(4+22)=params(17+22);   %vmax asp  = thr
% params(7+22)=params(17+22); %glu= thr
% 
% params(4+44)=params(17+44);    %km asp= thr
% params(7+44)=params(17+44); %glu= thr
% 
% params(4+66)=params(17+66);    %basal asp = thr
% params(7+66)=params(17+66); %glu = thr

% params=fitted_params;
params(end+1)=1;

% if meal==3
%     params([22,22*2,22*3])=result;
% end

end