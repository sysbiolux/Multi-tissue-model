tag=2;
model= SetupModel();
nrows=numel(model.rxns);
clear model
intCounter = 12;
step_size=1/60;
meal=2;
diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms
type_of_diet=diet(meal);


if tag==1
    filenameResults='CurrentResultsFood';
 elseif tag==2
    filenameResults='CurrentResults';
 elseif tag==3
    filenameResults='CurrentResultsExerc';
elseif tag==4
            filenameResults='CurrentResultsShortSim';
end

if tag==2
    final_lp=[];
    for ic=1:intCounter%-1
        load([filenameResults,num2str(ic)],'lp_sols')
        lp_sols=lp_sols(~cellfun(@isempty,lp_sols));
        for x=1:numel(lp_sols)
            try
            lp_sols_double(:,x)=lp_sols{x}.x(1:nrows);
            catch
                lp_sols_double(:,x)=zeros(nrows,1);
            end
        end
        final_lp=[final_lp,lp_sols_double];
        clear lp_sols
        clear lp_sols_double
    end
    save([filenameResults,'_lpfinal'],'final_lp')

    clear final_lp
    final_qp=[];
    for ic=1:intCounter%-1
        load([filenameResults,num2str(ic)],'qp_sols')
        qp_sols=qp_sols(~cellfun(@isempty,qp_sols));
        for x=1:numel(qp_sols)
            try
                lp_sols_double(:,x)=qp_sols{x}.x(1:nrows);
            catch
                lp_sols_double(:,x)=zeros(nrows,1);
            end
        end
        final_qp=[final_qp,lp_sols_double];
        clear qp_sols
        clear lp_sols_double
    end
%     qp_sols=final_qp;
%     clear final_qp
    save([filenameResults,'_qpfinal'],'final_qp')
    clear final_qp

     Results=[];
    for ic=1:intCounter%-1
        load([filenameResults,num2str(ic)],'NewResults')
           Results=[Results,NewResults];
    end
    save([filenameResults,'_Resultsfinal'],'Results')
    clear Results NewResults

else  
     final_lp=[];
     final_qp=[];
     final_res=[];
    for ic=1:intCounter%-1
        load([filenameResults,num2str(ic)])
        final_lp=[final_lp,lp_sols];
        final_qp=[final_qp,qp_sols];
        final_res=[final_res,NewResults];
    end
    lp_sols=final_lp;
    clear final_lp
    qp_sols=final_qp;
    clear final_qp
    Results=final_res;
    clear final_res
end
%
clearvars -except tag type_of_diet step_size
WorkingDir=pwd;
if tag==1
    filenameResults='CurrentResultsFood';
 elseif tag==2
    filenameResults='CurrentResults';
 elseif tag==3
    filenameResults='CurrentResultsExerc';
elseif tag==4
            filenameResults='CurrentResultsShortSim';
end
load([filenameResults,'_lpfinal'])
lp_sols=final_lp;
clear final_lp;

load([filenameResults,'_qpfinal'])
qp_sols=final_qp;
clear final_qp;

load([filenameResults,'_Resultsfinal'])

if step_size==1
save([WorkingDir filesep 'Results_',strjoin(type_of_diet),'_healthy.mat'])

  if ~isempty(infeasibility)
            save(['Infeasibility_',strjoin(type_of_diet),'_healthy.mat'],'infeasibility')
  end
else
    save([WorkingDir filesep 'Results_',strjoin(type_of_diet),'_healthy_',num2str(step_size*60),'_sec.mat'])

  if ~isempty(infeasibility)
            save(['Infeasibility_',strjoin(type_of_diet),'_healthy_',num2str(step_size*60),'_sec.mat'],'infeasibility')
  end
end
