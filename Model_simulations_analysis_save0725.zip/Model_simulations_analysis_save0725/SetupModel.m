function [model] = SetupModel()
load consistent_multi_CBM_model_with_aa_stores_charge_balanced_exchange_rxns

for j=1:numel(model.rules)
    if iscell(model.rules{j})
        rule=model.rules{j};
        model.rules{j}=rule{1};
    end
    
    if iscell(model.subSystems{j})
        subSystems=model.subSystems{j};
        model.subSystems{j}=subSystems{1};
    end
end

model=changeRxnBounds(model,{'Muscle_CK','Muscle_CKc','Muscle_glygn_stores','Hep_glygn_stores','Fat_tag_stores'},1000000,'u');
model=changeRxnBounds(model,{'Muscle_glygn_stores','Hep_glygn_stores','Fat_tag_stores'},-1000000,'l');

%Read the Model Constraints in a table and set it.
constraints = readtable('Model_Constraints_food.csv','delimiter',';');

[A,B] = ismember(constraints{:,1},model.rxns);

model.lb(B(A)) = constraints{A,2};
model.ub(B(A)) = constraints{A,3};
model=changeRxnBounds(model,'Hep_glygn_stores',-59.6,'l');

model=changeRxnBounds(model,{'store_o2[bl]'},-(116940+6089+397.76),'l'); % for 90% of 02MAX exercise
model=changeRxnBounds(model,{'Muscle_o2'},-116940,'l');%116940
model=changeRxnBounds(model,{'Hep_o2'},-1375,'u');
model=changeRxnBounds(model,{'Muscle_o2'},-1728,'u');
model=changeRxnBounds(model,{'store_co2[bl]'},200000,'u');%at 90% OF 02MAX EXERCISE the RER was co2/o2=1
model=changeRxnBounds(model,{'Fat_TAGt'},1000000,'u');

model.lb(find(model.lb==-1000))=-1000000;
model.ub(find(model.ub==1000))=1000000;
model=changeRxnBounds(model,{'Muscle_OROTGLUt','Fat_OROTGLUt','Hep_ARGDCm','Hep_r0016','Fat_r0016'},0,'b');
model=changeRxnBounds(model,{'Hep_O2t','Muscle_O2t','Fat_O2t'},0,'l');

model=changeRxnBounds(model,{'Fat_r0389'},0,'l');

constraints = readtable('Metabolites_fluxes_urine_excretion.csv','delimiter',';');
constraints{:,1}=strcat('Urine_excretion_',strrep(constraints{:,1},'[bl]',''));
[A,B] = ismember(constraints{:,1},model.rxns);

model.lb(B(A)) = 0;
model.ub(B(A)) = max(constraints{A,4},constraints{A,6});

model=removeRxns(model,{'Muscle_protein_production','Hep_protein_production','Fat_protein_production'});
model=addReaction(model,'Muscle_protein_production',['3 Muscle_h2o[c] + 3 Muscle_atp[c] + 0.0633 Muscle_glu_L[c] + 0.051 Muscle_asp_L[c] + 0.0508 Muscle_asn_L[c] + '...
    '0.086 Muscle_ala_L[c] + 0.0192 Muscle_cys_L[c] + 0.063 Muscle_gln_L[c] + 0.1085 Muscle_gly[c] + 0.0517 Muscle_ser_L[c] + 0.0512 Muscle_thr_L[c] + '...
    '0.0706 Muscle_lys_L[c] + 0.0426 Muscle_arg_L[c] + 0.016 Muscle_met_L[c] + 0.0222 Muscle_his_L[c] + 0.0225 Muscle_tyr_L[c] + 0.0423 Muscle_ile_L[c] + '...
    '0.0831 Muscle_leu_L[c] + 0.0054 Muscle_trp_L[c] + 0.0341 Muscle_phe_L[c] + 0.0565 Muscle_pro_L[c] + 0.0599 Muscle_val_L[c] -> 2 Muscle_adp[c] + 3 Muscle_h[c] + '...
    '2 Muscle_pi[c] + Muscle_amp[c] + Muscle_ppi[c] + Muscle_protein[c]']);

model=addReaction(model,'Fat_protein_production',['3 Fat_h2o[c] + 3 Fat_atp[c] + 0.0633 Fat_glu_L[c] + 0.051 Fat_asp_L[c] + 0.0508 Fat_asn_L[c] + '...
    '0.086 Fat_ala_L[c] + 0.0192 Fat_cys_L[c] + 0.063 Fat_gln_L[c] + 0.1085 Fat_gly[c] + 0.0517 Fat_ser_L[c] + 0.0512 Fat_thr_L[c] + '...
    '0.0706 Fat_lys_L[c] + 0.0426 Fat_arg_L[c] + 0.016 Fat_met_L[c] + 0.0222 Fat_his_L[c] + 0.0225 Fat_tyr_L[c] + 0.0423 Fat_ile_L[c] + '...
    '0.0831 Fat_leu_L[c] + 0.0054 Fat_trp_L[c] + 0.0341 Fat_phe_L[c] + 0.0565 Fat_pro_L[c] + 0.0599 Fat_val_L[c] -> 2 Fat_adp[c] + 3 Fat_h[c] + '...
    '2 Fat_pi[c] + Fat_amp[c] + Fat_ppi[c] + Fat_protein[c]']);

model=addReaction(model,'Hep_protein_production',['3 Hep_h2o[c] + 3 Hep_atp[c] + 0.0633 Hep_glu_L[c] + 0.051 Hep_asp_L[c] + 0.0508 Hep_asn_L[c] + '...
    '0.086 Hep_ala_L[c] + 0.0192 Hep_cys_L[c] + 0.063 Hep_gln_L[c] + 0.1085 Hep_gly[c] + 0.0517 Hep_ser_L[c] + 0.0512 Hep_thr_L[c] + '...
    '0.0706 Hep_lys_L[c] + 0.0426 Hep_arg_L[c] + 0.016 Hep_met_L[c] + 0.0222 Hep_his_L[c] + 0.0225 Hep_tyr_L[c] + 0.0423 Hep_ile_L[c] + '...
    '0.0831 Hep_leu_L[c] + 0.0054 Hep_trp_L[c] + 0.0341 Hep_phe_L[c] + 0.0565 Hep_pro_L[c] + 0.0599 Hep_val_L[c] -> 2 Hep_adp[c] + 3 Hep_h[c] + '...
    '2 Hep_pi[c] + Hep_amp[c] + Hep_ppi[c] + Hep_protein[c]']);
model=changeRxnBounds(model,'Fat_DM_atp',2022,'b');%

model=changeRxnBounds(model,'Hep_DM_atp',23887,'b');%21377
model=changeRxnBounds(model,'Muscle_DM_atp',15078,'b');
model=changeRxnBounds(model,'Fat_ACCOAC',50,'u');
model=changeRxnBounds(model,{'Fat_r0942';'Fat_CREATt4_2_r'},0,'b');

model=addReaction(model,'Hep_Rtotal','Hep_Rtotal[e]  <=> Rtotal[bl] ');
model=addReaction(model,'Muscle_Rtotal','Muscle_Rtotal[e]  <=> Rtotal[bl] ');
model=addReaction(model,'Muscle_Rtotal2','Muscle_Rtotal2[e]  <=> Rtotal2[bl] ');
model=addReaction(model,'Muscle_Rtotal3','Muscle_Rtotal3[e]  <=> Rtotal3[bl] ');
model=addReaction(model,'Fat_RTOTALt','Fat_Rtotal[e]  <=> Fat_Rtotal[c] ');
model=addReaction(model,'Hep_Rtotal3','Hep_Rtotal3[e]  <=> Rtotal3[bl] ');
model=addReaction(model,'Hep_Rtotal2','Hep_Rtotal2[e]  <=> Rtotal2[bl] ');
model=addReaction(model,'Muscle_RTOTAL3t','Muscle_Rtotal3[e]  <=> Muscle_Rtotal3[c] ');
model=addReaction(model,'Fat_RTOTAL2t','Fat_Rtotal2[e]  <=> Fat_Rtotal2[c] ');
model=addReaction(model,'Hep_RTOTAL2t','Hep_Rtotal2[e]  <=> Hep_Rtotal2[c] ');
model=addReaction(model,'Hep_RTOTAL3t','Hep_Rtotal3[e]  <=> Hep_Rtotal3[c] ');
model=addReaction(model,'Fat_Rtotal2','Fat_Rtotal2[e]  <=> Rtotal2[bl] ');
model=addReaction(model,'Fat_Rtotal3','Fat_Rtotal3[e]  <=> Rtotal3[bl] ');
model=addReaction(model,'Fat_Rtotal','Fat_Rtotal[e]  <=> Rtotal[bl] ');