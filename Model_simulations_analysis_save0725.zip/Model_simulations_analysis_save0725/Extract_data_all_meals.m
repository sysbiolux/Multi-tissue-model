function Extract_data_all_meals(meal)
% clear all

Hep_store_protein=7.9365e+05;
Muscle_store_protein=4.7619e+07;
Fat_store_protein=79365;

type_of_diet={'Milan_young_LF','no_food','Milan_young_HF'}; %wph pph ms
% meal=1;
load(['Results_',strjoin(type_of_diet(meal)),'_healthy'],'Results','qpsol','model');
Results_H=Results;

% for meal=1:3
load(['Results_',strjoin(type_of_diet(meal)),'_healthy'],'Results','qpsol','model');
Results_H=Results;

for count=1:size(Results_H,2)
    if count==1
        Results_H{end-2:end,count}=Results_H{end-2:end,count}+[Hep_store_protein;Muscle_store_protein;Fat_store_protein];
    else
        Results_H{end-2:end,count}=Results_H{end-2:end,count-1}+Results_H{end-2:end,count};
    end
end
qpsol_H=qpsol;

urine_fluxes=readtable('Metabolites_fluxes_urine_excretion.csv','Delimiter',';','ReadRowNames',1);
blood_conc=readtable('Blood_concentrations_updated.csv','Delimiter',';','ReadRowNames',1);
blood_conc=blood_conc(ismember(blood_conc.Properties.RowNames,model.rxns),:);
num_blood_mets=size(blood_conc,1);
Healthy_min=blood_conc{:,2};
Healthy_max=blood_conc{:,3};

urine_rxns=strfind(model.rxns,'Urine_excretion');
urine_rxns=~cellfun(@isempty,urine_rxns);

% new_baseline_blood=zeros(size(Results_H(:,1)));
% new_baseline_urine=zeros(sum(urine_rxns),1);

time_healthy=size(Results_H,2)-1;

try 
    load('New_baseline_blood')
catch
    [new_baseline_blood,IEMS_KO]=get_baseline_each_meal;%,Results_H,Hep_store_protein,Muscle_store_protein,Fat_store_protein,Healthy_min,Healthy_max);
end

Res_mapped=[{'Healthy'};strcat({'Healthy_'},strsplit(num2str([1:100]))')];

Res_mapped=[Res_mapped;IEMS_KO];

tag_healthy=1;
for i=1:100%:size(IEMS_KO,1)
%     try
        load(['Results_',strjoin(type_of_diet(meal)),'_healthy_',num2str(i),'.mat'],'Results','qpsol')
        time_IEM=size(Results,2)-1;
        min_time=min(time_healthy,time_IEM);

        Results_IEM=Results(:,1:min_time+1);
        qpsol_IEM=qpsol(:,1:min_time);
% 
        for count=1:size(Results_IEM,2)
            if count==1
                Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count}+[Hep_store_protein;Muscle_store_protein;Fat_store_protein];
            else
                Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count-1}+Results_IEM{end-2:end,count};
            end
        end
        
        clear qpsol
        clear Results
        
        Results_healthy=Results_H(:,1:min_time+1);
        qpsol_healthy=qpsol_H(:,1:min_time);
        
        y_healthy=zeros(size( Results_healthy));
        y_IEM=zeros(size( Results_healthy));
        for count=1:size( Results_healthy,1)    
            y_healthy(count,:)=Results_healthy{count,:}-new_baseline_blood(count);
            y_IEM(count,:)=Results_IEM{count,:}-new_baseline_blood(count);
        end
        
        x=1:min_time+1;
        if tag_healthy==1
            healthy=(trapz(x,y_healthy,2));%/(min_time+1);
            biomarkers(:,1)=healthy;
            up=max(Results_H{1:num_blood_mets,:},[],2)>Healthy_max;
            down=min(Results_H{1:num_blood_mets,:},[],2)<Healthy_min;
            tag=checkrange(up,down);
            abnormal_food(:,1)=tag;
%             new_baseline_blood=min(new_baseline_blood,min(y_healthy,[],2));
        end
        IEM=(trapz(x,y_IEM,2));%/(min_time+1);
        biomarkers(:,i+1)=IEM;
        up=max(y_IEM(1:num_blood_mets,:),[],2)>Healthy_max;
        down=min(y_IEM(1:num_blood_mets,:),[],2)<Healthy_min;
        tag=checkrange(up,down);        
        abnormal_food(:,i+1)=tag;
      
%             new_baseline_blood=min(new_baseline_blood,min(y_IEM,[],2));

        sol_healthy=zeros(size(qpsol_healthy{1}.x(1:numel(model.rxns)),1),min_time);
        sol_IEM=zeros(size(qpsol_healthy{1}.x(1:numel(model.rxns)),1),min_time);

        for u=1:min_time%min(max(find(~cellfun(@isempty,lpsol_IEM))),max(find(~cellfun(@isempty,lpsol_healthy))))
            sol_healthy(:,u)=qpsol_healthy{u}.x(1:numel(model.rxns));
            try
                sol_IEM(:,u)=qpsol_IEM{u}.x(1:numel(model.rxns));
            end
        end
        
        y_healthy=sol_healthy(urine_rxns,:);
        y_IEM=sol_IEM(urine_rxns,:);
        
%         [min(min(y_healthy)),min(min(y_IEM))]
        y_healthy(y_healthy<0)=0;
        y_IEM(y_IEM<0)=0;

        x=1:u;
        
         if tag_healthy==1
            healthy=trapz(x,y_healthy,2);%;trapz([1,x+1],Results_H{end-2:end,1:min_time+1},2)];%/min_time;%-trapz(x,repmat(Results_H{:,1},1,min_time),2))/min_time;
            urine(:,1)=healthy;%;
%             new_baseline_urine=min(new_baseline_urine,min([y_healthy;Results_H{end-2:end,:}],[],2));
        end
        IEM=trapz(x,y_IEM,2);%trapz([1,x+1],Results_IEM{end-2:end,:},2)];%-trapz(x,repmat(Results_H{:,1},1,min_time),2))/min_time;
        urine(:,i+1)=IEM;
        tag_healthy=0;
%         new_baseline_urine=min(new_baseline_urine,min([y_IEM;Results_IEM{end-2:end,:}],[],2));
%     end
end

for y=1:size(IEMS_KO,1)
%     try
        load(['Results_',strjoin(type_of_diet(meal)),'_IEM_KD_fraction_0_',strjoin(IEMS_KO(y)),'.mat'],'Results','qpsol')
        time_IEM=size(Results,2)-1;
        min_time=min(time_healthy,time_IEM);

        Results_IEM=Results(:,1:min_time+1);
        qpsol_IEM=qpsol(:,1:min_time);
% 
        for count=1:size(Results_IEM,2)
            if count==1
                Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count}+[Hep_store_protein;Muscle_store_protein;Fat_store_protein];
            else
                Results_IEM{end-2:end,count}=Results_IEM{end-2:end,count-1}+Results_IEM{end-2:end,count};
            end
        end
        
        clear qpsol
        clear Results
        
        Results_healthy=Results_H(:,1:min_time+1);
        qpsol_healthy=qpsol_H(:,1:min_time);
        
        y_healthy=zeros(size( Results_healthy));
        y_IEM=zeros(size( Results_healthy));
        for count=1:size( Results_healthy,1)    
            y_healthy(count,:)=Results_healthy{count,:}-new_baseline_blood(count);
            y_IEM(count,:)=Results_IEM{count,:}-new_baseline_blood(count);
        end
        
        x=1:min_time+1;
        IEM=(trapz(x,y_IEM,2));%/(min_time+1);
        biomarkers(:,i+y+1)=IEM;
        up=max(y_IEM(1:num_blood_mets,:),[],2)>Healthy_max;
        down=min(y_IEM(1:num_blood_mets,:),[],2)<Healthy_min;
        tag=checkrange(up,down);        
        abnormal_food(:,i+y+1)=tag;
      
        sol_healthy=zeros(size(qpsol_healthy{1}.x(1:numel(model.rxns)),1),min_time);
        sol_IEM=zeros(size(qpsol_healthy{1}.x(1:numel(model.rxns)),1),min_time);

        for u=1:min_time%min(max(find(~cellfun(@isempty,lpsol_IEM))),max(find(~cellfun(@isempty,lpsol_healthy))))
            sol_healthy(:,u)=qpsol_healthy{u}.x(1:numel(model.rxns));
            try
                sol_IEM(:,u)=qpsol_IEM{u}.x(1:numel(model.rxns));
            end
        end
        
        y_healthy=sol_healthy(urine_rxns,:);
        y_IEM=sol_IEM(urine_rxns,:);
        
        y_healthy(y_healthy<0)=0;
        y_IEM(y_IEM<0)=0;

        x=1:u;
        
        IEM=trapz(x,y_IEM,2);%trapz([1,x+1],Results_IEM{end-2:end,:},2)];%-trapz(x,repmat(Results_H{:,1},1,min_time),2))/min_time;
        urine(:,i+y+1)=IEM;
        tag_healthy=0;
%     end
end


biomarkers(isnan(biomarkers))=1;
urine(isnan(urine))=1;

blood=array2table(biomarkers');
urine=array2table(urine');
urine.Properties.RowNames=Res_mapped;   
blood.Properties.RowNames=Res_mapped;  
blood.Properties.VariableNames=strcat('Blood_',(strrep(strrep(strrep(strrep(Results_H.Properties.RowNames,'store_',''),'_stores',''),'_store',''),'[bl]','')));
urine.Properties.VariableNames=[strrep(model.rxns(urine_rxns),'excretion_','')];

%
%%%%%%%%%%%%% MATCH DATA
% data=readtable('Untargeted_metabolomics_data_NP.csv','Delimiter',',');

mets=unique(model.mets);%unique(data{:,2});
data={};

disease=Res_mapped(1,1);
if exist(['Results_',strjoin(type_of_diet(meal)),'_healthy.mat'],'file')     
    data=[data;[repmat(disease,numel(mets),1),mets,repmat({'UK'},numel(mets),1)]];
end

for i=1:100
    disease=Res_mapped(i+1,1);
    try
        if exist(['Results_',strjoin(type_of_diet(meal)),'_healthy_',num2str(i),'.mat'],'file')     
            data=[data;[repmat(disease,numel(mets),1),mets,repmat({'UK'},numel(mets),1)]];
        end
    end
end

for i=1:size(IEMS_KO,1)
    disease=IEMS_KO(i,1);
    try
        if exist(['Results_',strjoin(type_of_diet(meal)),'_IEM_KD_fraction_0_',strjoin(IEMS_KO(i)),'.mat'],'file')     
            data=[data;[repmat(disease,numel(mets),1),mets,repmat({'UK'},numel(mets),1)]];
        end
    end
end

data=cell2table(data,'VariableNames',{'IEM','Metabolite','Regulation'});

% data=sortrows(data,1);
data{:,2}=strrep(data{:,2},'[bl]','');
data{:,1}=strrep(strrep(strrep(data{:,1},' ','_'),'/','_'),':','_');
data{strcmp(data{:,1},'VERY_LONG-CHAIN_ACYL-COENZYME_A_DEHYDROGENASE_(VLCAD)_DEFICIENCY'),1}=strcat(data{strcmp(data{:,1},'VERY_LONG-CHAIN_ACYL-COENZYME_A_DEHYDROGENASE_(VLCAD)_DEFICIENCY'),1},'_');

mets={'amet','argsuc','gudac','hcys_L','thymd'};
data=data(~ismember(data{:,2},mets),:);

urine_mets=strrep(strrep(urine.Properties.VariableNames,'Urine_',''),'Blood_','');

blood_mets=strrep(blood.Properties.VariableNames,'Blood_','');
data=data(ismember(data{:,2},blood_mets),:);

blood_pos=ismember(blood_mets,data{:,2});

urine_pos=ismember(urine_mets,data{:,2});
% data{:,1}=strrep(data{:,1},'''','');
disease_pos=ismember(urine.Properties.RowNames,data{:,1});
disease_data_pos=ismember(data{:,1},urine.Properties.RowNames);
data=data(disease_data_pos,:);
% disease_pos=[1;0;1;0;0;0;0;0;0;0;0;1;0;1;0;1;1;0;0;0;0;0;1;0;1;1;0;0;0;0;0;0;0;0;1;1;1;0;1;0;0;0;1;1;0;0;0;1;0;0;0;1;0;1;0;0;0;0;0;0;0;0;0;1;0;1;0;1;0;0;1;1;0;0;0;1;0;1;0;0;1;0;0;1;1;0;0;0;0;0;0;1;0;0;1]%ismember(urine_food.Properties.RowNames,data{:,1});
% disease_pos=logical(disease_pos);
urine_food_extracted=urine(disease_pos,urine_pos);

% abnormal_food=[abnormal_food;ones(size(Results_H,1)-num_blood_mets,eval_IEMs+1)]';
% abnormal_food_extracted=abnormal_food([logical(1);disease_pos],blood_pos);

blood_food_extracted=blood(disease_pos,blood_pos);

urine_mets=strrep(urine_food_extracted.Properties.VariableNames,'Urine_','');

blood_mets=strrep(blood_food_extracted.Properties.VariableNames,'Blood_','');
data=[data,array2table(zeros(size(data,1),2),'VariableNames',{'BloodFood','UrineFood'})];

orig_data=extract_data_food_untargeted_metabolomics(data,urine_mets,blood_mets,blood_food_extracted,urine_food_extracted);
data=orig_data;

% data=data(:,1:13);
% data=[data,array2table(zeros(size(data,1),10),'VariableNames',{'UP_FED','DOWN_FED','NORMAL_FED','NUP_FED','NDOWN_FED','UP_FAST','DOWN_FAST','NORMAL_FAST','NUP_FAST','NDOWN_FAST'})];

% save(['Results_for_blood_biomarker_prediction_',strjoin(type_of_diet(meal)),'_AUC.mat'])


%%
    data_blood=[data(:,1:4)];
    data_urine=[data(:,1:3),data(:,5)];
    data_blood.Properties.VariableNames(end)={'AUC'};
    data_urine.Properties.VariableNames(end)={'AUC'};
    data_urine=data_urine(~isnan(data_urine{:,4}),:);

writetable(data_blood,['Results_for_blood_biomarker_prediction_',strjoin(type_of_diet(meal)),'_AUC.csv']);
writetable(data_urine,['Results_for_urine_biomarker_prediction_',strjoin(type_of_diet(meal)),'_AUC.csv']);


