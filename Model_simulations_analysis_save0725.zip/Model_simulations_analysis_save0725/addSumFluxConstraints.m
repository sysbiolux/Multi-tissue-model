function lp=addSumFluxConstraints(lp, model, upper_b,lower_b,Reactions,Coefficients,name)
%Adds a sum Flux constraint to the provided cplex lp object. 
%NOTE: The LP Object will be directly modified!
%Reactions is a CellArray of Reaction names, 
%Coefficients is an double array of the same length as reactions.
% upper_b and lower_b are the right hand side and left hand side
% constraints respectively
if nargin < 7
    name = ['SumFluxConstraint' num2str(numel(lp.Model.rhs))];
end
[Presence,Positions] = ismember(Reactions,model.rxns);
row = zeros(1,size(lp.Model.A,2));
row(Positions(Presence)) = Coefficients;
if(isfield(lp.Model,'rowname'))
    lp.addRows(lower_b,row,upper_b,name);
else
    lp.addRows(lower_b,row,upper_b);
end
        

